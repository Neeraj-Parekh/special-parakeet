# AGENT SPEC — Paper Knowledge Extraction

You are processing academic papers and producing a reusable knowledge base. For EVERY paper assigned to you, create these 4 files inside the paper's folder (path given in your assignment):

## 1. `summary.md` — comprehensive markdown summary
Required sections, in this order:
```markdown
# <Full Paper Title>

| Field | Value |
|---|---|
| **Authors** | ... |
| **Venue / Year** | ... |
| **Type** | journal article / conference paper / survey / book / whitepaper / preprint |
| **DOI / URL** | if present in text |
| **Processed** | <timestamp given to you> |
| **Source PDFs** | <filenames + sha256 prefix> |

> Version 1 — generated from extracted PDF text.

## Abstract
(verbatim abstract from the paper, quoted)

## Plain-Language Restatement
(3-5 sentences a non-expert can understand)

## Problem Statement
What gap does it address? Why does it matter?

## Methodology
Detailed: approach, algorithms/architectures, datasets, evaluation setup, metrics used. Include specifics — model names, hyperparameters, dataset sizes, statistical tests — as found in the text.

## Key Results
Quantitative metrics with markdown tables where the paper reports numbers (copy actual numbers). Qualitative insights too. If the paper is conceptual/qualitative, summarize its key claims/arguments/frameworks instead.

## Conclusions & Implications
What authors claim + what it means for practitioners building payment/fintech AI systems.

## Limitations
Acknowledged by authors AND inferred by you (mark which is which).

## Relevance to Our Hackathon
Why this matters for a Razorpay-track fintech hackathon: agentic payments/commerce, Return-to-Origin (RTO) risk prediction for e-commerce shipments, fraud detection on imbalanced data, customer trust & consent (incl. India DPDP-style consent), explainability of risk models, MLOps production deployment. Be specific about how ideas transfer.
```

## 2. `skill.yaml`
```yaml
name: kebab-case-skill-name
description: One paragraph — what an agent can now DO because of this knowledge.
version: 1.0.0
source_paper: "<paper title>"
tags: [tag1, tag2]   # lowercase-kebab
capabilities:
  - name: capability_name
    description: concrete action an agent can perform
    inputs: [...]
    outputs: [...]
dependencies:
  libraries: [...]   # python packages etc., or "none"
  data: [...]
  external_apis: [...]
examples:
  - title: short example task
    description: minimal usage snippet showing HOW an agent uses this skill (pseudo-code or CLI steps ok)
references:
  - citation or related-paper/repo mention
```

## 3. `research_requests.md`
5-10 bullets, each `- [High|Med|Low] Concrete experiment/question inspired by this paper`. Must be actionable (e.g., "Train XGBoost on synthetic COD RTO labels; compare SHAP importance vs paper's findings"), not vague.

## 4. `metadata.json`
```json
{
  "title": "...", "authors": ["..."], "venue": "...", "year": ...,
  "doi": null, "keywords": [...],
  "type": "...",
  "sources": [{"filename":"...","sha256":"...","pages":N}],
  "generated_at": "<timestamp>",
  "text_sha256": "<sha256 of concatenated source text files, compute over the txt cache file(s)>",
  "tags": [...], "folder": "<slug>"
}
```

## RULES
1. ACCURACY ABOVE ALL: every claim must come from the paper text you read. Never invent numbers, citations, or author names. If something isn't in the text, write "(not stated in text)".
2. Read the FULL cached .txt file(s). If >150k chars, read in chunks (Read tool offset/limit); prioritize abstract, intro, method, results, discussion, conclusion. For books: read TOC + skim all chapters' openings + read 2-3 core chapters deeply.
3. Multiple sources = same paper different versions: use the more complete/published version as primary; note version differences briefly in metadata.json under "notes".
4. Tags vocabulary (pick 3-8): agentic-payments, agentic-commerce, trust, consent, governance, regulation, liability, fraud, rto-risk, imbalanced-learning, concept-drift, explainability, mlops, deployment, blockchain, agent-economy, security, supply-chain, logistics, retail, ecommerce, consumer-protection, systematic-review, interpretability, cost-optimization, green-scm, human-ai-collaboration, user-studies, personalization, defi, digital-product-passport, cloud-infrastructure, deep-learning-platforms.
5. Write files directly with the Write tool. Do not ask questions.
6. After finishing ALL assigned papers, output a compact JSON report line per paper: {"slug","files_written":[...],"status":"ok"}.
