# Notes — agentic-ai-as-a-service-trust-satisfaction-continuance (source: .cache/df005b572a06.txt, 1782 lines, full sequential read 2026-08-26)

## Chunk 1 (lines 1–864)
- Title: "Agentic AI as a service innovation: A mixed-methods study of satisfaction, trust, and continued use". Authors: Al-Sharafi, Al-Zaeemi, Dwivedi*, Abdulkareem, Ali, Chae (KFUPM + SKKU). JIK 14 (2026) 101039. DOI 10.1016/j.jik.2026.101039. Received 7 Nov 2025, Accepted 6 Apr 2026, online 17 Apr 2026. CC BY-NC-ND.
- Abstract verbatim confirmed: 52,370 reviews Google Play + Apple App Store; LDA; PLSr + XGBoost; autonomy/proactivity/goal-directedness→satisfaction; adaptability/collaboration/persistence→trust; satisfaction stronger behavioral driver.
- Keywords: Agentic AI; Service innovation; Continued use intention; Human–AI collaboration; Computational agency; Post-adoption behavior.
- Intro: 3 gaps (user-level interpretations missing; post-adoption mechanisms not integrated with agentic traits; scarce large-scale inductive+confirmatory combos). Manus AI treated as general-purpose exemplar.
- Table 1 (p3–4): 6 prior research streams × approaches/emphasis/limitation (conceptual syntheses; org/sector analyses; technical architectures; human-AI theorizing; applied validation).
- Study 1: 102,166 reviews scraped → langdetect English 94,945 → preprocessing (dedup/lowercase/punct-numeral-URL strip/stopwords/tokenize/lemmatize NLTK+spaCy) → 52,370 clean. Top tokens: good, best, great, amazing, tool, use. Word cloud Fig 2.
- LDA Gensim: trained on 100 topics, retained 50 with coherence > 0.350. VADER+TextBlob polarity −1..+1, subjectivity 0..1, aggregated per topic.
- Construct mapping: hybrid keyword-lexicon + manual review. Lexicons: Autonomy(automation/autonomous/independently); Proactivity(suggest/anticipate/prompt); Goal-Dir(steps/results/correctly); Adaptability(match/mistakes/requested); Collaboration(team/together/working); Persistence(stable/consistent/daily); Trust(verification/account/sms); Satisfaction(easy/amazing/useful); CUI(continue/keep using/valuable). Nine constructs.
- Expert validation: 3 experts, 5-pt Likert relevance+clarity, 52/54 ratings (96.3%) at 4–5; Fleiss κ=0.31 modest; PABAK κ=0.90 high; disagreement on Persistence(relevance)+Proactivity(clarity).
- Figs: Fig 1 two-phase design (p4, adapted from Al-Sharafi et al. 2026); Fig 3 dendrogram high-freq keywords (p6); Fig 4 term-document heatmap (p7).

## Chunk 2 (lines 865–1711)
- H1–H9 wording confirmed as in summary. Quotes per trait confirmed (autonomy: "worked on its own"/"executed everything seamlessly"; proactivity: "starting research before I asked"; goal-dir: "kept moving toward the result"; adaptability: "adjusting when something failed"; collaboration: "digital partner"/"co-worker"; persistence: "kept trying even after errors").
- Fig 5 research model (p9). Three PLSr models; DVs = sentiment polarity AND subjectivity proxy scores; standardized β, SE, F-statistics; XGBoost k-fold CV tuned hyperparams (boosting rounds, learning rate, max depth, subsampling, regularization); importance by gain.
- Table 2 (p10): EXACT match to summary Key Results table:
  H1 0.019(.003)/0.011(.004); H2 0.029(.004)/0.019(.004); H3 0.077(.003)/0.019(.003); H4 0.223(.005)/0.081(.003); H5 0.040(.003)/0.005(.004); H6 0.136(.003)/0.005(.003); H7 0.314(.004)/0.121(.004); H8 0.325(.004)/0.125(.004); H9 0.029(.003)/0.144(.004).
  Model 1 R²=0.72/0.47, F=15,552.94/10,842.14; Model 2 R²=0.601/0.532, F=10,389.18/9732.29; Model 3 R²=0.607/0.535, F=9815.71/9080.78. ALL SUMMARY NUMBERS VERIFIED CORRECT.
- Table 3 (p11): XGBoost gain — Satisfaction: Autonomy .488(1), Trust .297(2), Proactivity .164(3), Goal-Dir .051(4); Trust: Collaboration .679(1), Adaptability .217(2), Persistence .113(3); CUI: Satisfaction .756(1), Trust .244(2). ALL SUMMARY NUMBERS VERIFIED CORRECT.
- Discussion: dual-pathway; "trust legitimizes reliance, while satisfaction motivates repetition"; collaboration top predictive trust driver though adaptability top structural; two-stage judgement (threshold of acceptability → experiential reinforcement).
- Implications: reusable outputs for autonomy; proactivity controllable w/ overrides; collaboration cues natural dialogue/shared ownership; service governance escalation procedures/responsibility boundaries/recurring-issue monitoring; UGC listening loop; "when trust and satisfaction clash... satisfaction usually determines if users come back."

## Chunk 3 (lines 1712–1782)
- References end. Limitations: single app (Manus AI), interpretive construct mapping, individual-user perceptions only; future: group-level trust, co-agency, shared decision-making, accountability, fairness, explainability, ethical alignment.
- Disclosure: manuscript edited with GPT-5.2 for grammar/style. Ack: KFUPM Grant CUP2602.

## Verification verdicts vs artifacts
- Header facts: OK. Abstract verbatim: OK. Methodology: OK. Key Results numeric tables: OK (all β/p/R²/F/gain values verified). Conclusions/limitations: faithful. skill.yaml capabilities consistent w/ paper (numbers 0.488/0.679/0.756 verified). research_requests.md numbers (β=0.040/0.223, 0.756 vs 0.244, β 0.325, R²=0.72, importance 0.488): verified.
- Figures to log: Fig 1 (p4 flowchart), Fig 2 (p5 word cloud), Fig 3 (p6 dendrogram), Fig 4 (p7 heatmap), Fig 5 (p9 model diagram), Fig 6 (p11 validated framework); Tables 1–3.
