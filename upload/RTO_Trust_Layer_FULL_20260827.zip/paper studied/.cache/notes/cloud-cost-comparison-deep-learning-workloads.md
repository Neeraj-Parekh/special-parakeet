# Notes — cloud-cost-comparison-deep-learning-workloads (f0023a6efd6d.txt)
Source: /mnt/20265E15265DEC72/study/CODE/HACKATHON/financial/paper studied/.cache/f0023a6efd6d.txt — 529 lines, 7 pages PDF (3447545.3451184.pdf)
Read mode: sequential single chunk (lines 1–529) — full text read 2026-08-26

## Chunk 1 — Lines 1–529 (full paper)

### Header / bibliographic facts (lines 1–52)
- Title check: "Performance and Cost Comparison of Cloud Services for Deep Learning Workload" (lines 1–2)
- Authors: Dheeraj Chahal, Mayank Mishra, Surya Palepu, Rekha Singhal — TCS Research, Mumbai, India — emails {d.chahal, mishra.m, surya.palepu, rekha.singhal}@tcs.com (lines 3–5)
- Venue/year: Companion of the 2021 ACM/SPEC International Conference on Performance Engineering (ICPE '21 Companion), April 19–23, 2021, Virtual Event, France — HotCloudPerf 2021 Workshop — ACM, New York, NY, 7 pages (lines 30–32, 48–52, 101–103)
- DOI: https://doi.org/10.1145/3447545.3451184 (line 32, 52)
- CCS: General and reference → Performance; Computer systems organization → Cloud computing (lines 21–23)
- Keywords: Recommendation system, ML Platform, AWS SageMaker, cloud performance (lines 25–26)
- No hidden subtitle/extra metadata.

### Abstract — VERBATIM (lines 6–20)
> Many organizations are migrating their on-premise artificial intelligence workloads to the cloud due to availability of cost-effective and highly scalable infrastructure, software and platform services. To ease the process of migration, many cloud vendors provide services, frameworks and tools that can be used for deployment of applications on cloud infrastructure. Finding the most appropriate service and infrastructure for a given application that results in a desired performance at minimal cost, is a challenge. In this work, we present a methodology to migrate a deep learning model based recommender system to ML platform and serverless architecture. Furthermore, we show our experimental evaluation of AWS ML platform called SageMaker and the serverless platform service known as Lambda. In our study, we also discuss performance and cost trade-off while using cloud infrastructure.

Note: abstract in source is split across lines with hyphen breaks ("intel- ligence", "ser- vices", "learn- ing") but content is continuous.

### Introduction (lines 34–125)
- Enterprise migration motivations: large infrastructure, high scalability, low operational management cost (lines 35–38)
- Decisions required: appropriate cloud services, instance types, configuration — based on app characteristics, performance requirements, budget (lines 38–54)
- Vendor examples listed explicitly:
  - ML platforms: AWS SageMaker [9], Microsoft Azure ML, TFX [11], MLFlow [16] — allow automatic training, deployment, inference (lines 57–59)
  - Serverless: AWS Lambda, Microsoft Azure Functions, Google Cloud Functions, IBM OpenWhisk (lines 60–63)
- SageMaker vs Lambda trade-off stated intro: SageMaker low latency vs Lambda pay-per-use cost savings, bursty traffic suitability (lines 65–68)
- Once platform chosen → next is instance family (compute-intensive vs memory-intensive with varying configs) — e.g. serverless better for event-driven bursty traffic, SageMaker endpoint for long-running workloads (lines 70–77)
- Recommender system use case: enhances customer experience, recommendations from historical behavior; can be deployed via ML platform and serverless; SageMaker for recommenders well-known but comparison vs serverless "not explored by its practitioners" (lines 78–88)
- Contributions (lines 92–112):
  1. Scheme for migrating deep-learning recommender to cloud
  2. Study inference performance and cost using different instance types on cloud
  3. Compare performance and cost when recommender deployed using ML platform vs serverless platform
- Platform used: AWS SageMaker end-to-end (data labeling, training, deployment, inference) → features GPU acceleration, auto-scaling, A/B testing, batch inference but steep cost; AWS Lambda → high scalability at low cost, especially for functions with small execution time and low resource requirements (lines 113–120)
- Paper structure: §2 related work, §3 recommender system/on-premise + migration, §4 experimental setup, §5 evaluation, §6 conclusion (lines 121–125)

### Related Work (lines 126–151)
- Recommender systems for customer experience: many ML workflows — Michelangelo [1] from Uber (1 million predictions/sec) and FBLearner [7] from Facebook (6 million predictions/sec) (lines 130–134) — contextual numbers to be cited
- Deployment of recommender iPrescribe using AWS SageMaker studied earlier [4] (lines 134–135)
- Serverless popularity for DL models: high scalability, pay-per-use; SPEC RG Cloud working group published 86 serverless use cases in technical report [15] (lines 138–139)
- Serverless architecture for DL apps studied [5][8]; suitability for recommenders also explored [3,13] (lines 140–142)
- Zheng et al. MArk [17]: study on cloud services for cost-effective and SLO-aware ML inference — authors extend this further to compare recommender on different SageMaker endpoint servers and vs Lambda (lines 143–148)
- Claim: "To the best of our knowledge, this work is a first effort to compare ML platform and serverless architecture for deploying deep learning model based recommender system." (lines 149–151)

### §3 Our Recommender System — NISER (lines 152–181)
- Model: NISER [6] — graph neural network (GNN) [14] based session-based recommendation model, utilizes user's past actions like product/item clicks (session) to recommend next product/item (lines 154–158)
- On-premise §3.1 (lines 160–195):
  - NISER consists of several layers including GNN layer — shown in Figure 1 (lines 161–163)
  - Figure 2 overall scenario/placement of components (lines 164–165)
  - Session-based models like NISER require only recent actions → useful for unknown users: first-time visitors on e-retail website browsing products (or non-logged-in user) (lines 166–171)
  - Item as embedding vector length 100 (line 172–173)
  - Training: learn item embeddings so items often clicked consecutively have similar embeddings; dataset = past sessions of item clicks by users (lines 173–177)
  - Prediction: sequence of items in current session used to predict top k items to be recommended next (Figure 2 context) (lines 178–180)
  - Figure 2 shows user clicks over web/app interface, session manager to identify sessions and keep track of item clicks per session, NISER model embedded in recommender process which recommends top-k (lines 183–195, continued next chunk)
- Cloud-based implementation §3.2 (lines 196–242):
  - Migration to AWS SageMaker then Lambda (lines 199–202)
  - §3.2.1 Using AWS SageMaker — Figure 3 (lines 204–219):
    - Call to fit API invokes train method in entry script defined in PyTorch [12] estimator.
    - Training data pre-loaded on S3 invoked inside train for training.
    - At completion, model returned by train, saved in S3 with parameter values.
    - Once training over, save API invoked, model saved on S3.
    - Call to deploy function invokes model_fn method of SageMaker, model accessed from S3.
    - SageMaker PyTorch model server created to host model; runs inside SageMaker endpoint.
    - Endpoint accessed via predictor object returned by deploy API; predictor has predict method doing inference returning NumPy array by default.
  - §3.2.2 Using AWS Lambda — Figure 3/Figure 4 (lines 221–242):
    - Figure 4: recommender deployment on AWS Lambda (line 249–250)
    - Serverless good choice due to small execution time per inference (line 224)
    - Challenges: statelessness; Lambda provides total 500 MB storage, only 250 MB available for deployment packages.
    - PyTorch + NumPy required ≈ 900 MB (line 228–229)
    - Solution: CPU version of PyTorch requiring only 200 MB → satisfies constraint (lines 229–231)
    - Another challenge: cold start → very high latency for first request; techniques to mitigate cited [2][10] (lines 231–233)
    - As in 3.2.1 used SageMaker APIs for training/deploy/infer — here Lambda used for deployment and inference ONLY (training still via SageMaker APIs) (lines 234–236)
    - First request triggers event, NISER model loaded in memory of Lambda function from S3 along with other packages/code from local storage → cold start significant latency overhead (lines 237–241)
    - Event handler code in Lambda contains predict function executed per request (lines 241–242)

### §4 Experimental Setup (lines 243–261)
- On-premise server: Intel server 28 physical cores, 256 GB memory; Python 3.6 with PyTorch version 17.1 over CentOS 7 (lines 245–247 → NOTE: "17.1" as printed in source; likely typo for 1.7.1)
- SageMaker instances: ml.c5.large and ml.c5.xlarge compute family CPU instances with gdn.ml.xlarge and gdn.ml.2xlarge family of GPU instances (lines 248–251; note source typo "gdn.ml.xlarge" vs correct ml.g4dn.xlarge — appears as "gdn.ml.xlarge" line 251 but later corrected to ml.g4dn.xlarge)
- Lambda: each instance configured with 3 GB memory → allocation of 2 cores per Lambda function (lines 252–253)
- Load generation: Jupyter notebook instance for SageMaker as well as Lambda (lines 254–255)
- Performance measurements: response time measured with increasing concurrency (number of concurrent users); response time is round-trip time; for all serverless experiments, provisioned concurrency used, response time collected while Lambda is warm; all data points collected in steady state (lines 256–261)

### §5 Experimental Evaluation
- Overview: first on-premise then vs SageMaker then vs Lambda (lines 262–266)
- §5.1 On-premise — Figure 5 (lines 268–295):
  - Allocated different cores (4,8,16) to NISER process instance; also experimented with 2 instances of NISER process (lines 271–274)
  - Python 3.6 PyTorch 17.1 CentOS 7 repeated (281–282)
  - Figure 5 mean response times: as concurrency increases, response time increases in each instance type irrespective of cores (lines 282–286)
  - Concrete example: "light blue" bar representing 8-core allocation — response time 16 ms for single request → 278 ms when 11 concurrent requests made; increase primarily due to queuing delay (lines 286–290)
  - Key observation at higher concurrency (6,8,11): response time of one 8-core instance ≈ twice that of two 4-core instances; same for single 16-core vs two 8-core (lines 291–295)
  - Inference: horizontal split beats vertical scale-up on average latency (queuing).

- §5.2 Cloud deployment using AWS SageMaker — Figures 6–11 (lines 296–348):
  - Effect of scaling on response time and cost per inference on ml.c5.xlarge (4 cores) and ml.c5.2xlarge (8 cores) and 2× ml.c5.xlarge (2*4 cores) (lines 302–305)
  - Figure 6 CPU: as concurrency increases response time increases each instance type; ml.c5.2xlarge slightly lower than ml.c5.xlarge at higher concurrencies due more cores (lines 305–310)
  - Figure 7 GPUs similar behavior (lines 310–312)
  - Figure 8 (multiple CPU instances) + Figure 9 (multiple GPU instances): average response time using 2× ml.c5.xlarge with total 8 cores significantly less than 1× ml.c5.2xlarge same total cores; BUT large variation at higher concurrency when using multiple instances instead of one equivalent — attributed to load imbalance on SageMaker model servers while distributing requests (lines 317–325)
  - Figure 10 cost per inference comparison ml.c5.xlarge (4-core) vs ml.c5.2xlarge (8-core): performance gain small but cost per inference approximately double in ml.c5.2xlarge vs ml.c5.xlarge (lines 326–330)
  - Figure 11 similar for GPUs ml.g4dn.xlarge vs ml.g4dn.2xlarge: cost per inference difference not as wide as CPU case (lines 330–344)
  - Interpretation: scope for trade-off; increase in resources at higher cost does not translate to proportional performance gain; user must choose deployment judiciously satisfying SLA + budget (lines 344–348)

- §5.3 Comparison of on-premise, AWS SageMaker and Lambda — Figures 12–13 (lines 349–421):
  - Figure 12: response time observed on-prem CPU vs SageMaker CPU vs GPU endpoint vs Lambda with increasing workload (lines 352–359)
  - At very low concurrency Lambda response time higher than SageMaker CPU and GPU — because SageMaker compute resources underutilized (lines 354–357)
  - As concurrency/load increases, SageMaker resources saturated; Lambda provides high scalability and spawns instances proportional to number of requests → constant response time in Lambda but linear increase in SageMaker CPU/GPU endpoints; response time with CPU endpoint highest vs GPU endpoint and Lambda at higher concurrency (lines 360–367)
  - Activating scaling feature in SageMaker can mitigate increasing response time but results in higher implementation cost vs pay-per-use Lambda (lines 368–371)
  - On-premise deployment response time higher vs SageMaker CPU with comparable configuration — attributed to optimized libraries/environment used in SageMaker (lines 371–374)
  - Figure 13 cost comparison (lines 375–402):
    - SageMaker and Lambda have unique cost models → challenging to compare (lines 376–377)
    - SageMaker cost proportional to up-time independent of CPU usage; Lambda pay-per-use derived from execution time, memory used, number of requests served (lines 378–381)
    - Figure 13 shows maximum achievable request rate for each instance and its fixed cost for one hour; Lambda cost dependent on requests served and time for serving (lines 382–385)
    - Intersection point of Lambda trend-line with each instance represents break-even point; if request rate below intersection → serverless cheaper (SageMaker instances underutilized but billed full hour); if request rate between intersection and max achievable → SageMaker cheaper because optimally utilized (lines 385–402)
  - Conclusions from data (lines 403–421):
    - Some scenarios serverless delivers better performance due to fast/high scalability for bursty workloads vs ML platform; ML platform better for long-running workloads when resources optimally used.
    - Inherent constraints: cold start in serverless → very high latency first request; observed cold start time of 30 seconds (lines 410–412)
    - Use of ML platform in conjunction with serverless can mitigate cold start; workload balanced such that bursty traffic redirected to serverless without provisioning for short-lived workload in ML platform.
    - Auto-scaling in SageMaker possible but takes few minutes vs few seconds for serverless instances → serverless good for bursty (lines 417–421)

### §6 Conclusion and Future Work (lines 422–442)
- Summary: presented methodology to migrate recommender to SageMaker and Lambda; performance/cost comparison with different instance types; comparison SageMaker vs Lambda; finding cost incurred due to scaling does not increase proportionally; auto-scaling in serverless results in better performance vs dedicated endpoints (lines 424–433)
- Future work: use application profiling and characterization data to find most appropriate cloud service; characteristics: memory usage, compute requirement, processing time, portability, workload, environment requirement etc. can be deciding factors mapping app to optimal infra/platform/service; building performance models using on-premise characterization data to configure cloud resources for cost-effective/high-performance deployment (lines 434–442)

### References (lines 443–529)
- 17 references: [1] Uber Michelangelo, [2] Bermbach 2020 cold starts, [3] BARISTA 2019, [4] Chahal et al. iPrescribe SageMaker 2020, [5] Migrating Large DL Models to Serverless 2020, [6] Gupta et al. NISER 2019 arXiv:1909.04276, [7] Hazelwood et al. Facebook HPCA 2018, [8] Ishakian et al. Serving DL in Serverless 2018, [9] Liberty et al. Elastic ML in SageMaker SIGMOD 2020, [10] Lin & Glikson pooling 2019, [11] Modi et al. TFX KDD 2017, [12] Paszke et al. PyTorch NeurIPS 2019, [13] Sreekanti et al. Serverless Dataflow 2020, [14] Tiezzi et al. GNN Lagrangian 2020, [15] van Eyk et al. SPEC RG Vision 2018, [16] Zaharia et al. MLflow 2018, [17] Zhang et al. MArk USENIX ATC 2019

### Cross-checks / potential drift risks for verification
- PyTorch version printed as "17.1" (lines 247, 281) — verbatim preservation needed; summary currently says "PyTorch version 17.1 (as printed)" — correct.
- Instance naming drift: setup section says "gdn.ml.xlarge and gdn.ml.2xlarge" (typo) vs later "ml.g4dn.xlarge and ml.g4dn.2xlarge" and "ml.c5.large" vs "ml.c5.xlarge" — source actually lists both; summary currently consolidates to ml.c5.large/xlarge/2xlarge and ml.g4dn.xlarge/2xlarge — need verify exact listing; text line 248–251 says "ml.c5.large and ml.c5.xlarge compute family CPU instances with gdn.ml.xlarge and gdn.ml.2xlarge family of GPU instances" — summary should include ml.c5.large (currently does) and note GPU naming inconsistency.
- Lambda memory 3 GB → 2 cores (line 252–253) matches summary.
- Response time numbers: 16 ms → 278 ms for 8-core 1→11 concurrency — matches summary exactly.
- "Approximately twice" for 1×8 vs 2×4 and 1×16 vs 2×8 — matches summary "≈2×".
- Cost per inference double CPU vs narrower GPU gap — matches summary.
- Cold start 30 seconds — matches summary (line 412).
- Max 86 serverless use cases [15], 1M vs 6M predictions/sec — matches summary.
- "First effort" claim present line 149–151 — matches problem statement.
- Abstract verbatim check needed vs summary's quoted abstract — appears exact.
- All 13 figures referenced (Fig 1–13) — images folder has partial subset due to truncated PDF rendering but spec says use primary version's images.
