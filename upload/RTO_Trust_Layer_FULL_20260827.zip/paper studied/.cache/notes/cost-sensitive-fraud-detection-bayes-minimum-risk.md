# Notes — cost-sensitive-fraud-detection-bayes-minimum-risk

## Source versions
- PRIMARY `CostSensitiveCreditCardFraudDetectionUsingBayesMinimumRisk_2013.pdf` (dd56f08dfb1c.txt, 27,763 chars, 6p): preprint-style; includes explicit prob-adjustment Eqs (6)-(7). Text extraction dropped the "1.26 billion" figure on p1.
- SECONDARY `bahnsen2013.pdf` (bc2b8ef00a97.txt, 28,557 chars, 6p): IEEE ICMLA 2013 published version — footer "2013 12th International Conference on Machine Learning and Applications", "978-0-7695-5144-9/13", "DOI 10.1109/ICMLA.2013.68", pages 333–338. Includes "1.26 billion" SEPA fraud 2010; refs add Sánchez et al. association rules; probability adjustment described in prose (no Eqs 6-7). Same content otherwise.
- Venue: ICMLA 2013 (12th Intl Conf on Machine Learning and Applications). Authors: Alejandro Correa Bahnsen, Aleksandar Stojanovic, Djamila Aouada, Björn Ottersten — SnT, University of Luxembourg.

## Key facts
- ECB [1]: 2010 SEPA card fraud ≈ €1.26 billion.
- Fraud ratios in literature: 0.005%–0.5%.
- Cost matrices: Hand et al. fixed FN = 100·Ca (Table II); proposed real-cost FN = Amt_i transaction amount (Table III); FP/TP cost = Ca (admin cost of analysis + contacting cardholder).
- Cost measure Eq (1): C = Σ yi(pi·Ca + (1−pi)·Amti) + (1−yi)·pi·Ca.
- Bayes minimum risk: classify fraud if R(pf|x) ≤ R(pl|x); fixed-cost rule Eq(4): CaP(pf|x)+CaP(pl|x) ≤ 100·CaP(pf|x); real-cost rule Eq(5): CaP(pf|x)+CaP(pl|x) ≤ Amti·P(pf|x).
- Data: large European card processor, 2012, 80M transactions, 27 attrs → selected attrs (Table IV: date, account, card, tx type Internet/Card-present/ATM, amount EUR, merchant ID/group, country, country2, card type, gender, age, bank, fraud label); +260 derived aggregation attributes (Whitrow/Bhattacharyya methodology), e.g., # internet tx last 6h same person+country.
- Full DB: 20,000 frauds / 80M = 0.025%. Subset used: 750,000 tx, 0.467% fraud, €866,410 total fraud loss. Train Jan–Oct (625k, 2,900 frauds, 0.464%, €721,349); Test Nov–Dec (125k, 600 frauds, 0.480%, €148,562).
- Under-sampling S1..S50 (1/5/10/20/50% frauds, all keep 2,900 frauds): S1=290k, S5=58k, S10=29k, S20=17.5k, S50=5.8k. Test never under-sampled.
- Models: LR (ℓ2 reg), C4.5 (sklearn defaults), RF (max estimators per split=10, Gini) via scikit-learn; thresholding optimization (Sheng & Ling); BMR w/ fixed matrix (-MR H), real-cost (-MR), real-cost + adjusted probabilities (-MR A). Prob adjustment: P*(pf|x)=P(pf|x)·Porig/Pund (Eq 6), P*(pl|x)=1−P*(pf|x) (Eq 7).
- Ca baseline = €2.50; sensitivity 1.00–5.00.

## Results
- No model at all ⇒ test cost €148,562.
- Fig 1: F1 best at S5 (RF≈0.245); cost best at higher fraud % (S50). Tree models > LR. F1-based selection ≠ cost-based selection.
- S50 savings up to 76% vs no model.
- Threshold opt: only RF improves — cost −€2,165 (47,669→45,504), F1 unchanged; LR-T worst (€87,127); C4.5-T no change. Conclusion: threshold method overfits training data.
- BMR fixed (MR H): worse everywhere (LR-MR H €95,190).
- BMR real cost (MR): LR-MR saves €13,685 vs LR (59,157→45,472); RF-MR bad (58,165) — overestimated probabilities from under-sampling.
- BMR adjusted (MR A): RF-MR A best overall €36,634 @Ca=2.50 ⇒ 23% savings vs RF (47,669). Recall down ~25% vs RF-T but catches high-amount frauds.
- Sensitivity Table VI (@1.00/2.50/5.00): RF-MR A = 20,929 / 36,634 / 52,003 — consistently best.

## Figures (primary images)
- Fig1a line chart F1 vs Train,S1..S50 (RF/LR/C4.5): peak RF@S5≈0.245.
- Fig1b bar chart Cost: RF@S50≈48k lowest of traditional.
- Fig2a combo bars(cost)+lines(prec/rec/F1) C4.5..RF-T: RF-T cost≈45.5k, recall↑0.80.
- Fig2b MR H: LR-MR H cost≈96k worst.
- Fig2c MR: LR-MR≈45.5k good, RF-MR≈59k bad.
- Fig2d MR A: RF-MR A≈36.6k best; recall drops to ~0.55-0.57 vs RF-T ~0.80.
- Charts look Excel-style rasterized (grey plot area, purple bars, blue/red/green markers), moderate quality.

## Hackathon relevance
- Direct template for RTO/fraud loss economics: replace accuracy metrics with euro/denominated cost matrix using per-transaction amounts; BMR decision layer on top of any probabilistic classifier; probability recalibration after resampling is essential.
