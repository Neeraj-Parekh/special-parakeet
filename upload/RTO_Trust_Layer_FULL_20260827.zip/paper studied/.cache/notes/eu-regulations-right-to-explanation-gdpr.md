# eu-regulations-right-to-explanation-gdpr — Full Source Notes (v2 verification)

**Sources:** 70704196032f.txt (euregs.pdf, 10pp, 32863 chars, preprint) + 1cd62fde7e27.txt (goodman2017.pdf, 8pp, 38064 chars, AI Magazine Fall 2017 published)
**Date:** 2026-08-26
**Method:** Sequential line-by-line read, no skips; 2-source comparison; image-by-image deep dive.

---

## Source 1: 70704196032f.txt (euregs.pdf) — Chunk 1 (lines 1-150)

- Title: "European Union regulations on algorithmic decision-making and a ''right to explanation''" — authors Bryce Goodman, Seth Flaxman (no affiliations page1, but AI Magazine version adds Oxford Internet Institute / Dept Statistics, Oxford).
- Abstract verbatim (lines 7-16): summarizes GDPR impact on ML, slated for 2018 law, restricts automated individual decisions that "significantly affect" users, may effectively create right to explanation, challenges + opportunities for CS.
- Intro (lines 18-38): GDPR adopted April 2016, first comprehensive regs in >20y. "Copernican Revolution" quote Kuner 2012. Right to be forgotten Art 17, foreign companies Art 44 as examples. Art 22 is key — potentially prohibiting wide swath of algorithms in recsys, credit/insurance, computational advertising, social networks. Needs overhaul of standard techniques. Interpretability importance. Mid-2018 effective.
- Figure 1 presented lines 39-58: full Article 22 excerpt 4 paragraphs: (1) right not to be subject to solely automated decision with legal/significant effects; (2) exceptions contract necessity / Union law authorization with safeguards / explicit consent; (3) safeguards for (a)+(c): human intervention, express view, contest; (4) no special categories Art 9(1) unless 9(2)(a) or (g) + safeguards. Caption: "Excerpt from the General Data Protection Regulation, (Parliament and Council of the European Union 2016)".
- Background (lines 61-108): GDPR April 2018 replaces 1995 DPD. Superficially reaffirms DPD but critical differences: (i) Directive vs Regulation — directive transferred to national law per country's discretion; regulation directly applicable EU-wide, no enabling legislation, simply is law. Notes DPD only indirectly implemented via member laws (Cra(?) citation — truncated in preprint). Footnote 2 scope nuance. (ii) Fines: DPD no explicit max, country-by-country; GDPR €20M or 4% global revenue whichever greater Art 83(5) — billions for Google/Facebook. (iii) Scope global Art 3(1) — any company processing EU residents' data, irrespective of processing location. (iv) New explicit rights Arts 77-80: complaint to supervisory authority (77, residence/work/infringement venue); judicial remedy vs supervisory authority (78, 3-month handling); judicial remedy vs controller/processor (79, liability para4); compensation/liability (82, material/non-material damages); representation by not-for-profit body (80). Together strengthen actual ability to pursue (Pastor & Lawrence 2016).
- Article 4 Definitions start lines 109-115: personal data = any info relating to identified/identifiable natural person; data subject; processing = any operation on personal data whether automated or not; profiling (continued next chunk).

**Condensed takeaway chunk 1:** Establishes GDPR novelty vs DPD in enforceability/fines/scope/judicial rights. Figure 1 is verbatim Article 22.

---

## Source 1: 70704196032f.txt — Chunk 2 (lines 151-300)

- Non-discrimination section opens lines 147-153: cites Art 21 Charter of Fundamental Rights, Art 14 ECHR, Arts 18-25 TFEU as normative basis. Profiling inherently discriminatory in categorization sense.
- Barocas & Selbst 2016 quotes: "Big data claims to be neutral. It isn't." Data contains inequality/exclusion so models reproduce it; "unthinking reliance can deny vulnerable groups full participation." Accurate classifier reifies discrimination as objective.
- Recital 71 (preamble, not law) requires controllers implement "appropriate technical and organizational measures" that "prevents, inter alia, discriminatory effects" on basis of processing sensitive data. Art 9 defines sensitive: racial/ethnic origin, political opinions, religious/philosophical beliefs, trade-union, genetic, biometric for identification, health, sex life/orientation (lines 171-177).
- Paragraph 71 + Art 22(4) specifically address discrimination from sensitive data profiling. Two interpretations unpacked:
  - Minimal: only explicit sensitive variables (ineffective). Removing them doesn't decorrelate due to proxies (Leese 2014, Hardt 2014). Example: geographic region correlates with low income/minority → loan eligibility informed by race/income via geography.
  - Maximal: include all variables correlated with sensitive categories → infeasible. Must ensure no dataset variables correlate with Art 9 categories. Calders & Verwer 2010 quote: "postal code can reveal racial information and yet still give useful, non-discriminatory information on loan defaulting." As datasets grow, correlations complex (IP vs race), e.g., Deloitte actuaries can predict health from consumer buying history with medical-exam accuracy (Robinson et al. 2014). Exhaustive exclusion impossible; firms reluctant to drop web-browsing patterns though correlated.
- Introduces "uncertainty bias" (Goodman 2016b) lines 213-239: arises when (a) one group underrepresented → more uncertainty, (b) algorithm risk-averse → prefers confident predictions (smaller CIs) per Aigner & Cain 1977. Could mean loan algorithms favor better-represented groups.
- Illustrates in Figure 2 (described before seen): population white vs non-white, synthetic datasets N=500 varying non-white proportion, true repayment 95% independent of race, logistic regression, decision rule lower end of 95% CI >90% threshold → all whites offered credit (CI small), non-whites <30% share denied entirely due to uncertainty.
- Right to explanation section start lines 279-291: distinguishes Arts 13-15 access/notification rights vs Art 22 profiling safeguards. Article 22 requires not just human intervention but Arts 13/14 require "meaningful information about the logic involved" when profiling. Prompts: what does explaining algorithmic decision require?
- Standard ML = correlations for prediction, no causal reasoning, only variance explained. Hildebrandt 2008: correlations = probability future same, not why. Pasquale 2015 black box society demands transparency.

**Condensed takeaway chunk 2:** Core dilemma: minimal interpretation ineffective, maximal infeasible → need human-intelligible explanations. Introduces uncertainty bias definition + simulation setup. Distinguishes notification vs explanation duties.

---

## Source 1 — Chunk 3 (lines 301-464)

- Burrell's 3 barriers detailed lines 302-309: (1) intentional concealment, (2) technical literacy gaps (code insufficient), (3) mismatch high-dimensional optimization vs human-scale reasoning.
- GDPR mapping: Art 13 goes some way to #1 (processors inform when/why data collected); Art 12 attempts #2 (concise, intelligible, easily accessible); #3 remains hard — model-selection challenge. Cites Lisboa 2013: ML alone in spectrum lacking interpretability.
- Explanation adequacy criterion lines 320-325: adequate explanation at minimum provides account how input features relate to predictions, answering "Is model more/less likely to recommend loan if applicant is minority? Which features play largest role?"
- Trade-off interpretability vs capacity lines 326-338: linear easy but limited; SVMs/Gaussian processes rich but hard; random forests hard via aggregation/averaging; neural nets hardest (deep learning weights unexplainable). Active research Kim et al. 2016. Promising: quantitative input influence from black-box access (Datta et al. 2016).
- Conclusion lines 339-380: Focused on two GDPR issues: nondiscrimination + right to explanation. Not comprehensive — Article 9 ethical access conditions out of scope, human intervention needs further investigation. Footnote 8 unclear if must disclose algorithms/data publicly. Challenges are "good problems" pushing transparent/fair/inspectable models ex ante and ex post. Cites discrimination identification (Berendt & Preibusch 2012, Sandvig et al. 2014) and rectification tools (Calders & Verwer 2010, Hajian et al. 2011, Zliobaite et al. 2011 etc.). Adoption uncertain. Silver lining: algorithmic bias identifiable/correctable vs human bias (Tversky & Kahneman 1974, Danziger et al. 2011, Abrams et al. 2012) pervasive in profiling sectors (Holmes & Horvitz 1994, Bowen & Bok 1998). Properly applied algorithms can be more accurate+transparent/fair than humans (Laqueur & Copus 2015). Final: GDPR vital acknowledgement few decisions purely technical; needs coordination top technical+philosophical; <1 year to effective, clock ticking.
- Acknowledgements: SRF supported ERC FP7/617071 and EPSRC EP/K009362/1.
- References: detailed list lines 383-464; note preprint artifacts: "[Cra ]" truncated (should be Fromholz 2000 in published), "?" placeholder for second Goodman 2016b citation, volume/page missing for Barocas & Selbst vs published includes details.

**Condensed takeaway chunk 3:** Explanation standards, interpretability spectrum, future research directions, optimistic conclusion about correctability vs human bias.

---
**Source 1 verification notes:** Preprint textual artifacts present (Cra, ?) not substantive. Figure 2 described in text lines 223-271 with axis labels extracted (0-50 x non-white %, 0-100 y predicted probability, legend non-white/white/approval threshold dashed 90%).

---

## Source 2: 1cd62fde7e27.txt (goodman2017.pdf) — Chunk 1 (lines 1-200)

- Published AI Magazine presentation lines 1-51: Header "Articles 50 AI MAGAZINE" + copyright 2017 AAAI ISSN 0738-4602, IStock image p51. Same title/authors. Abstract identical verbatim lines 25-46.
- Intro lines 54-76 matches preprint but small edits: "for example" after social networks, wording identical otherwise.
- Background lines 77-200: Same structure as preprint, but preprint footnote citations fixed. Page 52 quotes: "European Documentation Centre 2016" vs preprint "European Commission 2016" (same content, different docs). Fromholz 2000 citation is fully spelled out vs preprint "Cra" truncation — confirms postfix fix. Goodman 2016a,2016b both cited (preprint had "?"). Article 22 Figure 1 caption introduced lines 184-186 same, but figure itself extracted lines 187-216 shows proper typesetting with paragraph numbers and indentation, same 4-paragraph legal text, includes line breaks verified.
- Article 22 excerpt verified verbatim: (1) right not to be subject to solely automated inc profiling with legal/significant effects; (2)(a)(b)(c) exceptions; (3) safeguards for (a)+(c): human intervention, express view, contest; (4) no special categories Art 9(1) unless 9(2)(a)(g) + safeguards. All match preprint lines 39-56.
- Definitions lines 155-168 identical to preprint: personal data, data subject, processing, profiling, profiling subset conditions.

**Condensed takeaway chunk 1 (published):** No substantive divergence from preprint in abstract/intro/background/fines/scope/rights/definitions — only copyediting and complete citations, confirming preprint reliability.

---

## Source 2 — Chunk 2 (lines 201-400)

- Figure 1 continuation verified identical to preprint; page layout "Articles FALL 2017 53" artifact but text matches.
- Analysis of Art 22 safeguards: even with exceptions must provide safeguards; Art 9 access vs Art 22 profiling distinction reiterated lines 239-243 footnote 3 comparing consent not providing legal ground for sensitive data.
- Non-discrimination section lines 256-364 identical verbatim to preprint (with added "race, or gender" phrasing vs "e.g. race, gender etc" — negligible). Barocas quotes, Recital 71, Art 9 sensitive list, minimal/maximal interpretations, Calders & Verwer postal code quote, IP address example, Deloitte buying history predicting health with medical-exam accuracy, web-browsing reluctance — all match.
- Uncertainty bias definition lines 366-374: two numbered conditions (1) underrepresented → more uncertainty, (2) risk averse prefers confident (smaller CIs) [Aigner & Cain 1977] — matches preprint bullet but formatted as (1)(2) numbered list in published.
- Illustration lines 375-400: Same synthetic setup N=500 varying non-white proportion, true 95% repayment independent of race, logistic regression. Figure 2 caption lines 393-400 expanded: "An Illustration of Uncertainty Bias. A hypothetical algorithm..." with identical threshold logic (95% CI lower end >90% dashed line), <30% denied, approaching 50% all approved. Published caption more verbose with line-break hyphenation but same numbers.

**Condensed takeaway chunk 2 (published):** Confirms preprint simulation details; no numeric divergence; figure 2 caption verbatim except formatting.

---

## Source 2 — Chunk 3 (lines 401-600)

- Numeric axis ticks extracted lines 401-417: x = Non-white % of population 0-50 (0,10,20,30,40,50), y = Predicted probability of repayment 0-100 (0,20,40,60,80,100), legend: non-white vs white vs approval threshold. Note page extraction shows y-axis ticks out-of-order (20,0,40,60...) due to PDF extraction order but image restores correct ascending order.
- Logistic decision detail lines 422-433: risk averse rule lower end 95% CI above 90% threshold, all whites offered (CI small, true 95%), non-whites <30% denied due to uncertainty small sample.
- Active learning compounding lines 434-444 identical to preprint: more complicated combos occupation/location/consumption, rare combos few obs, active learning acquires more of better represented group, bias compounds.
- GDPR dilemma with two horns lines 445-455 same: minimal ineffective, maximal infeasible, need human-intelligible explanations.
- Right to Explanation lines 456-472: Arts 13-15 access vs Art 22 safeguards, human intervention footnote 6, meaningful information about logic involved footnote 7 (profiling must also significantly affect).
- ML correlation vs causation lines 473-483: Hildebrandt quote, Pasquale black box society same.
- Burrell barriers lines 490-500: (1) intentional concealment, (2) gaps technical literacy, (3) mismatch high-dimensional optimization vs human-scale reasoning — enumerated not bulleted in published but same content.
- GDPR mapping lines 501-514: Art 13 toward #1, Art 12 concise intelligible toward #2, #3 remains hard, Lisboa 2013 quote "machine learning approaches are alone in the spectrum in their lack of interpretability".
- Explanation adequacy lines 515-525 identical: answering "Is model more/less likely to recommend loan if applicant is minority? Which features play largest role?"
- Trade-off lines 526-548 identical: linear → SVM/Gaussian processes → random forests → neural nets hardest, Kim et al 2016, Datta et al 2016 quantitative input influence from black-box access.
- Conclusion lines 549-600 starts same: not comprehensive, human intervention needs investigation, "good problems", ex post/ex ante inspection cites, discrimination identification/rectification cited lists identical (adds Feldman et al 2015 in published that was "?" in preprint). Silver lining about identifiable interventions vs human bias with same citations (Tversky Kahneman, Danziger, Abrams etc) and Laqueur Copus.

**Condensed takeaway chunk 3 (published):** Figure 2 axes numbers confirmed, surrounding simulation narrative identical, discrimination & explanation arguments match preprint exactly.

---

## Source 2 — Chunk 4 (lines 601-850)

- Closing claim lines 597-604: "Above all else, the GDPR is a vital acknowledgement that, when algorithms are deployed in society, few if any decisions are purely 'technical'." Coordination technical+philosophical, <1 year to effect, clock ticking — matches preprint closing.
- Acknowledgements lines 605-607: Seth Flaxman supported ERC FP7/617071 and EPSRC EP/K009362/1 — matches preprint SRF abbreviation.
- Notes lines 608-645: 9 footnotes: (1) Reg (EU) 2016/679 OJ L119/1, (2) delegation to Member States tension citing Mayer-Schönberger & Padova 2016 p325, (3) consent not legal ground for sensitive data EU 2016, (4) extended analysis Goodman 2016b, (5) underrepresentation can arise historical discrimination or random sample rate, oversampling in public health, (6) exact meaning of intervention unspecified, (7) profiling must significantly affect, (8) unclear if must disclose algorithms/datasets public, (9) algorithm audits Goodman 2016a/b.
- References lines 646-850: full bibliography matching preprint but now complete — note corrections: preprint "[Cra ]" → "Fromholz, J.M. 2000 The European Union Data Privacy Directive. Berkeley Tech Law J 15(1):461-484."; preprint "?" → "Feldman et al 2015 Certifying and Removing Disparate Impact. KDD 259-268"; preprint incomplete Barocas pagination now "104:671"; adds DOIs, publishers, fuller details for all entries; adds Feldman entry, Mayer-Schönberger etc. Bibliography quality higher.
- Author bios lines 715-721: Bryce Goodman research associate Oxford Internet Institute MSc Oxford; Seth Flaxman researcher Dept Statistics Oxford PhD CMU — not in preprint.

**Condensed takeaway chunk 4 (published):** No new substantive results; footnotes clarify scope limits (not comprehensive, intervention unclear, disclosure uncertainty), bibliography complete.

---

## Cross-Source Comparison

- Both sources describe same paper; differences purely presentational: published adds AAAI copyright, volume/issue/pages (Fall 2017 Vol 38 No 3 pp50-57, though pagination in txt shows 50-57), author affiliations, figures correctly typeset, citations completed, grammar tiny: "discrimination includes race or gender" vs "race, gender, etc", reference formatting.
- No conflicting numeric claims: both state N=500, threshold 90%, CI 95%, repayment 95% independent, <30% denial zone, 50% parity. Both describe fines €20M/4%, Art 22 text verbatim, Art 3 global scope, Arts77-82 rights list.
- Primary source for verification: goodman2017.pdf (1cd62fde7e27) considered authoritative due to final venue formatting.

---

## B. Figures & Tables Visual Deep Dive (10 pngs inspected 2026-08-26)

- **Source 70704196032f images:** `page_002.png` (bottom: Figure 1 black-bordered Art 22 box + intro para, vector sharp), `page_004.png` (Non-discrimination section text-heavy, confirms profiling definitions), `page_005.png` (maximal interpretation + uncertainty bias definition bullets, text sharp), `page_006.png` (Figure 2 line chart center + caption below, vector: x 0-50 Non-white %, y 0-100 Predicted probability, red flat white ~92%, blue dashed 90 threshold, black rising non-white 8%@1% → 60%@6% →75%@10% →88%@20% →91%@30% cross →92%@50% converge).
- **Source 1cd62fde7e27 pages:** `page_002.png` (top decorative gavel/EU flag iStock photo + Background intro two-column, high-res photo credits © pepifoto), `page_003.png` (left: mint-green Figure 1 box with shadow + right: Art77-82 rights list + Article 4 definitions, vector green fill), `page_005.png` (top: Figure 2 green-background line chart full-width, thicker lines, same axes/values; bottom: maximal interpretation + uncertainty bias text continuation).
- **Embedded crops:** `img_p002_15.png` (2139×1568 high-res crop of gavel/EU flag, raster sharp, shallow DoF), `img_p003_21.png` (528×713 solid grey placeholder — extraction artifact for green Figure 1 box, unreadable but page render valid), `img_p005_35.png` (1107×623 grey placeholder for Figure 2 crop, same artifact).
- **Quality:** Both paper figures vector-crisp, no blur/pixelation at 200%, no watermark, axes not cropped, fonts consistent (serif body, sans axes minor). Preprint plain B/W, published polished green theme with drop shadows. Grey embedded placeholders are extraction failures, not paper defects.
- **Linkage verification:** Figure 1 supports Problem Statement/Methodology Art 22 pathway checklist (no numeric contradiction). Figure 2 numeric readings precisely support Key Results bullets (<30% denied, 50% parity, N=500/95%/90% params). Simulation capture matches text lines 223-238 (preprint) and 380-433 (published).
- **Tables:** No numeric data tables present; Figure 1 boxed legal excerpt + Figure 2 chart only. Extracted Article 22 paragraphs + Figure 2 interpolated values to `tables.csv` for completeness.

**Verification outcome:** All summary numeric claims (N=500, 95% true repayment, 95% CI, 90% threshold, <30% cutoff, €20M/4% fines, global Art3(1), Arts77-82 list) confirmed verbatim against both sources and page images. No drift requiring correction beyond version/metadata bump and Figures & Tables addition.

---



