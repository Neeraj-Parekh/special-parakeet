# Running notes — hybrid-multistage-credit-card-anomaly-fraud (key 5e3a8b823b7a)

Full sequential read of `.cache/5e3a8b823b7a.txt` (962 lines, 51,068 chars) completed 2026-08-26.

## Header facts
- Title: "Hybrid Machine Learning-Based Multi-Stage Framework for Detection of Credit Card Anomalies and Fraud"
- Author: Hatoon S. Alsagri, College of Computer and Information Sciences, Imam Mohammad Ibn Saud Islamic University (IMSIU), Riyadh 11673, Saudi Arabia (hsagri@imamu.edu.sa)
- Venue: IEEE Access, vol. 13, 2025, pp. 77039–77048. DOI 10.1109/ACCESS.2025.3565612
- Dates: received 4 Apr 2025, accepted 25 Apr 2025, published 29 Apr 2025, current version 7 May 2025. CC-BY 4.0. Associate editor Mauro Fadda. Funded by IMSIU DDRSP2504.
- Index terms: CCF, ML, DL, features selection, multi-stage classification.

## Abstract key numbers
- fraud recall 0.901, legitimate recall 0.995, model cost 0.421.
- Classifiers: LR, SVM, XGBoost, RF, KNN, DNN. Sampling technique + internal feature selection by voting.

## Intro / motivation (lines 28–163)
- Rule-based systems: interpretable but computationally intensive, subjective to experts, hard to maintain, cannot handle new fraud patterns.
- CCF = binary classification; one of most imbalanced problems in ML. Resampling improves minority detection but introduces FPs on majority.
- Contributions: (1) generic distribution-based resampling framework that neutralizes imbalance w/o adding majority FPs; (2) heterogeneous multistage classification framework beating classical voting ensembles; (3) interpretability layer fusing feature extraction techniques; (4) comparison vs LR/SVM/XGBoost/RF/KNN/DNN on f1-measure and cost.

## Related work (lines 164–228)
- Table 1 = comparative analysis of existing CCF detection techniques (on p. 77042 render).
- Prior art cited: RF better legal-case accuracy vs ANN better fraud accuracy [17]; DL vs linear regression/GBT on 81M transactions [28]; champion-challenger DL+ensemble [29 Kim]; homogeneity-oriented behavior analysis + deep-belief network [23]; HMM features + RF; GAN synthetic fraud samples; spark/Kafka near-real-time online CCF.

## Background (lines 229–407)
- Imbalance handling taxonomy: data layer (over-sampling: ROS, SMOTE, Radius-SMOTE; under-sampling: random, one-sided dynamic, neighborhood-based) vs model layer (cost-sensitive SVM/LR/DT; handcrafted cost matrix issue).
- KNN lazy learner; also used in this work for missing-value imputation (outperformed mean/median, preserves relationships).
- K-means unsupervised clustering with Euclidean distance to centroids; termination: max iterations / unchanged distribution / centroid change below threshold.
- LR base model, interpretable. SVM hyperplanes, best for small complex datasets.
- Tree methods: RF ensemble; XGBoost top in competitions; trees need no scaling, handle missing values, support class error weights.
- Deep learning: paper states it "develops and tests two models: a DNN and a CNN" (only DNN appears in results).

## Method (lines 408–504)
- Dataset: public Kaggle credit card dataset [60] — collected Q4 2013(September, two days), European cardholders; all features PCA-transformed; 28 encoded features + time + amount; 284,807 transactions, 492 frauds, fraud class percentage 0.173%.
- Two experimental tracks: (a) bypass data handling, classify directly; (b) full pipeline then classify.
- Empty-values check module using KNN imputation (though Kaggle set has none).
- Outlier detection: Isolation Forest (handles multi-variable outliers; binary-tree isolation).
- Figure 1 = data preparation phases; Figure 2 = proposed CCF identification framework.
- Proposed sampling (Algorithm 1): split into imbalanced train I and test T; I → minority X, majority Y; KNN classifies each Y sample as boundary point B or mass point M; random sets from B (B1..Bm); k-means scores M points in K clusters, random sets G1..Gk; random sets from X (X1..Xn); mix {Bi},{Gj},{Xi} into Modified Training Sets. Idea: force model to consider boundary points.
- Identification approach: new stacking — first-layer multiple classifiers; second-layer model receives outcomes AND decision probability; neutralizes first-layer misclassifications; second layer does not need whole feature set, only decisions+probabilities (performance advantage).

## Evaluation setup & cost model (lines 505–604)
- Accuracy meaningless under imbalance → precision/recall/FPR/F1/confusion matrix.
- Banking KPIs: C_Investigation = Y·Amt (Y = # predicted-fraud-but-legitimate cases; Amt = investigation cost). C_overall = C_Investigation + Σ_FN Trans_Amount_i. Model Cost_f = C_overall(f)/C_overall(withoutModel).
- Experiment axes: with/without data pipeline; sampling ∈ {raw, SMOTE, proposed}; model ∈ {individual, traditional stacking, proposed multi-stage stacking}.
- Grid-searched hyperparameters:
  - LR: alpha=0.3, fit_intercept=True, normalize=True, solver=sag
  - SVM: kernel rbf, degree=2, gamma=scale, coef0=0.01, shrinking=False
  - XGBoost: verbosity true, validate_parameters true, min_split_loss=0.002, max_depth=10
  - RF: max_depth=7, min_sample_split=3, n_trees=60, min_samples_leaf=6
  - DNN: hidden_layer_sizes=2, activation ReLU, lr=0.001, solver Adam
  - KNN: k=5
- Findings from Table 3: DNN best individual model (two hidden layers + softmax); end-to-end data pipeline improves performance/decreases bias; proposed resampling > raw > SMOTE.
- Table 4: proposed multi-stage stacking beats simple voting (max voting), traditional stacking, individual DNN. Second layer needs only decisions+probability.

## Section V.A mathematical modeling (lines 615–670)
- Oversampling/undersampling validation; metrics listed incl. ROC and "merchant category codes (MCC)" [sic — cites nonexistent [69]; MCC usage is idiosyncratic]. Figure 3: f1/MCC results of over/under-sampling comparisons (proposed higher than SVM/KNN/RF). Figure 4: cost function (proposed lower cost than competitors).

## Conclusion (lines 671–691)
- Framework achieves >0.9 fraud recall, legitimate recall ≥0.995; superiority over individual models/traditional stacking/simple voting; architecture transferable to other heavily imbalanced ML applications.

## Reference-list quality observations
- Text cites [59] for Kaggle dataset URL www.kaggle.com/mlg-ulb/creditcardfraud; [60] Ogwueleka cited in text for the dataset but is a J. Eng. Sci. paper; citation numbering misaligned (e.g., [31] never referenced in body; [69] cited but absent; refs [47]-[58] partially mismatched to claims like CART book cited as SVM ref [52]).
- Duplicate-ish content around KNN/K-means sections (text interleaving artifact).

## TODO figures
- Read page_003..009 PNGs + img_p001_323.png visually; log Figures 1-4 and Tables 1-4 in figures.md + tables.csv.
