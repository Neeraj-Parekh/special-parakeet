# Running notes — ml-interpretability-logistics-delay-risk-ecommerce
Source: .cache/497d923080dc.txt (3779475.3779510.pdf, 8 pp, 962 lines). Read sequentially lines 1–962 in a single pass (file < 1000 lines). Images: page_002 (Table 1), page_005 (Table 2), page_006 (Table 3) — all viewed visually.

## L1–96 (p.234, title/abstract/intro)
- Title: "Machine Learning-Based Prediction and Interpretability Analysis of Logistics Delay Risks in E-commerce Supply Chains". Author: Ziyan Hu, School of Mathematics, University of Leeds, Leeds, UK; 18205161361@163.com; corresponding author.
- Abstract verbatim matches summary.md quote (checked word-by-word; F2 0.8704 RF; SHAP 'Order status' & 'Shipping mode' top; 'Order day of year' seasonal).
- ACM ref: ICCBD 2025, Nov 14–16, Lijiang, China; 8 pages; DOI 10.1145/3779475.3779510; ISBN 979-8-4007-2110-6/2025/11; CC BY 4.0. Pages numbered 234–241 ✓ header claim.
- Intro: punctuality → satisfaction/reputation/cost/responsiveness [1]; prior = linear regression/time series, weak in high-dim nonlinear [2-3]; single-model studies lack cross-algorithm comparison; opacity hinders deployment [4]. DataCo dataset, target "is delay or not". 8 model families. Contributions: comprehensive comparison (linear+nonlinear+ensembles+deep), F2 as primary metric, SHAP interpretation.

## L97–236 (p.235, Table 1 + Data)
- Table 1 (viewed on page_002.png): fields Logistics (Late delivery risk 1/0; Shipping mode 4 classes), Transaction feature (Type: DEBIT/TRANSFER/CASH/PAYMENT), Order status (Order date numerical; Order status 9 values incl. SUSPECTED_FRAUD, ON_HOLD, PAYMENT_REVIEW), Geographical (Customer city Caguas, country EE. UU., segment Consumer/Corporate/Home Office, Market Africa/Europe/LATAM/Pacific Asia/USCA, Order region South Asia, Order country Indonesia, Order city Bekasi), Pricing and profit (discount rate 0.07, product price 327.75, quantity 2, profit 91.25), Product (Department Fan Shop, Category Cleats, Product Smart watch). Matches summary feature list exactly.
- Dataset: Mendeley Data [5], 180,519 records × 53 features; Jan 1 2015 00:00:00 – Jan 31 2018 24:00:00 ✓.

## L236–363 (p.236, new variables + preprocessing)
- Temporal: weekday 0–6 Mon–Sun; weekend if 5/6; day-of-year 1–366; month 1–12; season 1–4 Winter/Spring/Summer/Autumn ✓.
- Merges: region 23 (counts 461–23,073) → 11; country 163 (1–20,191) → 11 (Estados Unidos…India + Others); city 3,575 (1–17,856) → 11 (Santo Domingo…London + Others); department 11 categories, max−min spread 54,077 → final 8 named (Fan Shop, Apparel, Golf, Footwear, Outdoors, Fitness, Discs Shop, Technology) + Others = 9 total; category 50 (54–19,961) → 11; product 118 → top-10 + Others.
  - NOTE: summary.md said "Department name→9 retained + Others" — WRONG (9 is the final total incl. Others; 8 retained). FIX.
- Preprocessing: no missing values; outliers 1–10% per numeric variable; IQR bounds, replace with boundary, iterate; one-hot drop_first=True; Z-score; VIF: Order month 96.259, Order day of year 86.635 > 10 → drop Order month; all remaining VIF < 10 ✓.

## L363–492 (p.237, models + metrics)
- 8 models: LR, DT, NB, RF (Breiman 2001 bagging), XGBoost (boosting), Voting (equal weights + CV-F2-weighted), Stacking (Wolpert 1992; LR meta-learner over all base models), shallow MLP ✓.
- Metrics: Precision=TP/(TP+FP), Recall=TP/(TP+FN), F2=(1+2²)P·R/(2²P+R)=5PR/(4P+R) ✓. FN cost >> FP cost rationale ✓.
- Random Search (Bergstra & Bengio 2012), 3-fold CV, F2 objective ✓.

## L492–632 (p.238, Table 2 + experiment setup)
- Table 2 (viewed on page_005.png, digit-by-digit): all 15 rows match summary.md exactly — LR 0.618294/0.848870/0.578978; LR-T 0.622694/0.829920/0.586107; NB 0.721739/0.577046/0.770009; NB-T 0.739694/0.573974/0.797240; DT 0.775612/0.780824/0.774319; DT-T 0.864420/0.560467/1.000000; RF 0.739059/0.838913/0.717702; RF-T 0.870418/0.574476/0.999088 (bold optimal row); XGB 0.636359/0.866306/0.596759; XGB-T 0.678725/0.833804/0.648568; Voting(Eq) 0.847663/0.649194/0.917810; Voting(CV) 0.847575/0.628087/0.928711; Stacking 0.798514/0.821131/0.793053; MLP 0.783394/0.791445/0.781407; MLP-T 0.801276/0.817317/0.797364.
- Setup: 8 numerically processed + 13 categorical one-hot features (=21) ✓; 7:3 train/test ✓; 3-fold CV on training ✓.
- Narrative: DT/RF F2 0.7756→0.8644 and 0.7391→0.8704 via max_depth/min_samples_split; LR +0.01; NB modest; XGB/MLP limited gains.

## L632–798 (p.239, Table 3 + analysis)
- Table 3 (viewed on page_006.png, digit-by-digit): mean|SHAP| top10 Standard Class 0.101164, Second 0.022585, SUSPECTED_FRAUD 0.014572, Type_TRANSFER 0.012669, PROCESSING 0.009344, PENDING 0.009144, Same Day 0.008418, Type_DEBIT 0.004349, day-of-year 0.004151, COMPLETE 0.003929; positive Glendale .000061, SF .000048, Brooklyn .000047, Highland .000042, Fairfield .000040, Woonsocket .000039, Bloomfield .000038, Strongsville .000034, Hialeah .000034, Tempe .000033; negative Standard −0.017571, SUSPECTED_FRAUD −0.003442, profit/order −0.002274, day-of-year −0.002215, PENDING −0.001785, discount rate −0.001665, Second −0.001552, weekday −0.001395, PROCESSING −0.001381, Type_TRANSFER −0.001221. All match summary.
- Text: DT-T recall 1.0000 but "Precision decreases markedly to 0.5604" (summary narrative said 0.5605 — FIX to 0.5604). MLP F2 0.8013. Stacking limited by linear LR meta. RF chosen optimal.
- SHAP interpretation: cities (Glendale/SF/Brooklyn) highest positive; "consistent with the feature importance ranking derived from the Random Forest model" (summary said "impurity-based importances" — source does not say impurity; FIX wording).

## L798–962 (p.240–241, conclusion + refs)
- Conclusion: RF optimal max F2 0.8704; F2 vs F1 divergence (Stacking/MLP favor F1); metric choice business-dependent ✓.
- Limitations: static data, no real-time routes/weather/traffic; no delivery-staff behavioral data; resource constraints → H2O AutoML future work ✓.
- 22 references; DataCo dataset ref [5] Fabian/Fernando/António 2019 Mendeley ✓.

## Figures & tables inventory
- Paper contains ZERO figures; exactly 3 tables (Table 1 p.2, Table 2 p.5, Table 3 p.6), all clean vector-rendered ACM tables. No watermarks, no blur, consistent fonts.

## Verification verdict
- Header/abstract/methodology/Key Results tables: verified against full text + page images. 3 corrections needed (department merge count; 0.5605→0.5604; "impurity-based" wording).
