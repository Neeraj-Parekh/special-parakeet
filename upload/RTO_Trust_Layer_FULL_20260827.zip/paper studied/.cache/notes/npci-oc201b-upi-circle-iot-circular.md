# Running notes — npci-oc201b-upi-circle-iot-circular (key 1b298dffaf71)

Scanned document; `.cache/1b298dffaf71.txt` empty (6 chars whitespace). Visual transcription of all 3 rendered pages completed 2026-08-26. Embedded img_* files are degraded scan layers (faint p1 copy; dark unreadable p1 copy) of identical content — page renders used as primary.

## Document identity
- Ref: NPCI/UPI/OC-201B/2025-26, dated 8th October 2025.
- To: Members - Unified Payment Interface (UPI).
- Subject: Addendum to NPCI/UPI/2024-25/OC 201 – Introduction of IoT devices & software on UPI Circle.
- Signed: SD/- Sourabh Tomar, Head UPI Product.
- Parent circular: NPCI/UPI/2024-25/201 dated 13th August 2024 which introduced "UPI Circle – Delegated Payments for secondary users" (any UPI user can authorize/delegate payments to a trusted secondary user on any primary UPI App).

## Core extension (p.1)
- UPI Circle extended to IoT devices & software profiles: smart glasses, watch, TV, AI Profiles (initially limited users in CUG) under 'Full Delegation' framework per defined monthly limits + security guidelines.
- Debit transactions using IoT shall be only initiated by explicit user action.

## General guidelines (all members), p.1
1. Adhere to RBI 'Harmonization of TAT and customer compensation for failed transactions' dated Sep 20, 2019 as amended.
2. ODR functionality available for all such transactions.
3. Reconciliation per existing UPI guidelines; new purpose code 'BH' in UPI raw file to identify these transactions/settlements; additional raw file with secondary details shared with Primary PSP, Secondary PSP, Issuer Bank.
4. Only NPCI-permitted IoT devices/software linkable as secondary.
5. Only domestic P2M transactions permitted.
6. At linking time, primary and secondary devices shall be in close proximity.
7. Max monthly limit INR 15,000 per delegation; max per-transaction INR 5,000 for IoT device app/software.

## General guideline #8 (p.2)
8. 24-hour cooling period with cumulative transaction limit INR 5,000/-; auto-revoke authorization if delegation inactive 6 months or on security concerns (device tampering etc.).

## Primary UPI Apps (p.2)
1. Clearly display secondary device/software details; capture user consent for linking+authorizing with 2-Factor Authentication.
2. Provide lifecycle management (limit management, delinking) and transaction history for IoT-device transactions.
3. User can authorize up to 5 IoT devices/software from primary UPI apps.

## Secondary Apps and PSP Banks (Certified on UPI Circle), p.2
1. Secondary PSP Bank onboards IoT device app/software after due diligence + app security evaluation.
2. Secondary PSP facilitates registration with user consent + validation (mobile number + OTP); verify registered mobile number matches primary user's before linking.
3. Capture device/user ID details during registration; validate during payment request.
4. For software: capture user profile id; only PAID software profiles allowed; feature limited to limited users initially; wider opening to be communicated post validations.
5. Secondary Apps: same mobile number for user profile and UPI Circle registration.
6. User can accept delegation from only ONE Primary UPI App.
7. Secondary PSP Bank + IoT device App/software ensure security of payment and user data via NPCI-defined process: data-flow documentation, data localization guidelines, security reporting.
8. IoT without dedicated app/screen: advised to tie up with multiple supporting secondary UPI Apps; no exclusive tie-up with a particular secondary UPI App(s).

## Issuer Banks (p.3)
1. Validate device id/user id + requisite authorization details for EVERY transaction before debiting account.

## Numeric limits (prose, no tables in doc)
- INR 15,000 max monthly per delegation; INR 5,000 max per txn; 24h cooling period w/ cumulative INR 5,000; 6-month inactivity auto-revoke; up to 5 IoT devices per user; 1 primary app per delegation.

## Figures/tables
- None. Letterhead logos (NPCI, Always Forward, Together We Build), decorative diagonal lines, address block (1001A The Capital, B Wing, 10th Floor, Bandra Kurla Complex, Bandra (E), Mumbai 400 051; CIN: U74990MH2008NPL089067).
