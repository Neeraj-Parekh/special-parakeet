# Notes — open-fabric-for-deep-learning (bbe9876efd9e)

Source: `23_open_fabric_for_deep_learning_.pdf` — 5 pages, 15521 chars, engine fitz, sha256 4d6828b07f663fa1fa65206a4a5dda45633f74cd309088e60df176d78011733b
Text path: `.cache/bbe9876efd9e.txt` (253 lines). Sequential read in 1 chunk (lines 1–253; file <1000 lines). Images dir `.cache/images/bbe9876efd9e/` empty (rendered_pages: [], embedded_images: [] per figures_index.json).

## Chunk 1 — lines 1–253 (entire file)

### Header / bibliographic (lines 1–11)
- Title line 1: "Open Fabric for Deep Learning Models" — matches metadata title.
- Authors lines 2–10: Falk Pollok (IBM Research, falk.pollok@ibm.com), Scott Boag (IBM Research, scott_boag@us.ibm.com), Maria-Irina Nicolae (IBM Research, maria-irina.nicolae@ibm.com) — all IBM Research, three authors.
- No DOI; venue footnote line 52: "32nd Conference on Neural Information Processing Systems (NIPS 2018), Montréal, Canada." — year 2018, NIPS/NeurIPS venue, workshop context inferred from paper type/talk structure.
- Page count 5 confirmed by footer markers: "1", "2", "2", "3", "3", "4", "5" across extracted text.

### Abstract (lines 11–28)
Verbatim: "We will show the advantages of using a fabric of open source AI services and libraries, which have been launched by the AI labs in IBM Research, to train, harden and de-bias deep learning models. The motivation is that model building should not be monolithic. Algorithms, operations and pipelines to build and refine models should be modularized and reused as needed. The componentry presented meets these requirements and shares a philosophy of being framework- and vendor-agnostic, as well as modular and extensible. We focus on multiple aspects ... To train models in the cloud in a distributed, framework-agnostic way, we use the Fabric for Deep Learning (FfDL). Adversarial attacks ... mitigated using ART ... detect and remove bias using AIF360 ... publish ... using MAX ... Overall, we demonstrate operations ... and a set of developer APIs ... to democratize the open AI ecosystem."
- Ligature "reﬁne" (line 15), "ﬁddle" later; normalized to ASCII in summary — acceptable.
- Mentions four components: FfDL, ART, AIF360, MAX + call for community collaboration.

### Introduction (lines 30–76)
- Motivation repeated: model building should not be monolithic; share philosophy of framework/vendor agnostic + extensible (lines 32–35).
- FfDL (lines 36–46): "Fabric for Deep Learning (FfDL, pronounced 'ﬁddle')" — platform for training DL models in cloud via Kubernetes. Largely framework agnostic: Tensorﬂow, PyTorch, Keras, Caffe2 and others, extensible; open source on Github [1]. Microservices architecture — reduce coupling, keep each component simple/stateless, isolate component failures, allow each component to be developed/tested/deployed/scaled/upgraded independently. Leveraging Kubernetes → scalable, resilient, fault tolerant. Resource provisioning layer → ﬂexible job management on heterogeneous resources (GPUs and CPUs). Can integrate with other libs for fairness/robustness.
- ART (lines 47–59): Adversarial attacks risk [2,3]; evasion+poisoning with examples CCTV, voice assistants, autonomous cars. ART [4–7] is framework-agnostic library providing state-of-the-art attacks, hardening and robustness evaluation methods for classifiers. Modular design allows extension + composition via interfaces. Works with wide range of ML frameworks. Comprehensive defense foundation [8].
- AIF360 (lines 60–68): Python package; uses fairness metrics: "statistical partity difference" [sic — typo for parity], equal opportunity difference, average odds difference, disparate impact, Theil index to detect bias. Explainers → natural language, mitigators → remove bias, verify with same metrics. Business motivation beyond ethics: strategic goals (sell to all income groups equally) + legal traps (age discrimination illegal in deployment country).
- MAX (lines 69–72): "app store to discover, share and rate models" across frameworks; standardized classification/annotation/deployment [11].
- Collaborations (lines 73–76): Seldon [12] for serving; Horovod [13] as alternative to parameter servers; H2O [14].

### Related Work (lines 77–105)
- 2.1 Publications (lines 80–98): Deep learning as a service: IBM Watson ML [15], AWS SageMaker [16], Azure ML [17], Google TFX [18], Uber Michelangelo [19], Facebook FBLearner [20] — isolate multi-tenancy, metrics, fault tolerance, provisioning. Open source efforts: most popular is Kubeﬂow [21] followed by FfDL [1] and Microsoft DL Workspace [22]; differences in scheduling/distribution/framework support/ecosystem/architecture. Team prior pubs on IBM DLaaS [23], Scalable Multi-Framework Multi-Tenant [24], Dependability [25]; here present open source counterpart; reveals real-world challenges of open sourcing deeply integrated internal code: multi-tenancy, fault tolerance, scalability, open sourcing itself — complications moving to on-premise/public cloud deployable code.
- 2.2 Media/Summits (lines 100–105): FfDL released at Think; blog posts [26–30]; external coverage TechCrunch/IT World/InfoQ [31–33]; presented at IEEE Computer Society Silicon Valley [34]; videos [35,36].

### Structure of the Talk (lines 109–123)
- Deployment options: FfDL setup both on-premise and in public clouds — relevant for industries reluctant to compute confidential models on public infra. Storage: cloud object storage via S3 APIs for data, NFS for logs (lines 113–114). GPU support in K8s.
- Demo: train model via manifest specifying framework, data access, requested resources (lines 115–116). Architecture/APIs: public REST endpoint externally, internal gRPC to reduce latency (lines 117–118); distribute via Horovod or parameter servers.
- Workflow: train → adversarial attack to evaluate robustness → protect via ART; bias detection; submit to MAX (lines 119–121).
- Closing: collaborative future ideas for open source AI (lines 122–123).

### References (lines 124–253)
- [1] FfDL github, [2] Szegedy et al. Intriguing properties CoRR 1312.6199, [3] Biggio et al. Evasion attacks ECML PKDD 2013 pp 387–402, [4–8] ART urls + v0.3.0 CoRR 1807.01069 + blog posts, [9–10] AIF360 github + Bellamy et al. Oct 2017, [11] MAX, [12] Seldon, [13] Horovod, [14] H2O, [15–20] Watson/SageMaker/Azure/TFX/Michelangelo/FBLearner, [21] Kubeflow, [22] DLWorkspace, [23–25] IBM DLaaS papers, [26–30] developer.ibm.com blogs, [31–33] InfoQ/IT World/TechCrunch, [34–36] YouTube.
- No figures, tables, equations, datasets, metrics, or numeric results anywhere; purely architectural/position paper.

### Verification observations
- All summary.md Methodology claims directly supported by cited lines above.
- Key Results correctly states "no quantitative results" — confirmed: zero numeric tables/plots.
- Limitations correctly distinguish acknowledged (talk outline, no benchmarks) vs inferred (2018-era dormancy etc.).
- Skill capabilities map 1:1 to four components + principles described; no invented metrics.
- Typo "statistical partity" confirmed line 62; summary correctly notes it while using corrected spelling.
- No contradictions between figures (none) and text.
