# Running notes — teamlease-regtech-compliance-brochure (key 89701fba56d2)

Visual read of page_001.png, page_002.png, img_p001_135.png, img_p001_136.png completed 2026-08-26. Text layer (`.cache/89701fba56d2.txt`, 1138 chars) is website chrome only.

## What the artifact actually is (honest characterization)
- Print-to-PDF (2 pages, print stamp 8/26/26 12:03) of TeamLease Regtech's web-based **File Viewer** tool: `https://teamleaseregtech.com/fileviewer/?f=https%3A%2F%2Ftrplprodcompliance.bl...` (URL truncated).
- Page 1 = viewer UI (pager "1 of 2 pages", "Enquire Now" sidebar, phone/bookmark buttons, "Ask Ria anything... ✦NEW · AI ASSISTANT" chat widget, TeamLease footer with contact block: CIN U74999PN2018PTC179553, TeamLease Regtech Pvt. Ltd. formerly Avantis RegTech Pvt. Ltd., Office No. 312 & 313, Kakade Bizz Icon, Shivajinagar, Pune 411005, 9899245318, sales@tlregtech.com).
- Page 2 = TeamLease site footer only (locations Bangalore, Mumbai, Kolkata, Hyderabad, Delhi, Chennai, Ahmedabad; newsletter; Terms/Privacy; © TeamLease Regtech Pvt Ltd).
- NOT a marketing brochure with product claims; the substantive content is the **hosted document**: a 2-page scan of the PARENT circular NPCI/UPI/OC No.201/2024-25 dated 13th August 2024.

## Recovered content: NPCI OC 201 (parent of OC 201-B) — from embedded scans
Page 1 (img_p001_135.png):
- Ref NPCI/UPI/OC No.201/2024-25, dated 13th August 2024, to All Members - UPI.
- Subject: Introduction of "UPI Circle" – Delegated Payments for secondary users.
- Motivation: users dependent on cash because they don't manage their own account; UPI Steering Committee meeting 3rd August 2023 endorsed "UPI Circle - Delegate Payments".
- Definitions: Full Delegation (secondary initiates AND completes within spend limits); Partial Delegation (secondary initiates payment requests; primary completes with UPI PIN).
- Guidelines 1-4: (1) independent user journeys for primary/secondary; own choice of UPI app; (2) app passcode/biometrics (finger/face) mandatory for all secondary users; (3) linking: scan QR/enter UPI ID + select contact from contact list; later phase linking via contact-list selection only; (3a) manual entry of mobile number restricted; (4) primary can delegate to up to 5 secondary users; secondary accepts from only one primary.

Page 2 (img_p001_136.png):
- (5) primary authorizes secondary on either full or partial delegation.
- (6) limits control available to primary for usage controls over secondaries.
- (7) Full delegation: max monthly ₹15,000/- per delegation; max per transaction ₹5000.
- (8) Existing UPI limits apply for partial delegation.
- (9) Cooling period: first 24 hours after successful linking, daily transaction limit ₹5000 for both full and partial delegation.
- (10) Primary user visibility of secondary transactions on UPI App and bank account statement.
- (11) RBI Harmonization of TAT/customer compensation guidelines dated September 20, 2019, as amended.
- (12) ODR functionality available for UPI transactions.
- (13) Reconciliation per existing guidelines; NEW purpose code in UPI raw file + new line item in Net Settlement Report to identify UPI Circle transactions/settlements; additional raw file with secondary user details shared to primary PSP, secondary PSP and remitter bank*.
- "Members are advised to refer to UPI Circle Procedural Guidelines for detailed information."
- Signed SD/- Kunal Kalawatia, Chief of Products.

## Cross-links
- OC 201-B (sibling folder npci-oc201b-upi-circle-iot-circular) is the addendum extending UPI Circle to IoT/software; OC 201's limits (₹15,000/₹5,000, 24h/₹5,000 cooling) carried forward; OC 201-B adds 'BH' purpose code name and IoT-specific duties.
- Lexology article (sibling folder) cites this parent circular.

## Figures/tables
- No charts/diagrams/tables anywhere. UI elements: viewer toolbar icons, chat widget avatar, social icons (f/in/YouTube), footer nav.
