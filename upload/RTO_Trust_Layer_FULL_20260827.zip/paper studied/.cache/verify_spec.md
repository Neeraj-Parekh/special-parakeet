# VERIFICATION PASS v2 SPEC — full-source read + figure deep-dive

Two goals per assigned paper: (1) word-by-word verification of existing artifacts against the COMPLETE source, (2) visual analysis of every figure/table, recorded in the knowledge base. Accuracy is the only metric that matters.

## A. FULL SOURCE READ (no context loss)
- Open each source's cached .txt (`text_path` in assignments.json). Read it SEQUENTIALLY from line 1 to EOF using Read offset/limit chunks (~1000-1500 lines). NEVER skip ranges. After every chunk, append condensed running notes to `.cache/notes/<slug>.md` (create dir if needed).
- Scanned/image-only sources (chars < 2000): Read every `page_*.png` in `.cache/images/<key>/` VISUALLY and transcribe key content into notes instead.

## B. FIGURES & TABLES DEEP DIVE
For every source key of the paper: list `.cache/images/<key>/` and READ EVERY `page_*.png` (rendered pages incl. vector figures/tables) and EVERY embedded `img_*.png` with vision (skip byte-duplicate versions of same paper; use primary version's images).
For EACH figure/table log:
- ID (Figure 3 / Table 2 / unnumbered-p5), page, type (line chart / bar / heatmap / confusion matrix / architecture diagram / flowchart / photo / screenshot / data table)
- construction inference (matplotlib-style vector, gnuplot, hand-drawn, rasterized screenshot, scanned)
- axes / legend / units / series exactly as shown
- concrete takeaway numbers readable from it
- quality/editing observations: blurry? low-res? watermark? inconsistent fonts? cropped axis? pasted-from-another-doc look? (report honestly — this feeds venue-quality assessment)
- which summary.md claim it supports or contradicts
Write the complete log to `<folder>/figures.md`. Extract cleanly readable numeric tables into `<folder>/tables.csv` (first column: table_name+row label). Skip CSV only when truly not feasible.
Add concise `## Figures & Tables` section to summary.md: one bullet per figure — ID, type, one-line content + headline number/takeaway.

## C. WORD-BY-WORD VERIFICATION
Using notes + figures, verify and FIX IN PLACE:
1. Header table facts: title/authors/venue/year/DOI vs source.
2. Abstract section is verbatim from source (fix drift).
3. Methodology specifics (models, datasets, hyperparameters, stats) match.
4. EVERY numeric claim in Key Results matches source text or figures.
5. Conclusions/limitations faithful to what authors actually claim; keep inferred-vs-acknowledged distinction.
6. skill.yaml capabilities are genuinely enabled by this paper — no invented abilities; fix descriptions/examples misstating results.
7. research_requests.md asks remain factually consistent.
Record every change in metadata.json `"corrections": [{"file","field","before","after","reason"}]`.

## D. METADATA UPDATE
metadata.json: `"verified": true`, `"verified_at": <ts>`, bump skill.yaml + metadata `"version"` to 2.0.0, add `"figures_count"`, `"tables_extracted"`, append note "v2 full-read verification pass".

## E. RULES
Never invent figure contents you cannot see; say "unreadable" when true. Do not delete correct existing content. Keep existing formatting/style. If a paper has zero figures, state so explicitly in figures.md.

## F. REPORT
Final message: JSON line per paper {"slug","status":"ok|failed","corrections":N,"figures_logged":N,"tables_csv":true|false}.
