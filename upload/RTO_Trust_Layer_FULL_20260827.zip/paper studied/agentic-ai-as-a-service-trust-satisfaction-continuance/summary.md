# Agentic AI as a Service Innovation: A Mixed-Methods Study of Satisfaction, Trust, and Continued Use

| Field | Value |
|---|---|
| **Authors** | Mohammed A. Al-Sharafi; Shehab Abdulhabib Al-Zaeemi; Yogesh K. Dwivedi; Zainab O. Abdulkareem; Ahmed Ali; Inyoung Chae |
| **Venue / Year** | Journal of Innovation & Knowledge 14 (2026) 101039 (Elsevier); Available online 17 April 2026 |
| **Type** | journal article (mixed-methods empirical study) |
| **DOI / URL** | https://doi.org/10.1016/j.jik.2026.101039 |
| **Processed** | 2026-08-26T05:29:19Z |
| **Source PDFs** | main.pdf (sha256 prefix `5fcc4989`) |

> Version 1 — generated from extracted PDF text.

## Abstract

> "AI agents and agentic AI systems are increasingly employed for decision-making and task execution. However, limited evidence explains how users evaluate agentic features or form intentions to continue using these systems. This gap has important implications for service innovation and innovation management, because sustained adoption determines whether agentic AI generates scalable value in real use. This study examines how perceived agentic characteristics, autonomy, proactivity, goal-directedness, adaptability, collaboration, and persistence influence user satisfaction, trust, and continued use intention in a post-adoption context. User-generated reviews of the Manus AI app were analyzed using Latent Dirichlet Allocation to identify themes aligned with theoretical constructs, drawing on 52,370 reviews from Google Play and the Apple App Store. The resulting constructs were validated using Partial Least Squares regression and XGBoost to assess explanatory and predictive relationships. The findings show that autonomy, proactivity, and goal-directedness significantly predict satisfaction, while adaptability, collaboration, and persistence primarily shape trust. Satisfaction and trust predict continued use intention, with satisfaction emerging as the stronger behavioral driver. Overall, the results clarify the mechanisms through which agentic AI supports sustained engagement and service value creation, and they provide design guidance for developing agentic systems that can be scaled as service innovations and support digital transformation."

## Plain-Language Restatement

What makes people keep using an AI agent that acts on its own? The authors scraped over 100,000 app-store reviews of Manus AI (a general-purpose agentic assistant), mined them with topic modeling into six perceived agent traits — autonomy, proactivity, goal-directedness, adaptability, collaboration, persistence — plus satisfaction, trust, and continued-use intention, then validated the relationships statistically (PLS regression) and predictively (XGBoost). Result: traits like acting independently and anticipating needs make users *satisfied*, while recovering from errors, cooperating like a partner, and persisting through failures build *trust*. Trust legitimizes reliance, but satisfaction is what actually drives people to come back.

## Problem Statement

Agentic AI research is skewed toward conceptual definitions, technical architectures, and performance metrics while user-level evidence on how people evaluate agentic behaviors in repeated real-world use is scarce. Three gaps: (1) user interpretations of agentic traits in naturalistic contexts are under-studied; (2) established post-adoption mechanisms (satisfaction, trust → continuance, per Bhattacherjee's ECM and trust research) have not been integrated with perceived agentic traits; (3) large-scale studies combining inductive discovery from user content with confirmatory validation are rare. This matters for service innovation: continued use is a prerequisite for agentic AI generating scalable value.

## Methodology

- **Design**: Two-phase mixed-methods (inductive exploration → deductive validation), grounded in UGC analytics precedent.
- **Phase 1 data**: 102,166 Manus AI app reviews scraped from Google Play and Apple App Store; language detection (langdetect) kept English → 94,945; preprocessing pipeline (dedup/low-information removal, lowercasing, punctuation/numeral/URL stripping, stopword removal, tokenization, lemmatization via NLTK + spaCy) → **52,370 clean English reviews**. Most frequent post-processing tokens: "good," "best," "great," "amazing," "tool," "use."
- **Topic modeling**: LDA (Gensim); trained on 100 topics, retained 50 high-coherence topics filtered at coherence > 0.350; interpretability checked via top-probability terms and representative reviews; hierarchical clustering dendrogram + term-document heatmaps used diagnostically.
- **Sentiment/subjectivity**: VADER + TextBlob; polarity −1..+1, subjectivity 0..1, aggregated per topic to separate emotionally charged constructs (Satisfaction, Trust) from functional ones (Autonomy, Goal-Directedness).
- **Construct mapping**: hybrid keyword-lexicon matching + manual review of representative comments → nine constructs: Autonomy ("automation," "autonomous," "independently"), Proactivity ("suggest," "anticipate," "prompt"), Goal-Directedness ("steps," "results," "correctly"), Adaptability ("match," "mistakes," "requested"), Collaboration ("team," "together," "working"), Persistence ("stable," "consistent," "daily"), Trust ("verification," "account," "sms"), Satisfaction ("easy," "amazing," "useful"), Continued Use Intention ("continue," "keep using," "valuable").
- **Expert validation**: 3 domain experts rated relevance/clarity of 9 constructs on 5-point Likert scales; 52 of 54 ratings (96.3%) at 4–5; Fleiss' κ = 0.31 (modest), PABAK κ = 0.90 (high, expected under skewed endorsement); disagreement on Persistence (relevance) and Proactivity (clarity) resolved by refining definitions.
- **Phase 2**: Three PLS regression models (standardized β, SE, F-statistics; DVs operationalized as sentiment polarity AND subjectivity scores): Model 1 Satisfaction ~ Autonomy + Proactivity + Goal-Directedness + Trust; Model 2 Trust ~ Adaptability + Collaboration + Persistence; Model 3 Continued Use Intention ~ Satisfaction + Trust. Complementary XGBoost regressions per outcome (regularized gradient boosting; hyperparameters tuned by k-fold cross-validation: boosting rounds, learning rate, max depth, subsampling, regularization); feature importance by gain.

## Key Results

PLSr results (β, p-value; polarity / subjectivity):

| Hypothesis | Path | Polarity β (p) | Subjectivity β (p) | Supported |
|---|---|---|---|---|
| H1 | Autonomy → Satisfaction | 0.019 (0.003) | 0.011 (0.004) | Yes |
| H2 | Proactivity → Satisfaction | 0.029 (0.004) | 0.019 (0.004) | Yes |
| H3 | Goal-Directedness → Satisfaction | 0.077 (0.003) | 0.019 (0.003) | Yes |
| H4 | Adaptability → Trust | 0.223 (0.005) | 0.081 (0.003) | Yes |
| H5 | Collaboration → Trust | 0.040 (0.003) | 0.005 (0.004) | Yes |
| H6 | Persistence → Trust | 0.136 (0.003) | 0.005 (0.003) | Yes |
| H7 | Trust → Satisfaction | 0.314 (0.004) | 0.121 (0.004) | Yes |
| H8 | Trust → Continued Use Intention | 0.325 (0.004) | 0.125 (0.004) | Yes |
| H9 | Satisfaction → Continued Use Intention | 0.029 (0.003) | 0.144 (0.004) | Yes |

Model fit: Model 1 R² = 0.72 (polarity) / 0.47 (subjectivity), F = 15,552.94 / 10,842.14; Model 2 R² = 0.601 / 0.532, F = 10,389.18 / 9,732.29; Model 3 R² = 0.607 / 0.535, F = 9,815.71 / 9,080.78. Trust was the strongest structural predictor of both satisfaction (0.314) and continued use (0.325).

XGBoost feature importance (gain):

| Outcome | Feature | Importance | Rank |
|---|---|---|---|
| Satisfaction | Autonomy | 0.488 | 1 |
| Satisfaction | Trust in Agentic AI | 0.297 | 2 |
| Satisfaction | Proactivity | 0.164 | 3 |
| Satisfaction | Goal-Directedness | 0.051 | 4 |
| Trust | Collaboration | 0.679 | 1 |
| Trust | Adaptability | 0.217 | 2 |
| Trust | Persistence | 0.113 | 3 |
| Continued Use Intention | Satisfaction | 0.756 | 1 |
| Continued Use Intention | Trust in Agentic AI | 0.244 | 2 |

Explanatory-vs-predictive divergence: PLSr gives Trust the dominant structural role; XGBoost shows Autonomy dominates satisfaction prediction, Collaboration dominates trust prediction, and Satisfaction (0.756 vs 0.244) dominates continued-use prediction — interpreted as "trust legitimizes reliance, while satisfaction motivates repetition." Qualitative insight: continued engagement is a two-stage judgment — first a threshold of acceptability for autonomous action (trust gate), then reinforcement through consistently rewarding interactions. Representative user quotes: autonomy ("worked on its own," "executed everything seamlessly"), proactivity ("starting research before I asked"), adaptability ("adjusting when something failed"), collaboration ("digital partner," "co-worker"), persistence ("kept trying even after errors").

## Conclusions & Implications

Authors claim five contributions: empirical operationalization of six agentic constructs; a dual-pathway model separating instrumental traits (autonomy/proactivity/goal-directedness → affective satisfaction) from relational traits (adaptability/collaboration/persistence → cognitive trust); methodological combination of PLSr + XGBoost; integration of trust and satisfaction in one framework; demonstration of UGC/LDA as scalable construct-measurement pathway. Design guidance: prioritize hands-off autonomy with reusable outputs; make proactivity anticipatory but controllable (clear overrides, lightweight feedback to prevent intrusiveness); demonstrate adaptability via visible error recovery; design collaborative cues (natural dialogue, shared task ownership — top trust driver predictively); ensure consistent persistence; establish service governance (escalation procedures for failures, clear responsibility boundaries, recurring-issue monitoring); run continuous UGC listening loops.

For practitioners building payment/fintech AI systems: an agent that pays on a user's behalf needs BOTH trait families — instrumental value (autonomous execution, anticipation, goal focus) to generate satisfaction, and relational signals (error recovery, cooperative confirmation dialogue, persistent retry on failed payments) to earn trust before delegation. Critically, when trust and satisfaction clash ("reliable but frustrating"), satisfaction decides retention — so friction-free payment experiences matter even once trust exists.

## Limitations

Acknowledged by authors:
- Single application corpus (Manus AI) limits generalizability; high-stakes domains (healthcare, education, financial services) may elicit different expectations.
- Topic-to-construct mapping required interpretive judgment despite coherence thresholds, sentiment checks, and expert review — potential subjectivity; future work should add supervised classification/crowdsourced validation.
- Individual-user perceptions only; group-level trust, co-agency, shared decision-making, accountability, fairness, explainability flagged as future constructs.

Inferred by me:
- Constructs are measured via topic/sentiment proxies (polarity and subjectivity as dependent variables), not validated psychometric scales — coefficients reflect lexical-affective associations, not survey-grade latent variables; small β magnitudes (e.g., 0.011–0.019) coexist with huge F-statistics driven by n≈52k.
- Self-selection bias: reviewers are motivated app-store users; ratings skew positive (top tokens are praise words).
- No demographic or behavioral ground truth (actual retention/churn) — outcome is stated intention proxies; no causal identification.
- Manus AI is an early-stage product; review valence may reflect novelty effects and app bugs rather than stable trait perceptions.

## Relevance to Our Hackathon

Directly actionable for consumer adoption of a Razorpay-track payment agent:

1. **Trait checklist for the payment agent UX**: ship demonstrable autonomy (multi-step checkout without hand-holding), proactivity (suggest bill reminders/reorder payments before due dates), goal-directedness (show progress toward user goals like "save ₹X/month") — these drive satisfaction, which is the strongest continuance lever (XGBoost importance 0.756).
2. **Trust-building features ranked**: collaboration cues matter most predictively (importance 0.679) — implement conversational confirmations where the agent works "with" the user ("I found this bill; approve?"); adaptability second (visible error recovery when a payment fails, auto-retry with alternate rail); persistence third (consistent retry until success).
3. **Trust-gate then satisfaction-loop rollout**: sequence onboarding so users first reach the "threshold of acceptability" for autonomous action (small low-risk autopay tasks with verification cues — note the paper's own Trust lexicon included "verification", "account", "sms"), then optimize the loop for experiential smoothness to drive retention.
4. **UGC listening loop as hackathon analytics**: replicate their exact pipeline (langdetect → NLTK/spaCy preprocessing → LDA coherence >0.35 → VADER/TextBlob → PLSr+XGBoost) on reviews of existing Indian payment apps to mine which "agentic" features users already demand — a cheap, judge-impressive data story.
5. **Override controls prevent reactance**: proactivity "should remain controllable, with clear user override options" — aligns with DPDP-style consent: every proactive debit suggestion needs a lightweight decline/undo.
6. **Service governance**: escalation procedures for failed agent payments and clear responsibility boundaries (agent vs platform vs bank) map onto dispute-resolution requirements for delegated transactions.
