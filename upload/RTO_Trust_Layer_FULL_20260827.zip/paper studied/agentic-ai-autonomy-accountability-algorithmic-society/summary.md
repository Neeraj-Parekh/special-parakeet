# Agentic AI: Autonomy, Accountability, and the Algorithmic Society

| Field | Value |
|---|---|
| **Authors** | Anirban Mukherjee (Principal, Avyayam Holdings); Hannah Hanwen Chang (Associate Professor of Marketing, Lee Kong Chian School of Business, Singapore Management University) |
| **Venue / Year** | arXiv preprint (2502.00289), 16 February 2025 |
| **Type** | preprint (conceptual / position paper) |
| **DOI / URL** | arXiv identifier 2502.00289 (from source PDF filename; no DOI printed in text) |
| **Processed** | 2026-08-26T05:29:27Z |
| **Source PDFs** | 2502.00289.pdf — sha256 4e3efef2 |

> Version 1 — generated from extracted PDF text.

## Abstract

> "Agentic Artificial Intelligence (AI) systems can autonomously pursue long-term goals, make decisions, and execute complex, multi-turn workflows. Unlike traditional generative AI, which responds reactively to prompts, agentic AI proactively orchestrates processes, such as autonomously managing complex tasks or making real-time decisions. This transition from advisory roles to proactive execution challenges established legal, economic, and creative frameworks. In this paper, we explore challenges in three interrelated domains: creativity and intellectual property, legal and ethical considerations, and competitive effects. Central to our analysis is the tension between novelty and usefulness in AI-generated creative outputs, as well as the intellectual property and authorship challenges arising from AI autonomy. We highlight gaps in responsibility attribution and liability that create a 'moral crumple zone'—a condition where accountability is diffused across multiple actors, leaving end-users and developers in precarious legal and ethical positions. We examine the competitive dynamics of two–sided algorithmic markets, where both sellers and buyers deploy AI agents, potentially mitigating or amplifying tacit collusion risks. We explore the potential for emergent self-regulation within networks of agentic AI—the development of an 'algorithmic society'—raising critical questions: To what extent would these norms align with societal values? What unintended consequences might arise? How can transparency and accountability be ensured? Addressing these challenges will necessitate interdisciplinary collaboration to redefine legal accountability, align AI-driven choices with stakeholder values, and maintain ethical safeguards. We advocate for frameworks that balance autonomy with accountability, ensuring all parties can harness agentic AI's potential while preserving trust, fairness, and societal welfare."

Keywords: Agentic Artificial Intelligence, AI Self-Governance, Autonomous Decision-Making, Creative Problem-Solving, Novelty–Usefulness Trade-Off, Two–sided Algorithmic Collusion. JEL: D83, L86, K12, M31, O33.

## Plain-Language Restatement

AI is moving from tools that answer questions to agents that act on their own — booking trips, negotiating prices, executing workflows end-to-end without a human approving each step. The authors argue this breaks existing rules in three areas: who owns what an AI creates, who pays when an autonomous agent causes harm, and whether markets stay fair when both buyers and sellers are algorithms. Their key metaphors are the "moral crumple zone" (blame lands on the human user or low-level operator who had the least control) and the "accountability vacuum" (responsibility evaporates entirely). They close by asking whether networks of agents might develop their own self-governing norms — an "algorithmic society" — and warn those norms may not align with human values.

## Problem Statement

The paper addresses the gap between legal/economic frameworks built for reactive, prompt-driven generative AI (or for explicitly programmed software) and agentic AI systems that autonomously plan multi-step strategies, adapt to unforeseen conditions, and finalize decisions without iterative human approval ("complete agency" vs. "partial agency"). It matters because: (a) IP law presupposes meaningful human control over outputs (U.S. Copyright Office 2023 policy; Thaler v. Vidal 2022 rejecting AI inventorship); (b) tort/agency law requires a traceable human decision-maker, which opaque RL-trained agents defeat; (c) antitrust doctrine targets explicit collusion among humans, not emergent collusion among learning agents; and (d) no governance model exists for emergent norms in agent networks.

## Methodology

This is a conceptual/interdisciplinary analysis, not an empirical study. No datasets, algorithms trained, or statistical tests are reported. Approach:
- **Running example**: an agentic travel assistant that autonomously builds itineraries, books flights/hotels, negotiates with tour operators, and re-plans on disruptions (contrasted with a conventional chatbot).
- **Legal-doctrinal analysis** of copyright/patent cases and policies: U.S. Copyright Office 2023 guidance (88 FR 16190), Thaler v. Vidal, 43 F.4th 1207 (Fed. Cir. 2022), EPO J 8/20 (2021), Thaler v Comptroller [2021] EWCA Civ 1374, South African Patent No. 2021/03242 (DABUS granted, formality-only examination), Australian Federal Court 2021 reversed by Full Federal Court 2022 (Commissioner of Patents v. Thaler [2022] FCAFC 62), Burrow-Giles Lithographic Co. v. Sarony (1884).
- **Theory synthesis**: responsibility gap (Matthias 2004), moral crumple zone (Elish 2019), accountable algorithms (Kroll et al. 2017), Pasquale's black box.
- **Game-theoretic reasoning**: repeated Bertrand competition, Prisoner's Dilemma vs. Folk Theorem (Fudenberg & Maskin 1986), grim-trigger punishment (Friedman 1971; Green & Porter 1984), Q-learning's propensity to collude (Watkins & Dayan 1992; Klein 2019; Calvano et al. 2020). Two thought-experiment scenarios for two-sided agent markets (collusion sustained vs. collusion disrupted by buyer-agent demand withholding).
- **Governance analysis**: social laws for agent societies (Shoham & Tennenholtz 1995), norm emergence simulations (Sen & Airiau 2007), commons governance (Ostrom 1990), cooperative AI (Dafoe et al. 2021).

## Key Results

Conceptual paper — key claims/frameworks rather than measured results:

1. **Novelty–usefulness tension amplified**: Agentic AI autonomously finalizing outputs makes it the "de facto creator"; when training data and commissioners are also AI, tracing the "creative spark" to a human becomes tenuous. Perverse incentives: humans stop investing in creativity that yields no royalties; developers cannot hold IP in AI output either → risk of a "creative dark age" where cultural abundance legally belongs to nobody but economically enriches corporate stewards.

2. **Accountability vacuum / moral crumple zone**: Developers disclaim via "the AI acted autonomously at the user's request"; users lack insight into opaque RL-learned behavior; nobody can be straightforwardly liable. Illustrative failure-rate figures cited: ~90% of startups eventually fail (Startup Genome 2019); 70–80% of new product launches miss revenue targets (Gourville 2006) — innovation implies failure, so agent-caused failures are likely, not edge cases.

3. **Two-sided algorithmic markets** (the paper's novel economic contribution):
   - Scenario 1 (Collusion Sustained): buyer agents pounce on any price cut; rival seller AI retaliates with sustained below-cost cuts (grim trigger); agents learn to keep prices high — tacit collusion without communication.
   - Scenario 2 (Collusion Disrupted): buyer AIs deliberately shift only part of demand, denying defectors a big win and weakening punishment credibility — potentially destabilizing collusion and pushing prices toward competitive levels.
   - Implication: unlike myopic human consumers, forward-looking buyer agents change equilibrium logic; one-sided algorithmic-market models do not transfer.

4. **Algorithmic society risks**: emergent norms could entrench bias, create a de facto "AI cartel," exploit regulatory loopholes, and resist external intervention once equilibria solidify; designed "social laws" raise questions of who defines/enforces them across jurisdictions.

5. Policy directions floated: monitoring for algorithmic harmonization, auditing AI decision-making logic, regulatory sandboxes for pricing strategies, structural separation between consumer-side and supplier-side agent providers (with acknowledged innovation trade-offs).

## Conclusions & Implications

Authors' conclusions: agentic AI decouples creativity from legal-economic moorings (IP must be rethought: contribution tracking, attribution standards, dynamic hybrid-authorship royalties); accountability requires new frameworks ensuring fairness, transparency, and traceability since consent and oversight break down under full autonomy; antitrust tools need updating for two-sided algorithmic markets; bottom-up agent self-governance needs built-in ethical constraints, transparent oversight, and dynamic recalibration mechanisms.

For practitioners building payment/fintech AI systems: 
- Design decision logs and contestability into agentic products from day one — the paper argues post-hoc accountability fails when behavior is learned, not programmed.
- Consent UX must confront genuine opacity: a user "consent" screen does not equal informed consent over an agent's autonomous multi-step choices (insurance, cancellation policies, non-refundable bookings are the paper's examples — directly analogous to agent-initiated payments).
- If your platform hosts both merchant-side and consumer-side agents, expect emergent pricing dynamics (including tacitly collusive equilibria) and consider audit hooks/sandbox testing before wide-scale deployment.

## Limitations

Acknowledged by authors:
- Most advanced agentic AI systems are still in testing with very limited real-world deployment, so claims about emergent norms rest on simplified simulation evidence (e.g., Sen & Airiau 2007 side-of-the-road game).
- Norm-emergence simulations abstract from developer override capability; real-world agent norms are neither purely autonomous nor irreversible.
- The two-sided market analysis is presented as intuition-building thought experiments, not formal proofs or experiments.

Inferred (by me):
- No empirical data, model runs, or citations of actual deployed agentic payment/commerce systems; all economic arguments are theoretical scenarios.
- Legal analysis is US/UK/EU/AU-centric; no discussion of Indian or other emerging-market law relevant to fintech builders.
- The paper predates (and does not engage) concrete protocols like AP2/mandate architectures that now address parts of its consent/attribution problem.

## Relevance to Our Hackathon

Directly frames three hackathon angles:

1. **Consent UX & explainability duties**: The paper's core argument — that per-decision informed consent is impossible for opaque autonomous agents — motivates our design of layered consent (mandate-level authorization + per-transaction visibility + human escalation) and explainability artifacts (why was this RTO-blocking/loan-decision made). Its "moral crumple zone" warns against dumping liability onto merchants/users while the platform profits from agent autonomy — a strong narrative for merchant-aggregator-bank liability allocation demos.

2. **Audit trails as the fix for the accountability vacuum**: Since RL-learned agent decisions resist ex-post reconstruction, the paper implicitly demands tamper-evident decision logging and contestability (Kroll et al.'s "accountable algorithms") — exactly the agent-driven payment mandate audit trail we propose building for Razorpay-track systems.

3. **Two-sided agent markets**: Razorpay sits between merchants (seller agents) and consumers (increasingly buyer agents). Our fraud/RTO models and pricing logic will interact with counterpart bots; the collusion-sustained/disrupted scenarios suggest monitoring features (detecting algorithmic price harmonization) and sandboxed rollout of agentic pricing — a differentiating demo module.

4. **Liability allocation language**: Terms from this paper (responsibility gap, accountability vacuum) supply the vocabulary for our merchant/aggregator/bank liability-matrix deliverable.
