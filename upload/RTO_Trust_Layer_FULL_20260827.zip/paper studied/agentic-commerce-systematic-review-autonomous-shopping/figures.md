# Figures & Tables — Agentic Commerce: Systematic Review of AI-Driven Autonomous Shopping (Halat 2026)

**Source:** oleh-halat-126h-1.pdf (sha256 cdafe19d, 21 pages, text_sha256 07c9e15e). Primary key dfe74fe5b67b. Duplicate keys 721e9a8f2b8b / 17dac945d09e / 0d267117ffbf are byte-identical and excluded from visual review per spec (primary images cover all content). Images examined: `page_006.png` (p6), `page_007.png` (p7), `page_008.png` (p8), `page_009.png` (p9), `img_p007_22.png` (embedded crop of Fig.1 p7).

**Overall assessment:** Paper contains **1 figure (PRISMA flow diagram)** and **3 tables**. No charts, graphs, photos, or quantitative plots. All visuals are vector manuscript tables / flowchart boxes rendered via Word-like typesetting — no matplotlib/gnuplot/raster screenshots. Quality is functional but low-production-value: standard blue-header table style repeated every page, same CC-BY + ISSN footer on every page, Figure 1 uses thin black box borders with flat fills. Resolution is crisp (vector) — nothing blurry or cropped when read at full-page scale; embedded crop `img_p007_22.png` (1284×1541) confirms figure legibility. No watermarks. Table 2 is split awkwardly across a page break (header at bottom of p8, continuation on p9) — layout artefact typical of non-typeset journal, not a data error.

---

## Figure 1 — PRISMA 2020 flow diagram (page 7, also as `img_p007_22.png`)

- **Type:** Flowchart / PRISMA 2020 study-selection diagram (boxes + arrows, 5 vertical stages, 2 columns).
- **Construction:** Vector flowchart (PowerPoint/Word/PRISMA template style). Horizontal top bar "Identification of studies via databases and registers" with peach fill + purple border and rounded corners. Left-side vertical bars (light blue) labeling three super-stages: Identification, Screening, Included. Main boxes: thin black rectangular borders, white fill, black sans-serif text. Arrows are thin black lines with solid arrowheads.
- **Legend / axes / units:** No axes. Boxes labeled by stage; right-column boxes describe exclusions. Footnote markers: `*` = "Databases (n=1,170...)" and `**` = records excluded at screening (no title expansion shown in figure; text in body explains). Colour coding is purely structural, not a data legend.
- **Concrete numbers (readable exactly as shown):**
  - `Records identified from*: Databases (n=1,170; incl. 1,050 from databases and 120 from citation searching) — Registers (n=0)`
  - `Records removed before screening: Duplicate records removed (n=220) — Records marked as ineligible by automation tools (n=0) — Records removed for other reasons (n=0)`
  - `Records screened (n=950) → Records excluded** (n=820)`
  - `Reports sought for retrieval (n=130) → Reports not retrieved (n=0)`
  - `Reports assessed for eligibility (n=130) → Reports excluded: Not focused on agentic/autonomous system (n=40), Absence of transaction/commerce-related protocols (n=28), Conceptual/opinion-based with insufficient analytical depth (n=20), etc.`
  - `Studies included in review (n=42) — Reports of included studies (n=42)`
  - **Cross-check:** 1,170 − 220 = 950; 950 − 820 = 130; 130 − 88 (40+28+20) = 42 — arithmetic reconciles exactly. Text claims "numerical values fully reconciled and consistent across all sections" — figure confirms it.
- **Quality/editing:** Crisp vector at 1284×1541 embedded resolution. No blur, no cropped text. Fonts consistent (Arial/Calibri-like). Minor editing quirk: empty boxes for `n=0` cases still displayed (Registers, automation-marked, not-retrieved) — PRISMA template boilerplate left in, not an error but verbose. Overall placement centered, caption below reads "Figure 1. PRISMA 2020 flow diagram of the study identification, screening, eligibility, and inclusion process" in italics.
- **Supports/contradicts summary.md claim:** Directly supports Methodology PRISMA counts and Key Results inclusion figure (42) and the claim of full numeric reconciliation. No contradiction.

---

## Table 1 — Inclusion and Exclusion Criteria (page 6, rendered in `page_006.png`)

- **ID/page/type:** Table 1, page 6, data table (7-row, 2-column eligibility matrix).
- **Construction:** Manuscript table, blue header row (`Inclusion Criteria` / `Exclusion Criteria`) with white text, alternating light-blue and white row fills, thin grid lines. Word-style, not a plotted figure.
- **Axes/legend/units:** Two text columns; no numeric units.
- **Content (readable verbatim, row-by-row):**
  1. Peer-reviewed journal articles — vs — Non-peer-reviewed publications
  2. Conference proceedings — vs — Books and book chapters
  3. English-language studies — vs — Non-English publications
  4. Indexed in Scopus/Web of Science/IEEE — vs — Non-indexed or informal sources
  5. Focus on AI, agentic systems, or e-commerce. — vs — Irrelevant to AI or commerce
  6. Published 2020–2026 — vs — Outside timeframe
  7. Full-text accessible studies — vs — Inaccessible or incomplete records
- **Concrete numbers:** None (categorical).
- **Quality/editing:** Fully legible. Minor textual nuance: row 4 in body text says "indexed in major citation databases (Scopus, WoS, IEEE, and others)" while table simplifies to "Indexed in Scopus/Web of Science/IEEE" — difference is elision, not contradiction. No blur, no watermark, aligned.
- **Supports summary.md:** Supports Methodology inclusion/exclusion list; summary.md's abridged 6-point version is accurate but omits Conference/Books distinction (which is captured here — verification fix applied).

---

## Table 2 — Publication Distribution of Reviewed Studies (2020–2026) (pages 8–9, rendered across `page_008.png` bottom + `page_009.png` top)

- **ID/page/type:** Table 2, pages 8–9 (split across page break), data table (5-column distribution).
- **Construction:** Same blue-header manuscript table. Columns: [Period | Number of Studies | Dominant Research Focus | Nature of Contributions | Representative Included Studies]. Vector text.
- **Axes/legend/units:** Count units are integers (n studies); no chart axes.
- **Concrete numbers (exactly as read):**
  - Row 2020–2022: n=2 — AI-enabled e-commerce, recommendation systems, predictive analytics — Nature: Empirical foundation studies — Representative: Bawack et al. (2022)
  - Row 2023–2024: n=2 — Generative AI, conversational commerce, multi-agent collaboration — Nature: Empirical and simulation studies — Representative: Sharma & Dey (2023); Zhang, X. et al. (2025) *(note: Zhang X 2025 appears date-anomalous but is listed as 2025 in this row)*
  - Row 2025–2026: n=38 — Agentic AI, autonomous shopping systems, AI transaction protocols, governance frameworks — Nature: Predominantly conceptual and framework-based — Representative: Gupta (2025); Dusad (2025); Kodali (2025); Chinnaraju (2026); Balaskas (2026); Sotiya et al. (2026); Zhang, Y. et al. (2026)
  - Total: 42 — — — —
- **Headline takeaway:** 90.5% of corpus (38/42) in 2025–2026, confirming field consolidated only in most recent period. 2020–2024 combined only 4 studies.
- **Quality/editing:** Functional but editorial flaw: table is split across page break — header and first two rows on p8, remaining rows on p9 — causing "commerce, multi-agent collaboration" orphan line at top of p9 that belongs to 2023–2024's Dominant Focus cell. No numbers lost; stitching confirms totals. Text not blurry. Representative study list uses semicolons consistently.
- **Supports summary.md:** Supports Key Results period split and statement "38 of 42 between 2025–2026". Verbatim match. No contradiction.

---

## Table 3 — Classification of Research Contributions (page 9, rendered in `page_009.png` lower half)

- **ID/page/type:** Table 3, page 9, data table (4-column classification with percentages).
- **Construction:** Same blue-header style. Columns: [Type of Contribution | Number of Studies | Percentage (%) | Representative Included Studies].
- **Axes/legend/units:** Percentage units to one decimal place.
- **Concrete numbers (exactly as read):**
  - Conceptual/Framework Development: n=28, 66.7% — Representative: Dusad (2025); Kodali (2025); Bandi et al. (2025); Chinnaraju (2026); Basu (2026); Balaji (2026)
  - Empirical Studies: n=8, 19.0% — Representative: Bawack et al. (2022); Sharma & Dey (2023); Al-Sharafi et al. (2026); Hasselwander et al. (2026)
  - Experimental/Simulation-Based Studies: n=6, 14.3% — Representative: Trivedi (2025); Mansour et al. (2025); Yadav (2025); Sotiya et al. (2026); Sharma, A. G. et al. (2026); Zhang, X. et al. (2025)
  - Total: 42, 100.0%
- **Headline takeaway:** Two-thirds conceptual/framework (66.7%), under one-fifth empirical, small simulation share — evidence field is exploratory, matches ACIAF maturity "lower levels" interpretation on p9 lines 596–606.
- **Quality/editing:** Crisp vector. Percentages sum 100.0 exactly; 28+8+6=42; cross-checked. Representative study "Zhang, X. et al. (2025)" appears in both Table 2 (2023–2024) and Table 3 (as experimental) — consistent categorisation, date mismatch with row label is preserved as in source (not an extraction error). Caption italicised correctly.
- **Supports summary.md:** Supports Key Results contribution-type table verbatim; numbers were rendered correctly in summary.md v1.

---

## Page-level rendering notes (for audit trace)

- `page_006.png`: page 6 capture includes full Table 1 plus surrounding paragraphs (Screening/Eligibility/Inclusion counts 820/130/88/42, Inclusion/Exclusion definitions, Data Extraction fields). No other figure on page. Legibility: high.
- `page_007.png`: page 7 capture includes full analytical framework text (three readiness dimensions, five modules, four-level maturity, three-tier KPI) plus entire Figure 1 PRISMA diagram and caption. Legibility: high.
- `page_008.png`: page 8 capture includes small top line re PRISMA integrity, then Results → Overview literature paragraph block plus beginning of Table 2 (header + rows through 2023–2024). Captures stitch point correctly.
- `page_009.png`: page 9 capture includes continuation of Table 2 (2025–2026 + Total) plus three paragraphs of interpretation plus full Table 3 and footer licence. Confirms no truncation.
- `img_p007_22.png`: embedded extracted crop of Figure 1 at native resolution 1284×1541, exceeding page render detail — used to confirm all n-values above. No separate figure or table beyond PRISMA.

**Paper-wide observation:** Zero quantitative plots (no line/bar/scatter/heatmap/confusion matrix), zero architecture diagrams, zero photos/screenshots. Systematic review with qualitative synthesis — visuals are purely reporting tables + flow diagram. Absence of performance curves or benchmark tables is itself evidence for summary.md's claim that no effect sizes / no meta-analysis exists in this paper.

