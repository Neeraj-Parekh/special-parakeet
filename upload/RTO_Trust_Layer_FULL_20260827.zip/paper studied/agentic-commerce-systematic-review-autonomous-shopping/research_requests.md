# Research Requests — Agentic Commerce: A Systematic Review (Halat)

- [High] Close the review's evidence gap with measurement: build an agent-checkout simulator producing transaction-level data (mandate fit, delivery outcomes, fraud labels) and publish baseline micro/meso KPIs (fraud rate, RTO rate, dispute latency, step-up rate) that the reviewed literature lacks.
- [High] Implement proof-of-delivery-gated settlement for COD orders (the review's smart-contract use case) and measure effect on simulated RTO losses and courier-fraud attempts vs. pay-on-order baseline.
- [High] Test the review's claim that excess autonomy increases uncertainty: A/B a fully autonomous checkout vs. one with visible confirmation checkpoints; measure user trust ratings, override rates, and error-recovery times.
- [Med] Benchmark automated negotiation protocols: simulate buyer agents vs. merchant pricing agents under dynamic pricing/auction mechanisms; quantify consumer surplus and failure/loop rates across rounds.
- [Med] Evaluate identity-impersonation resistance: attempt spoofing attacks against API-key vs. signed-mandate agent authentication in a mock marketplace; report attack success rates.
- [Med] Quantify privacy barrier impact: vary the breadth of data access granted to a shopping agent (minimal vs. full history) and measure recommendation quality gain vs. stated privacy discomfort in a small user study.
- [Low] Replicate the review's bibliometric profile on a 2026+ corpus to test whether empirical studies are overtaking conceptual ones as it predicts is needed.
- [Low] Extend the protocol checklist to Indian rails: map UPI autopay/e-mandates and COD workflows onto the review's four protocol categories and identify which have no agentic equivalent today.
