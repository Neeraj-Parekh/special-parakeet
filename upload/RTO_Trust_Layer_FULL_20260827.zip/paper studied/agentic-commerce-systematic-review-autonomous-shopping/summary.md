# Agentic Commerce: A Systematic Review of AI-Driven Autonomous Shopping and Emerging Transaction Protocols

| Field | Value |
|---|---|
| **Authors** | Oleh Halat (Bachelor's Degree, E-commerce Business Analyst, ALEKO, 8307 S 192nd St, Kent, WA 98032, USA; ORCID 0009-0005-3246-7339) |
| **Venue / Year** | Global Prosperity, Vol. 6, Issue 3 (ISSN 2787-9364), 2026. Submitted 03.06.2026; Accepted 25.06.2026; Published 25.07.2026 |
| **Type** | journal article (systematic literature review, PRISMA 2020) |
| **DOI / URL** | No article DOI stated in text; ISSN 2787-9364 |
| **Processed** | 2026-08-26T05:29:16Z (v2 verified 2026-08-26) |
| **Source PDFs** | oleh-halat-126h-1.pdf (sha256 cdafe19d) [+ three byte-identical copies: oleh-halat-126h.pdf, -126h-2.pdf, -126h-3.pdf] |

> Version 2 — v2 full-read verification pass (word-by-word against all 4 byte-identical source txts + visual figure review).

> **Venue-quality caveat (inferred by me):** single-author review by a bachelor-level industry analyst (Bachelor's Degree as stated on title page) in a low-visibility outlet; the corpus is dominated by recent conceptual/preprint-style works. The PRISMA process itself is reported carefully and Figure 1 arithmetic fully reconciles (1170→950→130→42), but findings should be treated as a structured map of an immature literature rather than validated evidence.

## Abstract
> "This study presents a systematic literature review of agentic commerce, with particular emphasis on autonomous shopping systems, machine-to-machine transaction protocols, and the governance conditions necessary for their large-scale adoption. Rapid advances in large language models, generative artificial intelligence, and autonomous agent architectures are transforming digital commerce by enabling intelligent agents to search for and assess products, compare suppliers, negotiate transaction terms, execute purchases, coordinate logistics, and manage post-purchase activities with limited human involvement. Despite increasing academic and industry interest, the relevant literature remains fragmented across e-commerce, information systems, artificial intelligence, cybersecurity, digital governance, and consumer behavior research. Following the PRISMA 2020 methodology, this review examines studies published between 2020 and 2026 and retrieved from Scopus, Web of Science, IEEE Xplore, ScienceDirect, SpringerLink, and the ACM Digital Library, supplemented by searches of Google Scholar and arXiv. Following identification, deduplication, screening, eligibility assessment, and quality appraisal, 42 studies were included in the qualitative synthesis. The evidence was analyzed using the AI-Commerce Integration Assessment Framework, which enabled systematic interpretation of the literature across the dimensions of readiness, feasibility, performance, and maturity. The findings indicate a clear transition from AI-assisted product discovery and recommendation systems toward increasingly autonomous purchasing environments in which AI agents operate as active economic actors. However, broader adoption remains limited by concerns related to trust, privacy, transparency, accountability, cybersecurity, user control, and legal responsibility. The review also identifies emerging infrastructures for digital identity, authentication, interoperability, automated negotiation, smart contracts, payment settlement, and dispute resolution. Nevertheless, these mechanisms remain weakly standardized and insufficiently interoperable across platforms and jurisdictions. Overall, agentic commerce is conceptualized as a transition from human-centered digital transactions toward AI-mediated economic ecosystems. Its sustainable development will depend on the coordinated evolution of technical standards, governance structures, explainable AI, consumer protection mechanisms, accountability frameworks, and secure transaction infrastructures. This review provides an integrated synthesis of the field and identifies priorities for future empirical research on real-world implementation, interoperability, regulation, market effects, and human–AI collaboration."

(Keywords: agentic commerce, AI-driven autonomous shopping, emerging transaction protocols.)

## Plain-Language Restatement
This paper rounds up 42 academic studies on AI agents that shop autonomously and the payment/transaction plumbing they need. It finds the field only recently exploded (38 of 42 studies are from 2025-2026), is mostly concepts and frameworks rather than real-world tests, and shows a shift from AI that recommends products to AI that buys them itself ("invisible commerce"). The big blockers are trust in opaque decisions, privacy, unclear liability when agents err, and cyberattacks like fake or manipulated agents. The needed infrastructure — agent identity, authentication, interoperability standards, smart contracts, automated negotiation — exists only in fragments without common standards.

## Problem Statement
Research on agentic commerce is scattered across e-commerce, information systems, AI, cybersecurity, governance, and consumer behavior; prior work covers AI implementation, recommenders, trust, and market design but none combine autonomy, transaction execution, and governance structures. Without a systematic synthesis, innovations outpace formal cataloguing and theorizing. The review answers four questions: (RQ1) AI's role in commercialisation of the Internet and impact on consumer behavior; (RQ2) challenges to acceptance; (RQ3) transaction protocols/frameworks supporting autonomous commerce; (RQ4) key future research directions.

## Methodology
- **Design**: systematic literature review following PRISMA 2020; qualitative thematic synthesis as principal method; bibliometrics supplementary/descriptive only.
- **Databases**: Scopus, Web of Science, IEEE Xplore, ScienceDirect, SpringerLink, ACM Digital Library; supplemented by Google Scholar and arXiv. Search window: publications 2020-2026; searches run 1-10 June 2026 (last updated 10 June 2026).
- **Query** (titles/abstracts/keywords, adapted syntax per database): ("agentic commerce" OR "autonomous shopping" OR "AI shopping agents") AND ("artificial intelligence" OR "large language models" OR "multi-agent systems") AND ("e-commerce" OR "digital commerce" OR "online retail systems").
- **PRISMA flow (as reported)**: Identification: 1,050 database records + 120 via forward/backward citation searching = 1,170. Deduplication: 220 removed -> 950 screened. Screening: 820 removed -> 130 full-text. Eligibility: 88 excluded (n=40 not agentic/autonomous commerce; n=28 no transaction/commerce frameworks; n=20 opinion-based/insufficient analysis). Inclusion: **42 studies** in qualitative synthesis.
- **Screening reliability**: two reviewers independently screened titles/abstracts/full texts; disagreements resolved by discussion, with a third reviewer adjudicating where consensus failed.
- **Quality appraisal**: items adapted from CASP and JBI checklists applied independently by both reviewers; below-threshold studies excluded at full-text stage.
- **Data extraction fields**: authors/year, study location, AI system type (assistive / semi-autonomous / fully autonomous), commerce type (retail/fintech/e-commerce systems), transaction type (recommend / partially execute / fully execute), technology type (LLMs, multi-agent systems, APIs, blockchain protocols), findings and constraints.
- **Analytical lens**: the author's own AI-Commerce Integration Assessment Framework (ACIAF, Halat 2025): three readiness dimensions (data infrastructure, technical systems, organisational state); five analytical modules (readiness assessment; opportunity identification & prioritisation; feasibility evaluation; performance specification; optimisation feedback); a four-level maturity model; three-tier KPI architecture (micro/meso/macro).

## Key Results
Quantitative results reported by the review:

**Publication distribution (Table 2):**

| Period | Studies | Dominant focus |
|---|---|---|
| 2020-2022 | 2 | AI-enabled e-commerce, recommenders, predictive analytics |
| 2023-2024 | 2 | Generative AI, conversational commerce, multi-agent collaboration |
| 2025-2026 | 38 | Agentic AI, autonomous shopping, AI transaction protocols, governance |

**Contribution types (Table 3):**

| Type of contribution | n | % |
|---|---|---|
| Conceptual/Framework development | 28 | 66.7 |
| Empirical studies | 8 | 19.0 |
| Experimental/Simulation-based | 6 | 14.3 |

ACIAF interpretation: field sits at lower maturity levels; more readiness reported on technical systems than on organisational state and data governance (the dimensions Halat associates with implementation failure).

**RQ1 (behavior/transactions)**: transition from consumer-driven search to goal-oriented autonomous shopping; agents perform discovery, evaluation, supplier comparison, price negotiation, transaction execution, logistics coordination, post-purchase support; machine-mediated negotiation reduces transaction costs; personalization becomes continuous/contextual; acceptance depends on perceived usefulness, trust, ease; trend toward "invisible commerce" where transactions occur with minimal consumer intervention.

**RQ2 (adoption barriers)**: most frequently reported barrier is trust in opaque decision-making (users can't see how alternatives are evaluated/prioritized); privacy/data security (extensive access to behavioral, financial, contextual data; surveillance concerns); accountability/liability gaps (frameworks designed for human-centred transactions give limited guidance for errors, losses, fraud, unintended outcomes); cybersecurity threats (malicious agent manipulation, automated fraud, identity impersonation, unauthorized machine-to-machine transactions); discomfort relinquishing financial control. Notably: "increasing levels of automation do not necessarily reduce transactional friction" — excess autonomy generates new uncertainty.

**RQ3 (protocols)**: foundational categories identified — (1) authentication and digital identity protocols; (2) communication/interoperability protocols (absence of universal standards flagged as major limitation); (3) blockchain-enabled transaction infrastructures and smart contracts automating contract execution, payment settlement, escrow services, and proof-of-delivery verification without direct human oversight; (4) automated negotiation protocols (dynamic pricing, auction mechanisms, multi-round negotiations, contract optimisation). Persistent finding: mechanisms are weakly standardized and not interoperable across platforms/jurisdictions; studies "seldom specify the performance criteria required to govern these protocols before deployment" (the micro/meso/macro KPI gap).

**RQ4 (future directions)**: human-AI collaborative/hybrid oversight models; interoperability and standardization; regulatory governance (legal accountability, consumer protection, ethical deployment); explainable AI; socioeconomic effects (competition, pricing behavior, labor markets, consumer welfare, market concentration, digital inequality); extension to sectors like tourism/hospitality; cybersecurity resilience of autonomous economic infrastructure.

## Conclusions & Implications
Authors' claims: agentic commerce is a fundamental transformation in the allocation of decision-making authority within digital markets, not an incremental e-commerce enhancement; existing adoption/ecommerce theory assumes humans remain primary decision-makers and must be reworked for environments where agents act independently. Success will be determined by co-evolution of technical innovation and institutional governance (governance structures, accountability mechanisms, trust infrastructures, regulation). The field needs to move beyond conceptual discussion to empirical, longitudinal, real-world validation.

For practitioners building payment/fintech AI systems: the review's protocol taxonomy is effectively a checklist of what an agentic-payments platform must supply — machine identity/authentication, interoperable communication, settlement/escrow/dispute primitives (smart-contract style), and negotiation interfaces — plus the warning that none of these have settled standards yet, so early implementations become de facto standards. Its evidence-gap finding also licenses hackathon projects that produce actual measurements rather than another concept note.

## Limitations
Acknowledged by authors (Discussion p13, lines 853-861, verbatim):
- Based exclusively on secondary literature and therefore reflects current state of scholarly knowledge rather than direct observations of large-scale commercial deployments.
- Field of agentic commerce is evolving rapidly, meaning technological developments may outpace existing academic research.
- Many reviewed studies rely on conceptual models, simulations, or experimental environments, limiting generalizability of findings to real-world commercial settings.
- Only English-language publications considered, which may have excluded relevant contributions (confirmed in text: 4th limitation).

Inferred by me:
- Corpus quality skew: 66.7% conceptual contributions (28/42, Table 3 — verified against figure), several in low-visibility venues/preprints; the review's own conclusions inherit that evidential weakness. ACIAF maturity reading places field at lower maturity levels, with more progress on technical systems than organisational state/data governance — dimensions Halat (2025) says most associated with implementation failure.
- Use of the author's own (self-published) ACIAF framework (Gutenberg, Kyiv, 2025) as the analytic lens creates circularity risk; no independent validation of framework is presented.
- No meta-analysis possible (qualitative synthesis only; bibliometrics supplementary/descriptive only per p7 line 389); no effect sizes, no p-values, no performance benchmarks anywhere — consistent with paper containing zero quantitative plots/tables beyond counts.
- Protocol landscape (AP2/x402/MPP etc.) is treated generically in source; named current protocols are largely absent from synthesized corpus and from Tables 1-3/Figure 1.
- Venue: single-author, bachelor-level analyst; journal not indexed in major citation claims of quality; informal layout (Table 2 split across page break) signals low production standards but does not affect numeric integrity (all counts reconciled).

## Figures & Tables
Visual inventory verified against rendered pages (primary key dfe74fe5b67b: page_006.png, page_007.png, page_008.png, page_009.png, img_p007_22.png); duplicates skipped. See `figures.md` for full deep-dive and `tables.csv` for machine-readable extracts.

- **Table 1 (p6, data table):** Inclusion vs Exclusion criteria — 7 paired rows (Peer-reviewed vs Non-peer-reviewed; Conference proceedings vs Books; English vs Non-English; Indexed vs Non-indexed; Focus AI/e-commerce vs Irrelevant; Published 2020-2026 vs Outside timeframe; Full-text accessible vs Inaccessible). No numeric takeaway; defines eligibility frame for the 42-study corpus.
- **Figure 1 (p7, PRISMA 2020 flowchart):** Complete selection pipeline — 1,170 records identified (1,050 DB + 120 citation) → 220 duplicates removed → 950 screened → 820 excluded → 130 reports sought/assessed → 88 excluded at eligibility (40 not agentic + 28 no tx framework + 20 insufficient/opinion) → 42 studies included (100% retrieval rate; all exclusions itemised; arithmetic fully reconciles).
- **Table 2 (p8-9, data table):** Publication distribution 2020-2026 — 2020-2022: 2 studies (AI-enabled e-commerce/recommenders), 2023-2024: 2 (Generative AI/conversational/multi-agent), **2025-2026: 38/42 (90.5%)** Agentic AI/autonomous shopping/governance — headline confirms consolidation as distinct field only in most recent period.
- **Table 3 (p9, data table):** Research contribution types — **Conceptual/Framework 28 (66.7%), Empirical 8 (19.0%), Experimental/Simulation 6 (14.3%), Total 42 (100%)** — dominance of conceptual work maps to lower ACIAF maturity levels and limited real-world validation.

No other figures; no charts/plots/photos/screenshots in source — absence itself evidences "no effect sizes" claim.

## Relevance to Our Hackathon
Useful as the map + legitimacy source for the Razorpay track:
- **Protocol checklist for our demo**: RQ3's categories (agent identity/authentication, interoperable messaging, escrow/settlement, dispute resolution, proof-of-delivery verification, automated negotiation) are exactly the modules of an agent-checkout reference architecture — we can structure our build around them and cite this review as evidence each module is recognized as critical but unstandardized.
- **Proof-of-delivery verification**: the review explicitly flags smart contracts for proof-of-delivery and escrow without human oversight — a direct hook for an RTO-reduction feature: release COD settlement only on verified delivery events.
- **Trust & consent UX**: its top adoption barriers (opacity of decisions, loss of control) justify our trust-score surface and mandate controls as adoption features, not just security features; "invisible commerce" framing helps pitch why buyers need visible guarantees when transactions become invisible.
- **Fraud/RTO angle**: it catalogs malicious-agent manipulation, identity impersonation, and unauthorized M2M transactions as adoption-critical threats — supporting our fraud model's treatment of agent-initiated orders as a distinct risk class with impersonation-resistant authentication (signed mandates) at intake.
- **KPI gap = scoring opportunity**: the finding that studies "seldom specify performance criteria... before deployment" means defining micro (transaction-level fraud/RTO rates), meso (dispute latency, step-up rate), macro (trust index) KPIs for agentic checkout is itself a novel, citable contribution we can implement.
- **Evidence positioning**: because the field is 66.7% conceptual, any measured results we show (even on synthetic data) are differentiated contributions.
