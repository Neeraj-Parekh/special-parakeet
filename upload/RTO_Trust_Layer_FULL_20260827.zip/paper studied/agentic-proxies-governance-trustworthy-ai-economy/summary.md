# Agentic Proxies: Governance, Accountability, and the Architecture of a Trustworthy AI Economy

| Field | Value |
|---|---|
| **Authors** | Geoff Lundholm (Kindred Systems OS Ltd.; author discloses founder role and commercial interest in the framework's adoption) |
| **Venue / Year** | SSRN working draft ("Working Draft — June 2026"), 47 pp. |
| **Type** | preprint (working paper / framework paper) |
| **DOI / URL** | (not stated in text; companion repo referenced: github.com/Cleave360/adaptive_layer) |
| **Processed** | 2026-08-26T05:29:27Z |
| **Source PDFs** | ssrn-6952119.pdf — sha256 8fabbf9e |

> Version 1 — generated from extracted PDF text.

## Abstract

> "Three claims organise this paper. First: the emerging accountability problem in AI is not human-to-AI interaction. It is AI-to-AI delegation — the transfer of authority, mandate, and responsibility across chains of autonomous agents that act at machine speed, across vendor boundaries, without continuous human involvement. Existing governance frameworks — identity systems, observability platforms, compliance APIs — establish who an agent claims to be and what it did. None establish whether a delegated action remained continuously authorised across a multi-agent workflow. That is the gap this paper addresses. Second: bounded delegation is the preferable design philosophy for AI systems acting consequentially on behalf of humans — not as a temporary concession to present-day limitations, but as an enduring principle. An AI agent operating under explicit, bounded, verifiable delegation is not a constrained version of a fully autonomous agent. It is a different and more trustworthy class of actor: one whose actions are attributable, whose authority is traceable, and whose failures are governable. We term this class the agentic proxy. Third: insurability emerges from accountability, not from model capability. Fully autonomous agents are structurally uninsurable because they satisfy none of the three conditions underwriters require — identifiable exposure, attributable causation, and verifiable governance. Agentic proxies satisfy all three by design." 

(Abstract continues: introduces working definition and six core properties, presents the CTX Envelope as architectural primitive for accountability across handoffs, argues attestation must be structurally independent (SWIFT/ACORD/CA/audit analogy), tests via healthcare/financial/legal/manufacturing case studies.)

Keywords: agentic AI, principal-agent theory, bounded delegation, audit chain, AI governance, insurability, multi-agent systems, EU AI Act, AI-to-AI delegation.

## Plain-Language Restatement

The hard governance problem isn't people chatting with AI — it's AI agents delegating work to other AI agents across company boundaries, where nobody checks whether each handoff stayed authorized. The author defines a safer class of system, the "agentic proxy": an agent that acts only inside an explicit, revocable mandate from a named human/organizational principal, with every action cryptographically logged back to that principal. Handoffs between agents travel in a signed "envelope" whose scope can only shrink, never grow; if verification fails, nothing executes. Because this architecture makes exposure finite, causes attributable, and governance verifiable, such agents become insurable — which is what would let them enter banking, payments, and commerce at scale.

## Problem Statement

Gap addressed: identity systems (A2A Agent Cards, Microsoft Entra Agent ID), observability platforms (Datadog, Dynatrace, Langfuse, Arize, Anthropic Compliance API) and insurance products establish who an agent claims to be, what it did, and who bears risk afterwards — but none verify whether a delegated action remained continuously authorized across every hop of a multi-agent workflow at execution time. It matters because deployment has outrun governance: 35% of organizations already adopted AI agents (+44% planning; MIT Sloan/BCG spring 2025); Gartner projects one-third of enterprise software embeds agentic capabilities by 2028; non-human identities outnumber humans 45:1 in the enterprise yet only ~10% of organizations have a management strategy; 82% use AI agents vs 44% with formal AI governance policies; 80% report agents took unintended actions in production.

## Methodology

Conceptual/architectural framework development with case-study validation (no statistical estimation):
- **Definition building** from principal-agent theory (agency law "proxy"; CMR insights; MIT Media Lab authenticated-delegation framework extending OAuth 2.0/OIDC; MIT economics definition of AI-mediated transaction agents). Six properties: delegated & bounded authority; goal-directed reasoning; principal fidelity; persistent identity & auditability; human oversight compatibility; organisational attribution. Six answerable questions per action: who/what/where/when/how/why.
- **Architecture specification**: CTX Envelope with four blocks — provenance (delegator lease identity + hash-chain ref + root_principal + signature); mandate (scope strict subset of delegator's, formal invariant M_An ⊆ ... ⊆ MA0 verified via parent_mandate_hash; constraints; escalation_rules); shaped context (schema-conformant payload — memory-poisoning control); execution boundary markers (exec.start/exec.finish, output_hash). Fail-closed property: CTX rejection recorded in CTX stream (status: rejected ≠ status: error) with provably zero MCP tool events — mathematical proof unauthorized work did not run, conditional on a deterministic gatekeeper runtime binding tool access to valid envelope handshake.
- **Convergence analysis**: mapping table against Anthropic's Zero Trust for AI Agents (May 2026) requirements; Google AP2 analysis (SD-JWT Verifiable Credential payment mandates; Direct/Autonomous modes; explicit deferral of multi-agent delegation = the gap this paper fills).
- **Case studies**: Grok–Bankr incident (May 2026); healthcare PHI delegation; financial services (rebalancing/communications/claims mandates mapped to investment policy statements, MiFID II, FCA Consumer Duty, SEC Rule 206(4)-7); legal privilege workflows; 13-agent manufacturing QA reference implementation (programmatically validated).
- **Legal/institutional analysis**: Moffatt v. Air Canada [2024] BCCRT 149; California AB 316 (eff. Jan 1, 2026, forecloses "AI did it" defense); EU revised Product Liability Directive (EU) 2024/2853 (implementation by Dec 9, 2026; software/AI as products, strict liability); EU AI Act Articles 13–14; FSMA 2000 regulated-activity question for audit-data routing; apparent-authority doctrine.
- **Insurance market analysis**: three conditions of insurability; review of Munich Re aiSure, Armilla (Chaucer/Axis-backed, 2025), Testudo (Jan 2026) as named-peril first movers; Gallagher survey (n>1,200: 57% cite AI errors/hallucinations as top risk).

## Key Results

Framework results (no empirical modeling):
1. **Agentic proxy vs adjacent concepts** (comparative table): generative AI (low autonomy, no delegation, implicit accountability), RPA (rule-based), general agentic AI (high autonomy, implicit delegation, variable accountability), agentic proxy (explicit+bounded delegation, verifiable chain, named persistent principal, real-time granular revocability, CTX-envelope handoffs, "by design" insurability, detectable mandate-violation failure mode), fully autonomous agent (self-set goals, none of the above, structurally impossible to insure).
2. **CTX Envelope guarantees table**: seven verifiable questions (who delegated; under whose ultimate authority; within what scope; with what constraints; on what information; did authorized work execute; did rejected work execute) each answered from envelope fields.
3. **Incident analysis**: Grok–Bankr — attacker embedded Morse-code instructions in a Grok conversation passed to Bankrbot; ~$174,000 in DRB tokens extracted (later recovered by Bankr team); root cause = handoff carried instruction content with no authorization representation; Bankrbot's earlier hardcoded block on Grok-origin instructions was silently dropped during a refactor because it was never architecturally represented as a mandate. Under the envelope model the injected instruction fails provenance/mandate verification → CTX rejection → zero MCP events.
4. **Insurance architecture**: three prospective coverage lines — Principal Liability Coverage (deployer/principal, premium bounded by mandate tightness), Delegation Chain Coverage (multi-agent failures: unauthorized scope expansion, inter-agent collusion, cascading propagation), Governance Failure Coverage (first-party losses from governance-infrastructure failure). Market data cited: US generative-AI lawsuits grew 978% between 2021–2025 (>700 cumulative filings; YoY acceleration 59%→137%); ISO CGL exclusions available Jan 2026 may remove genAI coverage.
5. **Institutional stack**: standard publication → standards-body recognition (BSI PAS route) → auditor ecosystem → insurance integration → procurement requirement; trust mark modeled on HTTPS padlock / PCI DSS badge; continuous cryptographic verification replaces episodic audit.
6. **Governance hierarchy**: organizational policies → departmental workflow policies → agent mandates → hash-chained execution events; "the unit of accountability is the workflow."
7. **Fable 5 episode** (June 12, 2026 US export-control directive suspending Anthropic model access globally): illustrates that without verifiable scope boundaries/attribution/prior governance records, regulators are forced to blunt kill switches; argues for regulating deployment governance rather than model capability.
8. **Open gap acknowledged**: third governance layer — model inference (activations, steering vectors; Anthropic NLA research, May 2026) — currently ungoverned; inference attestation is future work.

Document Trinity: AGENT.md (identity/authority/trust tier), SKILL.md (capabilities with inputs/outputs/preconditions/postconditions), INTENT.md (principal intent; hard constraints trigger fail-closed rejection, soft preferences are recorded performance deviations — the "hotel booking problem").

## Conclusions & Implications

Authors' conclusions: bounded delegation is the enduring design principle for consequential AI ("directed agent," not diminished agent); the CTX envelope solves the specific previously unnamed multi-agent authorization gap; independent attestation is structurally required (a lab cannot attest its own agents — defendant certifying its own evidence); insurability follows from verifiable governance, creating commercial pull for adoption; regulatory evolution will expect exactly these artifacts (AB 316, EU PLD, AI Act Art. 14).

For practitioners building payment/fintech AI systems:
- Payment mandates become concrete: Google AP2's signed Checkout/Payment Mandates are domain instances of bounded delegation; our demo can implement mandate narrowing (merchant mandate ⊆ user mandate) with parent-mandate hash verification and fail-closed rejection at the payment gateway.
- The two-stream audit design (authorization stream vs tool-call stream) gives a crisp audit-trail story for agent-driven payment mandates: prove both what ran AND what was blocked from running.
- Insurer-facing telemetry (mandate compliance rates, out-of-scope action frequency, delegation-chain integrity metrics) suggests new product surfaces: export underwriting-grade reports from your payment-agent platform.
- Boundary-agent tiering: any agent accepting external input (webhooks, merchant messages) should be treated as untrusted boundary membrane verifying envelopes before internal delegation — direct pattern for fraud/prompt-injection defense in agentic checkout.

## Limitations

Acknowledged by authors:
- Author's commercial interest disclosed (founder of Kindred Systems OS Ltd., building the described governance infrastructure).
- Computational overhead of envelope wrapping/signing/verification at every hop is "real, measurable" — argued as bounded premium but not benchmarked beyond qualitative comparison to one $174K loss.
- Actuarial pricing not attempted ("requires historical loss data that is only now beginning to accumulate").
- Model-inference layer explicitly out of scope (open research question).
- FSMA classification of the attestation platform unresolved; entity advised to seek FCA guidance.
- Appendix A OTel emission spec deferred to separate document (referenced, not included in extracted text).

Inferred (by me):
- Single-author vendor whitepaper in academic form; the Grok–Bankr, Fable 5, and various 2026 statistics rest on secondary press/blog sources not independently verifiable from the text.
- No empirical evaluation of whether the architecture reduces incidents; the 13-agent manufacturing implementation is the author's own validated reference, not third-party audited.
- Formal mandate-language semantics flagged by the author as unsolved; subset-invariant enforcement presumes mandates are machine-comparable, which real fuzzy intents may resist.
- Interoperability cost with existing payment rails (UPI/card networks' own auth flows) is not analyzed.

## Relevance to Our Hackathon

Arguably the most directly buildable blueprint among our papers:

1. **Audit trails for agent-driven payment mandates**: Adopt the CTX envelope pattern for Razorpay-track demo — every mandate creation/delegation carries provenance + narrowed scope + exec markers into a hash-chained log; show judges side-by-side streams: authorized actions executed vs rejected actions provably never executed (fail-closed proof).

2. **Consent UX grounded in mandates**: INTENT.md's hard-constraint vs soft-preference distinction maps to consent tiers (hard: spend cap, category blocklist → enforceable; soft: merchant preference ranking → advisory). This yields an explainable consent screen: "your agent may pay up to ₹X/day at categories Y; anything else escalates."

3. **Merchant/aggregator/bank liability allocation**: Mandate-narrowing invariant localizes breaches — if an out-of-scope charge executed, the envelope chain pinpoints which hop failed verification, i.e., whose control failed. Perfect substrate for the liability-allocation matrix demo.

4. **RTO/fraud angle**: Boundary-agent tiering treats inbound merchant signals and buyer-agent requests as untrusted until envelope-verified — a prompt-injection-resistant design for agentic COD/RTO decisions; shaped-context minimization parallels DPDP data-minimization duties.

5. **Insurability pitch**: The three coverage lines give us a business-model slide: platforms exposing mandate-compliance telemetry enable Delegation Chain Coverage for merchants using agentic checkout — trust as a market-access requirement (trust mark analogy).
