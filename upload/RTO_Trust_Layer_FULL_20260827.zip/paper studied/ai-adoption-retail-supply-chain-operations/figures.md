# Figures & Tables — Analyzing the Adoption and Influence of AI in Retail Supply Chain Operations

**Verdict: no numbered figures, no numbered tables, no empirical visuals.** The paper is a narrative management review; its only visual content is branding.

| ID | File | Page | Type | What it shows | Construction / quality | Supports |
|---|---|---|---|---|---|---|
| Unnumbered | `img_p001_14.png` (198×176 px) | 1 | Publisher logo | Circular green IAEME (International Association for Engineering and Management Education) emblem with atom, microscope, monitor and aircraft icons | Flat vector clip-art; low resolution; no data content | Nothing (branding only) |

Notes:
- The three "case studies" (Walmart inventory AI, Amazon last-mile, Zara demand forecasting) are prose-only — no charts, screenshots, or numbers accompany them.
- Nothing to extract into `tables.csv`.
- Quality observation: total absence of any quantitative or graphical evidence is consistent with the venue-quality caveat (IAEME, Vol. 1 Issue 1 of a young journal; narrative essay by an industry project manager).
