# Figures & Tables — AI Agents in Payments: Applications, Risks and Regulations

Source: EJRR 2026 (CUP), 24 pp. Images inspected from `.cache/images/3a74fc8ec407/` (page_003.png, page_005.png, img_p003_515.png, img_p005_518.png). Duplicate source key 7eac73c318d2 contains byte-identical images (same PDF sha256) — skipped per spec.

The article contains **2 figures and 0 tables**. No numeric tables exist → no tables.csv (not feasible/needed).

## Figure 1 — High-level architecture of an advanced AI agent
- **ID / page:** Figure 1, p. 3 (embedded raster img_p003_515.png, 987×441)
- **Type:** architecture diagram (module block diagram)
- **Construction inference:** clean vector-style diagram (draw.io/PowerPoint aesthetic) rasterized into the PDF; flat teal/green boxes with black outlines, purple highlight for the central Agent box; uniform sans-serif labels
- **Content exactly as shown:** central **Agent** box; left branch **Tools** → Calendar(), Calculator(), CodeInterpreter(), Search(), "... more"; top **Memory** → Short-term memory, Long-term memory; right **Planning** → Reflection, Self-critics, Chain of thoughts, Subgoal decomposition; bottom **Action**. Solid arrows Agent↔Tools/Memory/Planning/Action; dashed arrows Memory→Reflection and Tools→Action.
- **Takeaway:** matches prose exactly — agent core with 4 modules; planning sub-functions (reflection, self-critique, chain of thought, subgoal decomposition) and short-/long-term memory are drawn, not merely asserted.
- **Quality:** sharp, consistent fonts, no watermark; dashed vs solid arrow semantics are not explained in a legend (minor).
- **Supports:** summary Methodology bullet "Architecture review of modular LLM agents (planning module with reflection/self-critique/chain-of-thought/subgoal decomposition; short-/long-term memory; tool/API integration)" — confirmed visually.

## Figure 2 — Agentic system for credit card limit modification (Worldline patent)
- **ID / page:** Figure 2, p. 5 (embedded raster img_p005_518.png, 987×511)
- **Type:** flowchart (business-process diagram with pictograms)
- **Construction inference:** vector-style diagram rasterized; teal/green + magenta palette; pictogram icons (AI head, bucket, envelope, human figure, factory, document); title banner "Card Limit Modification Automation"
- **Content exactly as shown:** center node "AI reads content of email conversation". Branches: **General request** (left arrow) → bucket icon → "Classify the conversation and add/remove tag/theme/entity"; **Not matched to Bank X** (down) → "Check if interlocutor is eligible to make the request" (human pictogram) → **NO** → "Reply that cannot process further" (envelope icon); **YES** → "AI will gather needed information whether from content of email, or from the attachment" (document icon) → "Send information to bot" → "Request is processed by bot"; **Related to Bank X** (right) → factory icon "Bot eWL0XX" → "Request is processed by bot".
- **Takeaway:** confirms the NLP-parse → triage/classify → eligibility gate → info extraction → RPA hand-off (bot eWL0XX) pipeline described in prose; the RPA bot name "eWL0XX" appears only in the figure.
- **Quality:** sharp and legible; **internal inconsistency with prose**: the diagram routes "Related to Bank X" directly to Bot eWL0XX and puts the eligibility check on the "Not matched to Bank X" branch, whereas the text says eligibility is verified for Bank-X-related requests and non-Bank-X mail goes to the classification module. This is an inconsistency in the original paper's figure vs prose, not an artifact of extraction. Also the "General request" and "Not matched to Bank X" paths visually overlap in meaning.
- **Supports:** summary Key Results "Worldline's patented AI agent for credit-card limit modification (email parsing -> eligibility check -> RPA hand-off)" — confirmed visually, with the caveat above.

## Tables
None. The article is prose-only apart from the two figures (no data tables, no numeric tables to extract).
