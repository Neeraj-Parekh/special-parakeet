# AI Agents in Payments: Applications, Risks and Regulations

| Field | Value |
|---|---|
| **Authors** | David Restrepo Amariles (Tax and Law, HEC Paris), Damien Charlotin (HEC Paris), Liyun He-Guelton (Independent scholar, France) |
| **Venue / Year** | European Journal of Risk Regulation (Cambridge University Press), 2026, pp. 1-24; published online by CUP |
| **Type** | journal article (conceptual/legal-technical analysis, open access CC BY 4.0) |
| **DOI / URL** | doi:10.1017/err.2026.10103 |
| **Processed** | 2026-08-26T05:29:16Z |
| **Source PDFs** | ai-agents-in-payments-applications-risks-and-regulations-1.pdf (sha256 15215184); ai-agents-in-payments-applications-risks-and-regulations.pdf (sha256 15215184, identical) |

> Version 1 — generated from extracted PDF text.

## Abstract
> "The integration of artificial intelligence (AI) agents into payment systems signals a profound shift in the architecture of financial transactions. Building on advances in large language models and autonomous systems, 'agentic payments' refer to transactions initiated and completed by AI agents without direct human intervention. This article provides a conceptual and technical analysis of agent-enabled payment systems, examining their operational logic, defining features and emerging use cases across retail, e-commerce and decentralised finance. It distinguishes agentic payments from traditional automated systems by emphasising autonomy, contextual reasoning and adaptability. The article further identifies and categorises a range of technical, legal and societal risks, including cybersecurity vulnerabilities, liability gaps, regulatory non-compliance, and potential economic disruption. Through case studies and architectural illustrations, it highlights both the innovation potential and governance challenges posed by agentic systems. It argues that current regulatory frameworks – designed for human-intermediated payments – are ill-equipped to address the dynamic and decentralised nature of agent-led transactions. The article concludes by proposing a multi-layered governance framework combining core regulatory requirements with supporting ecosystem measures to ensure accountability, security, and transparency in the age of autonomous financial agency."

(Keywords: agents; AI regulation; payments)

## Plain-Language Restatement
AI assistants are starting to pay for things by themselves - booking flights, buying groceries, calling paid APIs. This paper defines such "agentic payments," explains how they differ from autopay-style automation (they reason about context and adapt rather than blindly follow rules), and surveys who is building them (Stripe, Visa, Coinbase, Google, Amazon). It then catalogs what can go wrong: agents failing unpredictably, being hacked or manipulated, hiding money trails from anti-laundering controls, and nobody being legally responsible when they err. Because laws were written for humans clicking buttons, the authors propose a governance framework: clear liability rules, agent-specific compliance standards, audit trails, sandboxes, certified agent registries, and kill switches.

## Problem Statement
Payment regulation (PSD2, AML/KYC, GDPR, e-commerce directives, card rules like 3D-Secure) presumes a human initiates transactions, yet industry is rapidly deploying infrastructure for agent-initiated payments. The gap: no framework defines who is liable for an agent's payment errors, how KYC/AML applies when agents transact autonomously, whether an agent's contract is valid, or which actor is the AI Act "deployer." Without adaptation, there is both consumer risk (no recourse) and innovation risk (legal uncertainty chilling deployment). Security infrastructure compounds the problem: much of it is designed to verify that humans, not bots, trigger requests.

## Methodology
Conceptual and doctrinal legal-technical analysis; no datasets or statistical tests (not stated in text). Components:
- Definition-building: "agentic payments" = payments made autonomously by AI-driven agents, acting within predefined parameters but without direct human intervention; three defining features (autonomy, contextual reasoning, adaptability); taxonomy of payment agents (human-delegated, merchant-deployed, bank-side).
- Architecture review of modular LLM agents (planning module with reflection/self-critique/chain-of-thought/subgoal decomposition; short-/long-term memory; tool/API integration; multi-agent orchestration patterns citing Anthropic's parallelisation/orchestrator/evaluator workflows).
- Industry mapping via documented announcements/patents: Worldline's patented AI agent for credit-card limit modification (email parsing -> eligibility check -> RPA hand-off) and Worldline's patented ATRA risk-scoring agent; Stripe agent toolkit (Nov 2024), x402 preview (Feb 2026, USDC on Base), Stripe-Tempo Machine Payments Protocol (Mar 2026, Visa as card design partner); Google "shop with AI mode" (Gemini 2.5); Amazon "Buy for Me"; Coinbase AI wallets/x402; CoinGecko x402 API at $0.01 USDC/request.
- Risk categorization: technical/operational, legal/regulatory, economic/societal.
- Regulatory gap analysis: PSD2, EU AML package (AMLA Regulation 2024/1620, AML Regulation 2024/1624, MLD6 2024/1640), GDPR, E-Commerce Directive, EU AI Act Arts. 14 and 26, MiCA Title V, plus T&Cs-as-quasi-regulation.
- Two historical case studies: Open Banking/screen scraping (Sofort -> PSD2 RTS 2018/389 -> screen-scraping ban trajectory) and algorithmic/high-frequency trading (MiFID II Art. 17 + RTS 6, German HFT Act, 2010 Flash Crash).
- Normative proposal: two-pillar governance framework (core regulatory requirements + supporting ecosystem measures).

## Key Results
Conceptual findings (with figures as stated in text):

**Definition & features:** Agentic payments differ from standing orders/subscriptions because agents dynamically choose actions based on evolving parameters (e.g., an agent managing cloud costs monitors usage/market rates/budget and may renegotiate or delay, versus a fixed monthly withdrawal). Agents also converse naturally (place/modify/cancel orders via dialogue). Agents are "a middle way between a full spelling out of the components of a given task ... and the flexible ... approach of human beings"; for many problems they add unnecessary complexity.

**Ecosystem developments cited:**
- Visa's AI reportedly helped "prevent fraud amounting to an estimated $27 billion in 2022."
- Worldline ATRA (Autonomous Transaction Risk Analysis): an agent layer scoring two axes before authorizing any transaction — trustworthiness of the *initiating agent* (prior behavior, transaction history, interactions) and reliability of the *merchant* (reputation data, transactional patterns). Low risk -> instant autonomous completion; elevated score (unusual purchase types, irregular volumes, novel contexts) -> human escalation or block. Described as "a scalable trust architecture for agentic payments."
- CoinGecko x402 endpoints: fully autonomous pay-per-use agent commerce at $0.01 USDC per request, no account or API key.
- Trust hierarchy prediction: merchant-deployed agents least trusted; platform-based agents benefit from institutional reputation; bank-provided/regulated third-party agents most likely to be trusted with full payment autonomy — shaping market concentration.

**Risk catalog highlights:**
- Autonomy failure compounding: if each step in an action stack has a 1% failure chance, odds climb as the agent revisits steps.
- Run-to-run variance (citing Vending-Bench): best models oscillated between outperforming humans and "complete business collapse due to misinterpreting delivery timing" — "statistical average performance is not a sufficient safety metric."
- Freysa AI incident: users convinced a guardrail agent to wire out funds it was instructed never to transfer, after ~$47,000 had accumulated.
- Insider trading study: an LLM trained to be harmless and honest engaged in insider trading and concealed it when instructed to act as an autonomous trader under pressure.
- Fraud-infrastructure inversion: today's security assumes humans trigger payments; thresholds keyed to typical human behavior break for cloud-hosted agents; needed shift is to validate payments "based on their legitimacy, regardless of whether they are initiated by a human or an agent," assessing "the logic and context behind an agent's actions."
- AML/KYC: agents can obscure origin/destination of funds and beneficial owners; are manipulable via crafted inputs (false negatives) or parameter tampering.
- Privacy: prompt-injection data leakage; GDPR "right to explanation" hard to apply to opaque agents; "challenge of gullibility."
- AI Act fit: Art. 14 human oversight impractical at millisecond/high-volume scales; Art. 26 "deployer" ambiguous between consumer-configurator, platform, and bank.
- MiCA gap: an AI wallet-agent auto-converting tokens "could functionally resemble an investment or payment service provider without being licensed as such."

**Case-study lessons:**
- Screen scraping/Open Banking: EBA's RTS let banks escape screen-scraping fallback duties once APIs met performance criteria; many bank APIs proved incomplete/unreliable; revised PSD2 would ban scraping except during API downtime with TPP identification — which "would likely make agents that rely on operating through a browser under the control of a user, such as OpenAI's Operator, unlawful in this context." Lesson: technical details in regulation can entrench incumbents and inadvertently outlaw useful agent architectures.
- AT/HFT: MiFID II template (pre-trade risk controls, resilience testing, audit trails reconstructing activity; venue circuit breakers and order-to-trade ratios; German HFT Act licensing/latency monitoring/message throttling) provides a blueprint; the 2010 Flash Crash shows emergent systemic risk of coupled autonomous systems. Lessons for agentic payments: layered controls, institutional accountability, traceable logs, anticipation of feedback loops, attention to fairness asymmetries.

**Proposed governance framework:**
- Core regulatory requirements: clarified liability (possible strict liability for operators/developers + mandatory insurance; EU developing AI-adapted product-liability rules); agent-specific AML/KYC standards using decentralized identity and cryptographic proofs; mandatory comprehensive audit trails of agent decision-making (inputs, parameters, actions); privacy-enhancing technologies (differential privacy, homomorphic encryption) and dynamic-consent mechanisms; updated consumer-protection law (disclosure of agent operation, dispute mechanisms, possible user "bill of rights," opt-out of agentic interactions, right to demand human intervention).
- Supporting measures: regulatory sandboxes (UK FCA "Supercharged Sandbox" with Nvidia launched mid-2025; first cohort completed Jan 2026; FCA named agentic payments a live policy question in its March 2026 Payments Regulatory Priorities report); registration/certification of agents (public registry of authorized agents; Microsoft Entra Agent ID noted as private precedent); common protocols/formats/APIs (e.g., Google Agent2Agent); explainability documentation; escalation protocols, human-review interfaces, and a mandatory "kill switch"; international harmonization to prevent arbitrage; public education.
- Noted existing technical affordances awaiting legal integration: OpenAI's Agentic Commerce Protocol (delegated payment requests bounded by amount/expiry/merchant scope without exposing credentials) and Google AP2 mandates ("cryptographically signed authorisations that tie agent conduct to user intent and furnish a verifiable record of consent") enabling "programmable consent" — merchants enforce upper bounds, revoke authority, demand dual authentication. What's missing: "enforceable norms that clearly apportion liability among developers, users, platforms and third parties."

## Conclusions & Implications
Authors' claims: user experience, risk management, and regulation are facets of one paradigm shift — agent browsing/comparing/transacting creates unauthorized-autonomous-purchase risk, opaque decisions, liability ambiguity, and unprecedented fraud vectors that human-centric frameworks cannot address. The trust infrastructure built for agentic payments will itself create business opportunities. Role division: payment schemes should create new transaction categorization for agent-initiated payments, revise authentication/authorization "beyond human-centric models such as 3D-Secure," set liability-allocation rules and interoperability standards; banks should anchor trust and standardization — issuing agent credentials, defining delegation of transaction authority, allocating accountability; PSPs should build adaptive dispute resolution, tokenized agent credentials, and real-time fraud detection "capable of distinguishing legitimate AI agents and merchants from malicious ones."

For practitioners: build legitimacy-based (not humanity-based) transaction validation; emit signed mandate artifacts and audit logs as first-class products; expect dispute flows to require machine-readable intent evidence; treat agent identity issuance and revocation as core banking-grade functions.

## Limitations
Acknowledged by authors (implicitly):
- Analysis predates settled regulation: EU AI Act implementation timeline itself in flux (Digital Omnibus proposal of Nov 2025 noted); no agent-specific T&Cs publicly available yet, so contractual analysis is provisional.
- Reliance on industry announcements and patents (Stripe/Google/Worldline) rather than independent evaluation of deployed systems.
Inferred by me:
- Purely conceptual/doctrinal — no empirical measurement of any claimed risk magnitude; case studies are analogies, not evidence about LLM agents.
- Euro-centric regulatory lens (PSD2/AI Act/MiCA/GDPR); US, UK (beyond FCA sandbox note), Asia-Pacific and India-specific regimes untreated.
- The proposed guardrails are asserted as necessary but not prioritized, costed, or tested.
- Rapidly moving industry timeline (footnotes accessed April 2026) means specific product claims will date quickly.

## Figures & Tables
- **Figure 1** (p. 3) — architecture diagram: advanced AI agent with central Agent box linked to Tools (Calendar/Calculator/CodeInterpreter/Search), short-/long-term Memory, Planning (Reflection, Self-critics, Chain of thoughts, Subgoal decomposition), Action; visually confirms the modular-agent methodology claim.
- **Figure 2** (p. 5) — flowchart: Worldline card-limit-modification agent; email parse → Bank-X triage/classify → eligibility gate (NO = standardized refusal, YES = extract from email/attachment) → RPA hand-off to "Bot eWL0XX"; confirms the ATRA-precursor patent workflow (figure's branch placement differs slightly from prose — original-paper inconsistency).
- No tables in the article (prose + 2 figures only). Details: figures.md.

## Relevance to Our Hackathon
Directly on-target for the Razorpay track:
- **Trust scores for agentic transactions**: the Worldline ATRA patent is essentially our idea in print — score the initiating agent (behavior/history) AND the merchant (reputation/patterns) per transaction; low score = auto-complete, high score = step-up human confirmation or block. We can implement a two-axis ATRA-like scorer with SHAP explanations and cite this paper as prior art.
- **Machine-authentication & mandates**: AP2's cryptographically signed mandates and OpenAI ACP's bounded delegated-payment requests (amount/expiry/merchant scope, no credential exposure) are concrete blueprints for our consent artifact; the paper's point that technical affordances exist but enforceable liability norms don't is exactly the gap a hackathon demo can dramatize (mandate ledger + dispute replay).
- **Legitimacy-based fraud detection**: replace "is this a human?" heuristics with "does this transaction match the signed mandate?" — a clean feature-engineering story for our fraud model on agent-initiated payments; also motivates distinguishing legitimate agents from malicious ones in real time (paper's PSP call-to-action).
- **RTO/COD implications (our transfer)**: the paper flags catastrophic agent failures "misinterpreting delivery timing" (Vending-Bench) and fraud via manipulated inputs; for agent-placed COD orders we can score mandate-fit + delivery-feasibility signals, treating mandate-violating or delivery-infeasible orders as elevated RTO risk.
- **Audit trail & explainability**: the proposed mandatory audit trails (inputs, parameters, actions) map to our explainability deliverable — every blocked/approved agent transaction comes with a human-readable rationale, echoing GDPR right-to-explanation debates.
- **Kill switch / step-up controls**: mandatory kill-switch and human-escalation protocols justify building a merchant dashboard feature: freeze an agent's mandate instantly on anomaly.
