# Artificial Intelligence in Retail: The AI-Enabled Value Chain

| Field | Value |
|---|---|
| **Authors** | Kim Oosthuizen (University of Stellenbosch Business School); Elsamari Botha (University of Canterbury & USB); Jeandri Robertson (University of Cape Town); Matteo Montecchi (King's Business School, King's College London) |
| **Venue / Year** | Australasian Marketing Journal, 2020 (accepted 28 July 2020) |
| **Type** | journal article (conceptual framework paper) |
| **DOI / URL** | https://doi.org/10.1016/j.ausmj.2020.07.007 |
| **Processed** | 2026-08-26T05:29:19Z |
| **Source PDFs** | oosthuizen2020.pdf (sha256 prefix `86b0edcd`) |

> Version 1 — generated from extracted PDF text.

## Abstract

(No separately labeled abstract appears in the extracted text; the introduction serves this role.) "Traditional retailers' business models are facing disruption by new entrants who can deliver greater value to customers more efficiently... This article introduces a conceptual framework to understand the role that AI can play in the retail value chain by proposing an AI-enabled retail value chain." The paper maps AI technologies from Gartner's 2019 Hype Cycle onto seven traditional retail value-chain stages, then uses Christensen's jobs-to-be-done approach to identify four key roles for AI solutions: knowledge and insight management, inventory management, operations optimization, and customer engagement — arguing these establish interconnectivity between value-chain activities rather than a linear silo view.

## Plain-Language Restatement

This conceptual paper asks what artificial intelligence should actually *do* inside a retail business, instead of listing shiny tools. The authors take Porter's classic step-by-step retail value chain (design → sourcing → manufacturing → inventory/distribution → store operations/sales → fulfilment → customer use/support), show where real retailers already deploy AI (Adidas' 24-hour shoe factories, ThredUp scanning ~100 million secondhand items, Sephora's virtual try-on), and reorganize everything around four "jobs" AI performs: turning data into insights, matching inventory to demand, optimizing operations, and engaging customers. Their core argument: AI breaks the linear value chain into an interconnected, iterative system, so retailers should invest in versatile AI technology classes (like machine learning or edge AI that serve multiple stages) rather than one-off point solutions.

## Problem Statement

Traditional retail value chains drive inefficiencies and are shortening as manufacturers/third parties go direct; digital entrants (Alibaba, Amazon) have devastated incumbents (Toys 'R' Us, Radioshack). Expectations for commercial AI are "sky-high" but it has yet to fully deliver; managers lack guidance on which AI technologies to prioritize and how current investments can be leveraged. No academic study had specified exactly how the retail value chain should change under AI. Four risks of retaining the traditional chain: (1) each stage adds stakeholders and complexity, slowing response to customer preferences; (2) stakeholder-specific platforms/legacy systems inhibit integration and data-driven agility; (3) longer chains make products more expensive and slower to reach customers; (4) complex chains invite disruption by agile firms leveraging new technology.

## Methodology

Conceptual/theoretical paper (no empirical dataset):
- **Stage 1 — Traditional value chain mapping**: synthesizes literature (Porter 1985; Hagel et al. 2016; Reinartz et al. 2019; Levy & Weitz 2009; Rieple & Singh 2010) into a seven-stage table of activities, stakeholders, key decision drivers/outcomes, and incumbent technology per stage (Table 1).
- **Stage 2 — AI technology scan**: reviews the 2019 Gartner Hype Cycle for Artificial Intelligence (Sicular et al., 2019), focusing on technologies predicted to reach mainstream adoption within five years: speech recognition, GPU accelerators, robotic process automation (RPA) software, AI-related consulting & system-integration (C&SI) services, augmented intelligence, chatbots, machine learning, deep learning, edge AI, intelligent applications, VPA-enabled wireless speakers, virtual assistants, FPGA accelerators, computer vision, insight engines, data labelling/annotation services, AutoML.
- **Stage 3 — Retailer example mapping** (Table 2): documented deployments matched to value-chain stages — Adidas (machine learning "speedfactory", personalised shoes made in 24 hours); Simons (insight engines for projected demand + proactive inventory allocation); Mohammadi Fashion Sweaters (intelligent applications/AI-enabled knitting); ThredUp (deep learning image recognition scanning close to 100 million unique inbound items, automated visual tagging + unique item codes); The Home Depot (edge AI, drones/robotics for faster order fulfilment); Sephora (augmented intelligence AR try-on, face-scanning shade matching with cross-channel personal codes); IKEA (AR true-to-scale furniture placement).
- **Stage 4 — Theory application**: applies Christensen's jobs-to-be-done approach (2003; 2016a,b) with Bettencourt & Ulwick's (2008) job-mapping; authors iteratively followed a customer-centric validation process to conceptually cluster AI's jobs, yielding four dimensions (Table 3 cross-tabulates jobs × value-chain stages × specific technologies).

## Key Results

Four jobs-to-be-done dimensions for AI in the retail value chain:
1. **Knowledge and insight management** — manage/share/use/create/process information; transform structured+unstructured data into organizational knowledge ("building block" of AI per Paschen et al.). Technologies: deep learning, insight engines, intelligent applications, GPU accelerators, C&SI services. Positioned as backbone supporting all other activities.
2. **Inventory management** — balance demand to supply over large assortments meeting customer needs and financial objectives; predict demand, keep popular items stocked, localized assortments, lower working capital. Technologies: chatbots, insight engines, intelligent applications, machine learning, virtual assistants. Evidence cited: Otto Group cut out-of-stock rate by 80% using predictive machine learning, boosting revenue/margins and market-shift response (Trotter, 2018).
3. **Operations optimization** — minimize costs, maximize operational capabilities, shorten the chain. Technologies: RPA, computer vision, deep learning, edge AI, C&SI services, machine learning, virtual assistants. Evidence: JD.com delivers 92% of orders same or next day after introducing AI operations (Marr, 2019; Trotter, 2018); Nike's augmented-intelligence custom shoe process takes two weeks design-to-delivery (Chao et al., 2019).
4. **Customer engagement** — build relationships/trust through personalization across the journey (not just final stages). Technologies: augmented intelligence, chatbots, computer vision, deep learning, edge AI, insight engines, machine learning, speech recognition, virtual assistants. Examples: Sephora shade codes enabling cross-channel personalization; The North Face weather-based outfit recommendations. Chatbots noted for reducing service costs and response times (Reddy, 2017).

Framework claims: dimensions are non-mutually-exclusive; multi-purpose technologies (machine learning, intelligent applications, edge AI, deep learning) deliver greatest ROI; the AI-enabled value chain is iterative/agile with real-time data flows replacing the linear silo model; most near-term AI remains "narrow" (ANI), so versatility of deployment matters more than generality of intelligence. Managerial prescription: start with knowledge-and-insight management as foundation, then scale technology classes across the chain.

## Conclusions & Implications

Retailers should invest in classes of AI technologies rather than single applications, begin with knowledge/insight management as the foundation, and scale AI across all links of the value chain instead of focusing narrowly on customer-facing or distribution-channel tech. The framework offers investment priorities and shows how existing investments can be redeployed across multiple functions. Future research directions named by authors: how the four dimensions build competitive advantage across product-market contexts; workforce skills needed to implement/manage/work alongside AI; data-quality risks — suboptimal data creates vulnerabilities and unintentional bias with negative outcomes; technological/organizational platforms required for scaling.

For practitioners building payment/fintech AI systems: the four-job taxonomy transfers directly — an agentic payments platform is essentially "knowledge & insight management" (risk/behavioral insights) + "inventory management" analog (liquidity/fund-flow balancing) + "operations optimization" (payment routing, reconciliation) + "customer engagement" (personalized payment experiences). The paper's trust-through-personalization thread (customer engagement builds loyalty moving beyond transactional) supports positioning Razorpay-style rails as the trust layer of agentic commerce.

## Limitations

Acknowledged by authors:
- Conceptual work — no empirical validation of the framework; future research needed on competitive advantage contribution, skills, data-bias mitigation, platforms.
- Relies on secondary sources (Gartner hype cycle, press/trade reports) for retailer examples.

Inferred by me:
- Example evidence is anecdotal vendor/press-reported figures (80% out-of-stock reduction, 92% next-day delivery) without independent verification or methodology detail.
- 2020 technology landscape predates LLMs/agentic AI; the "AI as computational agents" definition anticipates but does not cover modern autonomous commerce agents, governance, or consent issues.
- Jobs-to-be-done clustering was performed by the authors iteratively without reported inter-rater reliability or external validation.
- Retail-specific; direct transfer to fintech requires adaptation (the authors do not address payments, regulation, or fraud).

## Relevance to Our Hackathon

1. **Value-chain stage map for agent interventions**: use their seven-stage table to locate where Razorpay-style rails add trust in an agent-mediated purchase journey — sourcing/procurement (merchant verification), inventory/distribution (delivery-promise accuracy feeds RTO risk), store ops/sales (dynamic pricing/markdown logic agents can negotiate against), fulfilment (tracking signals that trigger COD→prepaid conversion nudges), customer support (agent-handled refunds/disputes).
2. **Four-jobs lens for our product pitch**: frame the hackathon build as AI doing knowledge/insight (fraud & RTO models), inventory (payment-method "inventory" = liquidity/rail selection), operations (auto-reconciliation, retry routing), and engagement (conversational consent UX) — mirrors judges' mental model of full-stack fintech.
3. **Invest in capability classes**: like the paper's advice to buy versatile tech classes, architect our solution as reusable components (one risk-model serving checkout, lending limits, and agent spend-caps) rather than point fixes — cheap MLOps win.
4. **Trust-through-personalization evidence**: customer-engagement AI "builds customer trust through personalisation" (their Table 3 objective row) — cite this when justifying personalized consent screens and spending insights in an agent wallet.
5. **Data-quality warning**: their flagged risk that poor upstream data creates biased automation is a ready-made slide for why our pipeline includes data-validation and drift checks before any autonomous money movement.
6. **Benchmark numbers for storytelling**: Otto Group −80% out-of-stock via predictive ML and JD.com 92% same/next-day delivery give concrete precedents that prediction-driven operations translate to hard KPIs — analogous targets: reduce failed-payment retries, raise prepaid-share of COD shipments.
