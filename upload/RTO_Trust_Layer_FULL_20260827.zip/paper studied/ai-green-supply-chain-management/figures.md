# Figures & Tables — The Role of Artificial Intelligence in Green Supply Chain Management

**Verdict: no figures/charts. Exactly 2 numbered tables** (both qualitative synthesis tables with literature citations, no numeric data). Page renders `page_002.png` (Table 1) and `page_004.png` (Table 2) visually confirmed to match the extracted text.

## Numbered tables

| ID | Page | Type | Content | Construction / quality | Takeaway |
|---|---|---|---|---|---|
| Table 1 — Drivers of Green Supply Chain Management | 2 (p. 326) | 3-col synthesis table (Driver / Synopsis / References) | Five drivers: Regulatory compliance (waste statutes, emission limits, sustainability reporting); Cost reduction (waste ↓, energy efficiency, optimized logistics/fuel); Market & customer demand (consumer preference shift to sustainable products); Competitive advantage (green differentiation attracting eco-sensitive consumers); CSR (stakeholder trust/reputation) | Typeset journal table; clean; citations per row (Zhao & Gómez Fariñas 2022; Kumar et al. 2021; Liu et al. 2024; Aslam et al. 2018; Wang & Pan 2022; Saini et al. 2023; Le 2023) | GSCM adoption is pulled by regulation + cost + demand + differentiation + CSR simultaneously |
| Table 2 — Benefits of AI in Green Supply Chain | 4 (p. 328–329) | 3-col synthesis table (Advantage / Description / References) | Four benefit clusters: enhanced warehouse effectiveness (ML floor plans/racking, pick-path optimization, AI forecasting vs carrying cost); decreased operating cost (automated counting/tracking/documentation, early malfunction detection → less downtime); reduced errors & waste (early detection of abnormal human/machine behaviour before rework/mis-shipment); enhanced supply-chain sustainability (ML-optimized truckloads/routes → less fuel; circular-economy lifecycle insights; supplier transparency) | Typeset journal table spanning two pages; clean; citations per row (Oluwademilade et al. 2024; Rege 2023; Albayrak et al. 2023; Sodiya et al. 2024; Allahham et al. 2023; Kumar et al. 2021) | AI's green benefit case is operational (cost/error/sustainability) rather than environmental measurement per se |

## Quality/editing observations
- No charts, plots, photos, or screenshots anywhere in the 7-page PDF.
- Tables are qualitative literature syntheses — no numbers to extract; `tables.csv` not applicable (nothing numeric to preserve beyond the citation mapping above).
- Venue note (inferred): IJLTEMAS shows a 5-day receive→accept window (29 Nov → 4 Dec 2024), typical of low-barrier outlets; treat synthesis claims as secondary-source quality.
