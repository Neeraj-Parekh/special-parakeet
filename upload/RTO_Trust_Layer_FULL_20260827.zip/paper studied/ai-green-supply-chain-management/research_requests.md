# Research Requests

- [Med] Quantify the green co-benefit of RTO reduction: using our synthetic delivery data, estimate fuel/km and extra-attempt rates for failed first attempts, then model emissions avoided by the prepaid-nudge intervention (the review asserts ML route/load optimization cuts fuel use but reports no numbers — produce our own).
- [Med] Apply the paper's adoption-barrier checklist (trust, explainability, data security, worker resistance, AI energy footprint) as an evaluation rubric for our hackathon demo, and document mitigations (SHAP explanations, consent flows, audit logs) per barrier.
- [Low] Prototype a "green supplier/courier scoring" feature analogous to DEA-ANN green supplier selection: rank courier partners by delivery-success and returns history to inform merchant routing decisions.
- [Low] Test whether demand-forecast-driven inventory positioning (a claimed GSCM benefit) reduces RTO incidence in simulation, e.g., fewer forced substitutions or split shipments under stockouts.
- [Low] Investigate measurement standards: identify which environmental KPIs (fuel intensity, failed-attempt rate, packaging waste from re-ships) Indian logistics providers already track, so a sustainability dashboard could be built on real metrics rather than proxies.
- [Low] Explore federated or energy-light modeling choices (small boosted trees vs large models) and report training/inference energy estimates, responding to the paper's concern about AI's own environmental cost.
