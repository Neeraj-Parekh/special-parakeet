# The Role of Artificial Intelligence in Green Supply Chain Management

| Field | Value |
|---|---|
| **Authors** | Sodiq Fowosere (Christian Dior Coutre Americas), Courage Obofoni Esechie (Southern University and A&M College), Sarah Namboozo (Southern University and A&M College), Friday Anwansedo (Bilaafe Ltd, Nigeria) |
| **Venue / Year** | International Journal of Latest Technology in Engineering, Management & Applied Science (IJLTEMAS), ISSN 2278-2540, Volume XIV, Issue II, February 2025, pp. 325–331 |
| **Type** | journal article (narrative literature review) |
| **DOI / URL** | https://doi.org/10.51583/IJLTEMAS.2025.14020033 |
| **Processed** | 2026-08-26T05:29:19Z |
| **Source PDFs** | The_Role_of_Artificial_Intelligence_in_Green_Suppl.pdf (sha256 58a26f8a…) |

> Version 1 — generated from extracted PDF text.

## Abstract

> "As environmental concerns continue to grow, industries are compelled to implement sustainable supply chain processes. Green supply chain management (GSCM) has become a key strategy for reducing the negative effects of supply chains on the environment. It includes anything from energy-efficient logistics to environmentally friendly product design. Simultaneously, artificial intelligence (AI) is transforming supply chain management through improved decision-making, optimization, and efficiency capabilities. Businesses have a great chance to achieve sustainability objectives while preserving operational performance at the nexus of AI and GSCM. This study aims to investigate how AI applications are currently used in green supply chain management, identify possible advantages and difficulties, and offer predictions about recent advances in the field. The results show that supply chain sustainability can be significantly increased by using AI applications. More precise demand forecasting and improved waste management techniques that reduce resource use are two major advantages. AI such as machine learning and predictive analytics, enable businesses to automate labour-intensive procedures and make smart judgements instantly while monitoring environmental performance. In conclusion, AI has a lot of potential to promote environmentally friendly supply chain management approaches that also improve operational effectiveness."

## Plain-Language Restatement

This review explains how AI tools — machine learning forecasting, IoT sensors, cloud platforms, big-data analytics — can make supply chains greener: cutting waste, fuel use, and emissions while keeping operations profitable. It catalogs what drives companies to go green, which AI technologies are being applied where, the concrete benefits observed in prior studies, and the obstacles (cost, data security, skills, legacy integration) before calling for research combining AI with blockchain, IoT, and renewable energy.

## Problem Statement

Organizations face growing regulatory pressure, consumer demand for sustainability, and cost/reputation incentives to reduce the environmental footprint of supply chains; GSCM integrates environmental thinking across design, sourcing, production, delivery, and end-of-life management, but prior GSCM research concentrates on industrialized countries (Japan, Germany, Portugal, UK, Taiwan) with limited study of developing nations, and the mechanisms by which AI specifically enables GSCM remain scattered across literatures. The paper synthesizes how current AI applications support GSCM, their benefits/difficulties, and future directions.

## Methodology

Narrative literature synthesis with no stated systematic-review protocol, dataset, or quantitative evaluation ("not stated in text"). Structure: introduction & motivation; overview of GSCM (definitions from Zhu et al. 2008 "closing the loop" incl. reverse logistics; Srivastava 2007 scope); theoretical aspects of AI+GSCM integration (adoption barriers from Strohm et al. 2020, Sharma et al. 2021, Reim et al. 2020 four-insight roadmap); application survey organized around technology families (IoT/sensors, cloud computing + SaaS, Big Data Analytics-AI hybrids, DEA-ANN for supplier selection, dual-channel green supply chains); two summary tables (drivers; benefits). Sources: ~52 references (2006–2024).

## Key Results

Qualitative synthesis; headline claims:

**Drivers of GSCM (Table 1):** regulatory compliance (emission limits, sustainability-reporting mandates); cost reduction (energy-efficient logistics reduce fuel usage/costs); market & customer demand (preference shift toward sustainable products); competitive advantage (green differentiation attracting environmentally sensitive consumers); corporate social responsibility (stakeholder trust).

**AI applications discussed:** wireless sensor networks/IoT building virtual infrastructure with cloud computing for monitoring, storing, visualization; cloud/SaaS reducing uncertainty in supply, demand, and process management (forecasting, planning, warehouse management, logistics, procurement); BDA-AI improving visibility/integration and lowering waste, air pollution and carbon emissions (Sun et al. 2019; Benzidia et al. 2021); Data Environment Analysis–Artificial Neural Network (DEA-ANN) hybrid for (green) supplier selection and supplier environmental-performance prediction; dual-channel green supply chain (DGSC) decision-support for pricing/differentiation/inventory under risk.

**Benefits of AI in GSCM (Table 2):** enhanced warehouse effectiveness (ML-generated floor plans/racking layouts, optimal pick paths, AI forecasting balancing inventory vs carrying costs); decreased operating cost (automation of counting/tracking/documentation, early malfunction detection minimizing downtime); reduced errors and waste (early detection of abnormal human/machine behavior before rework or mis-shipment); enhanced supply-chain sustainability (ML-optimized truckloads/routes burning less fuel, circular-economy insights from product lifecycle analysis, sourcing transparency supporting social/environmental guidelines).

**Adoption barriers:** high upfront costs, data-security concerns, shortage of technical know-how, integration difficulty with legacy infrastructure, workforce resistance/fear for job security, system-trust and explainability challenges (users less inclined to trust systems they cannot understand), analogue (paper/spreadsheet) processes blocking data capture, plus the environmental footprint of AI itself (energy for data processing/storage) requiring a balanced approach.

**Future research:** integration of AI with blockchain, IoT, and renewable energy sources; longitudinal studies on long-term effects of AI on supply-chain efficiency and environmental performance; scalability of AI-driven solutions.

## Conclusions & Implications

Authors claim AI can significantly increase supply-chain sustainability while preserving/improving operational performance, chiefly via more precise demand forecasting and waste reduction, but adoption must be balanced against AI's own energy costs. For practitioners building payment/fintech AI: the review's trust/explainability discussion (transparency as prerequisite of adoption; explainability = interpretability + credibility per Larsson & Heintz 2020) reinforces that RTO-risk scoring deployed to merchants needs explanation surfaces; its route/load-optimization benefit claim connects directly to delivery-failure/RTO economics (failed attempts burn fuel twice); and its roadmap framing (Reim et al.: understand AI → business model fit → organizational acceptance → capability acquisition) is a usable checklist when proposing agentic interventions inside a merchant's ops stack.

## Limitations

*(Acknowledged by authors)*: difficulties integrating AI into existing infrastructure; expensive upfront costs; data security concerns; dearth of technical know-how; environmental cost of AI computation itself; literature/practice gaps on scalability and long-term effects. *(Inferred by me)*: no systematic search/selection protocol or quality appraisal of the 52 citations; purely qualitative — no effect sizes, case metrics, or quantified emission reductions are aggregated; heterodox venue with light editorial apparatus; several cited works are themselves reviews, risking secondary-source drift; developing-country focus called for but not delivered empirically; no discussion of measurement standards for "green" outcomes, making claims hard to verify or replicate.

## Relevance to Our Hackathon

Indirect but useful: (1) the strongest bridge is cost-plus-carbon framing — failed deliveries double fuel/labor spend (Kandula et al.) and this review argues ML route/load optimization cuts both fuel and emissions, so an RTO-reduction demo can credibly claim a green-Supply-chain co-benefit for merchants (ESG angle on the Razorpay track). (2) Its adoption-barrier list (trust, explainability, data security, worker resistance) prefigures the governance/consent requirements our agent-mediated payment interventions must satisfy — cite it when justifying SHAP explanations and audit logs. (3) DEA-ANN green supplier selection suggests an analogous "risk-score your courier/logistics partner" extension using delivery-success histories. (4) Its call for AI+blockchain+IoT integration echoes the digital-product-passport paper in this corpus, giving us a consistent narrative thread if we pitch provenance-aware agentic commerce.

## Figures & Tables
No charts/figures. **Two numbered qualitative synthesis tables**: Table 1 (p.326) — five GSCM drivers (regulatory compliance, cost reduction, market/customer demand, competitive advantage, CSR) each with per-row citations; Table 2 (pp.328-329) — four AI-benefit clusters (warehouse effectiveness, operating cost, errors/waste, supply-chain sustainability) with per-row citations. Both visually verified against page renders; no numeric data, so no `tables.csv`. See [figures.md](./figures.md).

---
*Verification: v2 full word-by-word source read completed 2026-08-26; header facts, verbatim abstract, DOI, table contents, 52-reference list confirmed; no factual corrections required. Venue note: 5-day receive-to-accept window (inferred quality caveat).*
