# Blockchain Empowered Trustworthy Agent Networks: Foundations, Taxonomy, and Future Directions

| Field | Value |
|---|---|
| **Authors** | Liehuang Zhu, Yuhang Li, Tianxing Wang, Zhihao Chen, Ke Li, Hongyi Liu, Yajie Wang* (corresponding), Lei Xu, Peng Jiang, Zijian Zhang — School of Cyberspace Science and Technology, Beijing Institute of Technology, China |
| **Venue / Year** | arXiv preprint arXiv:2608.04626v1 [cs.CR], 5 Aug 2026 (formatted for IEEE Communications Surveys & Tutorials) |
| **Type** | survey |
| **DOI / URL** | arXiv:2608.04626v1 (https://arxiv.org/abs/2608.04626) |
| **Processed** | 2026-08-26T05:29:16Z |
| **Source PDFs** | 2608.04626v1.pdf (sha256 prefix 91b1bf7a) |

> Version 1 — generated from extracted PDF text.

## Abstract

"AI agents are evolving from isolated task executors into networked autonomous entities that can communicate, delegate tasks, invoke tools, access external knowledge, and participate in cross-platform service and economic workflows. This evolution gives rise to open agent networks, where heterogeneous agents owned by different stakeholders interact without naturally shared infrastructures for identity, authorization, auditability, reputation, or settlement. This survey and tutorial article reviews the literature over the period 1980–2026 on the evolution from classical multi-agent systems to open agent networks, with a particular focus on LLM-based autonomous agents, agent interoperability protocols, Internet-of-Agents infrastructures, and blockchain-enabled trust mechanisms. We first review this evolution and show how the trust boundary expands from individual execution to cross-agent, cross-platform, and cross-organizational interaction. We then identify a network-level trust crisis that cannot be fully addressed by single-agent safety mechanisms or closed multi-agent coordination techniques, and develop a five-dimensional taxonomy covering entity and capability trust, authorization and delegation trust, information and provenance trust, coordination and group-robustness trust, and accountability and settlement trust. Based on this taxonomy, we examine how blockchain can provide shared identity, verifiable authorization, tamper-evident provenance, auditable collaboration, incentive alignment, and value settlement for trustworthy agent networks. We further synthesize the mapping between agent-network risks, trust requirements, and blockchain-enabled mechanisms, and clarify the role of blockchain as a shared trust layer rather than a replacement for agent security, semantic verification, privacy protection, or robust reasoning."

## Plain-Language Restatement

As AI agents start talking to each other across companies and platforms — discovering services, delegating tasks, and paying each other — they enter "open agent networks" where nobody shares a common ID system, permission scheme, audit log, reputation score, or payment rail. The authors call this a network-level "trust crisis": one agent's fake identity, stolen authority, poisoned document, or unpaid bill can cascade through whole task chains. They organize these risks into five trust dimensions that follow the lifecycle of a delegated task, and then map each to blockchain/DLT mechanisms (decentralized IDs, smart contracts, hash anchoring, staking, escrowed micropayments) that can make trust states jointly verifiable across organizations. The key message is balance: blockchain is a shared evidence-and-settlement substrate, not a replacement for off-chain security, semantic verification, or runtime monitoring.

## Problem Statement

Open agent networks — enabled by interoperability protocols MCP, ACP, A2A, ANP and Internet-of-Agents visions — involve heterogeneous agents from different providers/stakeholders that dynamically discover, delegate, transact, and settle without shared infrastructure. The survey addresses two gaps: (1) existing surveys are fragmented at single-agent, closed-MAS, protocol-level, or AI-for-blockchain boundaries and do not capture relational risks produced by networked interaction; (2) there is no systematic mapping between network-level risks, trust requirements, and decentralized verification mechanisms. The problem matters because an agent's output may become another agent's instruction, evidence, memory, tool input, or basis for payment, turning locally containable failures into compositional, persistent network-level problems ("trust crisis of agent networks").

## Methodology

Survey/tutorial covering literature 1980–2026 (from Contract Net Protocol, KQML, FIPA, JADE through LLM agents, MCP/ACP/A2A/ANP protocols, IoA infrastructures, and blockchain trust mechanisms). No experiments/datasets — synthesis methodology:

1. **Evolution review**: single-agent systems → multi-agent collaboration → Internet of Agents, showing how the trust boundary expands at each stage.
2. **Five-dimensional lifecycle taxonomy** of trust crises, ordered along a delegated task's arc, each with three risk sub-types:
   - *Entity admission & capability trust*: identity/uniqueness risk (spoofing, Sybil); capability authenticity risk (model substitution — LLMmap fingerprinting; exaggerated claims — WildToolBench found no evaluated model exceeded 15% accuracy under its conditions); discovery-metadata manipulation (ToolHijacker).
   - *Authorization, delegation & execution-boundary trust*: induced misuse of legitimate authority (AgentDojo, InjecAgent, ConfusedPilot, AgentFuzz); instruction/data architectural conflation (StruQ, ACE); semantic-task misalignment/"authority laundering" (Task Shield).
   - *Information interaction & knowledge-source trust*: communication-channel risk (Agent-in-the-Middle; topology-dependent impact in MultiAgentBench); persistent memory/knowledge-base poisoning (AgentPoison, PoisonedRAG, environment-embedded triggers); protocol-level/retrieval-pipeline manipulation (MCP Security Bench attack family, RAG-jamming).
   - *Collaborative decision-making & group-robustness trust*: consensus failure under partial/malicious participation (Imperfect Byzantine Generals Problem); correlated error masquerading as consensus (multi-LLM debate analysis); topology exploitation (G-Safeguard graph detection; Agents Under Siege optimized attacks).
   - *Value settlement & accountability-governance trust*: missing institutional infrastructure for agent-level economic agency (incentive-compatible coordination; agent-economy gap; participation denial absent transparent registration); contribution attribution under ambiguous collective behavior (reputation-reward RL, credit assignment); responsibility reconstruction after harm (lifecycle-aware accountability; auditability axioms; monitored architectures; principal-agent liability analysis).
3. **Risk→trust→mechanism synthesis** (Table II): for each crisis, non-chain gaps vs. blockchain supplements (DID/VC anchoring, AgentCard/ANS registration, revocation state, reputation ledgers; smart-contract access control, scoped authorization, locked budgets, conditional payment; message hashes, signed digests, version chains, on-chain/off-chain evidence split; collaboration traces, result commitments, ZK contribution proofs, staking, insurance; verify-then-pay, x402 micropayments, escrowed payment, task proofs, staking penalties, insurance contracts, audit ledger) vs. explicit on-chain limits.
4. **Scenario analysis** across three deployment boundaries: agent service markets/economy; cross-organizational workflow automation; embodied/IoT/vehicular networks.

## Key Results

No quantitative benchmarks of its own (survey). Key qualitative results:

**Five-crisis table (Table I)** — networked origin, propagation mechanism, amplification:
| Trust crisis | Networked origin | Propagation | Amplification |
|---|---|---|---|
| Participant Trust | Open access; weak verification | Untrusted agent insertion | Persistent task-chain exposure |
| Authority Trust | Multi-hop authority | Intent and permission drift | Global overreach |
| Information Trust | Shared context and memory | Reuse of polluted inputs | Network-wide contamination |
| Collaboration Trust | Coupled reasoning | Consensus amplification | Correlated failure |
| Settlement Trust | Distributed execution | Diffused responsibility | Weak traceability |

**Blockchain role by layer** — representative mechanisms cited: BlockA2A (DID-based cross-domain auth + blockchain-anchored ledger + smart-contract context-aware access control); Binding Agent ID; A2A+x402 (on-chain AgentCards + x402 micropayments); Agent Name Service (ANS) universal directory compatible with A2A/MCP/ACP; Agent-OSI layered stack with AuthN/AuthZ layer; Trust Fabric (decentralized registries, semantic Agent Cards); AgentReputation (verifiable evidence, privacy protection, manipulation resistance); Agent Exchange (auctions, Agent Hubs, performance tracking); Insured Agents (risk pricing, conditional audit access, decentralized verification); DMAS, MOD-X, BetaWeb (message integrity/non-repudiation, cross-framework bus, Agentic Web governance); BlockAgents, DecentLLMs, DAO-Agent, WBFT (task-internal MAS: Byzantine robustness, ZK contribution verification, weighted BFT); TessPay (verify-then-pay); CPMM (x402/H402 capability-priced micro-markets); Agent TCP/IP (binding inter-agent transaction protocols).

**Key boundary claims**: blockchain proves existence/integrity of states (identity claims, digests, proofs, payments) but cannot determine semantic truth, intent validity, tool safety, or correctness of majority opinions. Entity admission and value settlement are closest to on-chain public infrastructure; authorization and information need hybrid on-chain state + off-chain defense; collaborative decision-making needs most caution (consensus ≠ correctness). Design principles proposed: trust-object specificity, continuous lifecycle governance, evidence-backed cross-domain verifiability, least-privilege contextual binding, robustness under partial compromise. Evaluation should yield multidimensional trust profiles, not single trust scores.

**Six future directions**: (A) dynamic trust management & capability state (binding keys vs. operators vs. model/tool providers vs. principals; extension of revocation; cold-start and reputation manipulation via rating inflation/Sybil identities); (B) intent constraints & verifiable execution boundaries (transforming natural-language goals into structured authorization objects; progressive authorization, dynamic budget tightening); (C) verifiable execution & semantic evidence (proof types: message/provenance/version/execution/compliance; privacy pressure → ZKP, TEEs, selective disclosure); (D) trustworthy collaboration evaluation (metrics: contribution attributability, source diversity, model correlation, abnormal influence, decision stability, dispute reviewability); (E) agent economy & accountability loops (task proof vs. outcome proof vs. settlement proof vs. liability proof; interfaces to regulators/arbiters/insurers); (F) evaluation benchmarks/testbeds (beyond TPS/gas cost to trust-effect metrics like identity verifiability, revocation propagation time, authorization-deviation detection rate, accountability-attribution accuracy).

## Conclusions & Implications

The authors conclude that trustworthy agent networks require hybrid architectures: blockchain supports cross-organizational shared state, verifiable commitments, non-repudiable evidence, incentive constraints, and programmable settlement, while off-chain mechanisms secure reasoning, execution, privacy, real-time interaction, and physical control. Blockchain's value is greatest when mutually distrustful participants need persistent shared records or contestable settlement; otherwise conventional access control, signed logs, trusted execution, and centralized infrastructure may be more appropriate. Existing literature remains dominated by proposals/preprints needing validation in deployable systems, unified evaluation, cross-protocol revocation, and regulatory compliance.

For fintech/payments practitioners: this survey supplies the canonical risk checklist for agentic commerce — verify counterparty identity AND capability before routing transactions; track delegation chains and budgets programmatically; anchor evidence for disputes; treat settlement (verify-then-pay, escrow, insurance) as part of the same state machine as authorization; never assume consensus or payment records imply service quality.

## Limitations

**Acknowledged by authors:** existing blockchain-agent work is mostly architectural proposals, early protocols, and preprints lacking deployable validation; no unified evaluation or testbeds exist; blockchain cannot address semantic truth, capability quality, safe tool use, privacy compliance, or legal adjudication; cross-protocol revocation and regulatory compliance unresolved.

**Inferred by me:** as a survey it reports no independent empirical measurements, so the relative effectiveness of cited mechanisms is asserted rather than benchmarked; the taxonomy's five crises, while analytically clean, may overlap in deployed systems (e.g., Sybil reputation attacks span participant and settlement trust simultaneously); coverage is literature-based up to mid-2026 and may miss industrial implementations; regulatory analysis is generic (no jurisdiction-specific treatment such as India's DPDP or payment regulation); some cited works are themselves preprints, so reliability of individual mechanism claims varies; the extraction shows minor typographic garbling around Section VI-F metrics (text artifacts), though meaning is recoverable.

## Relevance to Our Hackathon

This is the most directly applicable reference for building trustworthy agentic payments at Razorpay-track scope:

- **Verifiable identity/reputation for shopping agents at checkout**: the entity-admission crisis gives the exact threat model — Sybil buyer-agents, spoofed identities, forged capability claims, poisoned merchant directories (ToolHijacker-style metadata manipulation = fake/impersonated merchant listings). Build a checkout-time gate: DID + credential digest check, revocation-state lookup, reputation ledger entry per agent/merchant before allowing payment initiation.
- **Trust scoring layers for agent-mediated payments**: the settlement-trust crisis prescribes verify-then-pay (TessPay pattern), escrowed payment states, signed evaluation records, and reputation updates fed back into future admission — i.e., our RTO/fraud risk scores become admission criteria in a loop ("settlement errors corrupt reputation and influence future admission decisions"). Implement as: order outcome → signed settlement record → reputation update → next-checkout risk tier.
- **Escrow-like settlement patterns**: the paper's four-stage payment lifecycle (discovery, authorization, execution, accounting) plus escrowed-payment/task-proof mechanisms map onto a hackathon build: lock budget at cart time (authorization object with spending caps), release on delivery proof (oracle), dispute path with anchored evidence.
- **Fraud on imbalanced data**: authorization-deviation detection ("misuse under valid authorization") motivates anomaly features — budget-ceiling proximity, invocation-count spikes, sub-delegation depth, revocation lag — which are exactly behavioral features for fraud classifiers.
- **Consent & DPDP-style human oversight**: ANP's distinction between human vs. agent authorization ("high-risk operations should not be fully signed by autonomous agents alone") supports tiered consent dashboards where high-value or first-party-unverified checkouts require human confirmation; progressive authorization = step-up authentication.
- **Explainability**: the multidimensional trust profile (participant/authority/information/collaboration/settlement) instead of a single score is a template for explainable risk dashboards for merchants.
