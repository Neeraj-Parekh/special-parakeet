# Learning from Imbalanced Data Sets

| Field | Value |
|---|---|
| **Authors** | Alberto Fernández, Salvador García, Mikel Galar, Ronaldo C. Prati, Bartosz Krawczyk, Francisco Herrera |
| **Venue / Year** | Springer (Springer Nature Switzerland AG), 2018 |
| **Type** | book |
| **DOI / URL** | https://doi.org/10.1007/978-3-319-98074-4 (ISBN 978-3-319-98073-7 hardcover, 978-3-319-98074-4 eBook) |
| **Processed** | 2026-08-26T05:29:31Z |
| **Source PDFs** | 10.1007@978-3-319-98074-4.pdf (sha256 prefix 57d5fe1e) |

> Version 1 — generated from extracted PDF text.

## Abstract

(Books in this volume carry no single global abstract; the following is quoted verbatim from the book's Preface.)

"Learning with imbalanced data refers to the scenario in which the amounts of instances that represent the concepts in a given problem follow a different distribution. The main issue when addressing such a learning problem is when the accuracy achieved for each class is also different. This situation occurs since the learning process of most classification algorithm is often biased toward the majority class examples, so that minority ones are not well modeled into the final system. Being a very common scenario in real-life applications, the interest of researchers and practitioners on the topic has grown significantly during these years."

"The intended audience of this book are developers and engineers aiming to apply imbalance-learning techniques to solve different kinds of real-world problems, as well as researchers and students needing a comprehensive review on techniques, methodologies, and tools for learning from imbalanced data."

## Plain-Language Restatement

Most machine-learning classifiers are tuned to maximize overall accuracy, so when one class is much rarer than another (e.g., fraudulent payments vs. legitimate ones), models learn to mostly predict the common class and ignore the rare one. This book is a comprehensive guide to why that happens and what to do about it. It walks through the main families of fixes: changing evaluation metrics, resampling the data (undersampling/oversampling such as SMOTE), making algorithms cost-sensitive, and building ensembles that combine these tricks. It also extends the discussion to multi-class problems, data streams with drift, and Big Data scale, and points to software tools that implement everything.

## Problem Statement

Standard classifiers minimize error under the implicit assumption of balanced classes and equal misclassification costs. In imbalanced domains the minority class — usually the class of interest — is poorly modeled: the book shows a 1:100 synthetic problem where a trivial all-negative model reaches 99.01% test accuracy while achieving 0% accuracy on positives, versus 98.61% for a model that actually separates the classes. Two lessons are drawn: (1) accuracy is not a valid measure under imbalance, and more informative measures (ROC, geometric mean, F-measure, precision, recall) are required; (2) classifiers must be biased toward the minority class without harming majority-class performance. The gap addressed is the absence of a unified, practitioner-oriented reference covering formal foundations, application case studies, metrics, and all major solution families (cost-sensitive, data-level, algorithm-level, ensemble-based, plus multi-class, streaming, and Big Data extensions).

## Methodology

The book is a structured review/synthesis organized in three parts (per the Contents and Preface):

- **Part I: Foundations & alternatives**
  - *Ch 2 Foundations*: formal description via Imbalance Ratio (IR = #negative/#positive); taxonomy of solutions into four groups — algorithm-level (internal), data-level (external), cost-sensitive, and ensemble-based; stresses that skewed distribution alone does not hinder learning (small sample size, class overlapping, small disjuncts are the real culprits). Surveys applications across engineering, IT, bioinformatics, medicine, business management (stock prediction, credit card/loans approval, fraud detection, customer churn), security, education; e.g., Kubat et al.'s oil-spill dataset had 896 lookalikes vs 41 oil spills (IR > 20). Introduces the KEEL dataset repository (66 binary imbalanced datasets, IR from 1.5 to 129, used later in experiments).
  - *Ch 3 Performance Measures*: organizes evaluation by prediction scale — nominal, scoring, probabilistic. Covers accuracy/error drawbacks (illustrated with three confusion matrices sharing 99% accuracy), Cohen's kappa and weighted kappa with inverse-proportionality costs, MCC, TPR/FPR/TNR/FNR, PPV/NPV/FDR/FOR, Fβ/F1, G-measure, G-mean = √(TPR·TNR), balanced accuracy; ROC curves/AUCROC (probabilistic interpretation as ranking probability, Mann–Whitney U link; unreliable under class rarity/small samples), Precision–Recall curves/AUCPR (preferred under rarity), Brier score with calibration/refinement decomposition and reliability diagrams.
  - *Ch 4 Cost-Sensitive Learning*: distinguishes feature (test) costs vs class misclassification costs; minimum expected cost principle R(i|x) = Σ_j P(j|x)·C(i,j); decision threshold p* = C(1,0)/(C(1,0) − C(0,1)) assuming zero correct-classification costs; direct vs meta-learning approaches; obtaining the cost matrix from experts (credit-card fraud example where cost = average monetary loss of accepting a fraudulent transaction vs losing a customer after rejecting a valid one) or estimated via IR heuristic (C(i,j)=IR, C(j,i)=1) or ROC iso-performance lines / ensembles over cost grids; MetaCost wrapper (bootstrap an ensemble, relabel training instances by minimizing conditional risk, retrain any classifier); cost-sensitive decision trees (splitting-criterion modification with test+misclassification cost minimization, ATC metric; instance-weighting meta-approach); Different Error Costs (DEC) SVMs with separate C+/C− penalties; moving-threshold ANN outputs; cost-sensitive kNN rule; hybrids like SMOTE with Different Costs (SDC).
- **Part II: Classical imbalanced classification tools**
  - *Ch 5 Data-Level Preprocessing*: undersampling basics (RUS; Tomek Links; Condensed Nearest Neighbor US-CNN; OSS; CNN+TL; Neighborhood Cleaning Rule NCL; Class Purity Maximization; SBC clustering-based; NearMiss-1/2/3/more-distant family); advanced undersampling (evolutionary/CHC-based EBUS & EUSCM taxonomies, ACOSampling with fitness α·F-measure + β·G-mean + γ·AUC, IPADE-ID differential-evolution instance generation, CBEUS cluster+GA, cleaning-based Weighted Sampling and Instance Hardness Threshold IHT, ensemble-based IRUS inverse random undersampling and OligoIS, clustering-based ClusterOSS and DSUS); SMOTE in detail (interpolation along segment joining a minority sample and one of its k=5 NNs, gap ∈ [0,1]; noted drawbacks: over-generalization, noise generation, no neighbor awareness); SMOTE extensions (>90 exist; detailed coverage of Borderline-SMOTE1/2 DANGER set logic, ADOMS PCA-direction interpolation, ADASYN density-distribution generation gi = r̂i·G, ROSE smoothed bootstrap, Safe-Level-SMOTE safe-level ratios, DBSMOTE DBSCAN density-reachable graphs, MWMOTE informative-weighted two-phase selection, MDO Mahalanobis covariance-preserving generation); hybrids SMOTE+Tomek Links and SMOTE+ENN plus SPIDER, SMOTE-RSB*, SMOTE-IPF. All illustrated visually on a 5×5 "chessboard" CART reconstruction benchmark.
  - *Ch 6 Algorithm-Level Approaches*: SVM bias analysis (identical penalty C shifts boundary toward minority; support-vector disproportion) with kernel modifications (boundary/margin shift, kernel target alignment, asymmetric conformal kernel scaling D(x) = e^(−k f(x)²)), instance weighting in soft-margin objective (per-instance Ci), zSVM support-vector re-weighting by factor z, FSVM/FSVM-CIL fuzzy memberships with decaying functions; decision trees — Hellinger distance splitting criterion dH(TPR,FPR) proven skew-insensitive (Hellinger Distance Decision Trees built on C4.4), off-centered entropy, minority entropy, Class Confidence Proportion splits with Fisher's exact test pruning; gravitational/fuzzy-rough nearest neighbors (IFROWANN); Bayesian adaptations (Locally Weighted Naïve Bayes, Bayes Vector Quantizer); one-class classifiers (train on majority treating minority as outliers, or tuned one-class on minority, or both combined; weighted one-class SVM using neighborhood difficulty levels).
  - *Ch 7 Ensemble Learning*: foundations (bias-variance, ambiguity decomposition; Q-statistic diversity analysis by Wang & Yao showing strong negative correlation between Q and GM/AUCROC under imbalance — greater diversity preferred); Bagging (~63.2% unique instances per bag; Pasting Small Votes/Ivotes importance sampling), AdaBoost (+M1/M2 variants) with worked decision-stump example (stumps ≈60% accuracy boosted to 95% training/90% test); taxonomy Table 7.1: cost-sensitive boosting (AdaCost ϕ± = ∓0.5Ci + 0.5, CSB1/CSB2, RareBoost with αp=TP/FP and αn=TN/FN and its >50% positive-accuracy collapse condition, AdaC1/C2/C3), ensembles with cost-sensitive base classifiers (BoostedCS-SVM with λ-scaled alpha and g-mean stopping, BoostedWeightedELM, CS-DT-Ensemble, BayEnsBNN, AL-/IC-BoostedCS-SVM), boosting-based (SMOTEBoost, MSMOTEBoost, RUSBoost, DataBoost-IM, RAMOBoost, Adaboost.NC, EUSBoost, GESuperPBoost, BalancedBoost, RB-Boost, Balanced-St-GrBoost), bagging-based (OverBagging/SMOTEBagging a% resampling rate 10%→100%, UnderBagging/QuasiBagging/Asymmetric Bagging, Roughly-Balanced Bagging negative binomial draws, Partitioning/BEV, IRUS, α-tree ensembles, PUSB, UnderOverBagging, IIVotes with SPIDER, RB-Bagging, EPRENNID, USwitchingNED), hybrid ensembles-of-ensembles (EasyEnsemble, BalanceCascade sequential majority removal, HardEnsemble 50 oversampled + 100 undersampled RUSBoost members, StochasticEnsemble), Other (MOGP-GP, Random Oracles, loss factors based on F-measure/G-mean, GOBoost g-mean optimization, OrderingBasedPruning RE-GM, diversity-enhancing techniques, PT-Bagging threshold-moving without rebalancing, IMCStacking cost-sensitive stacking, dynamic selection).
    - Illustrative experiment: all 66 KEEL datasets, C4.5 base learner (confidence 0.25, min 2 item-sets/leaf, Laplace smoothing), g-mean with DOB-SCV 5-fold CV × 5 seeds = 125 runs; Wilcoxon pairwise + Friedman aligned-ranks + Holm post-hoc tests; 10 classifiers for boosting-based, 40 for bagging/hybrid, UnderBagging_RE pruned from 100 to 21.
- **Part III: Extensions**
  - *Ch 8 Multi-class*: OVO (m(m−1)/2 subproblems) vs OVA decomposition, ad-hoc multi-class preprocessing/algorithms/cost-sensitive/ensemble methods, micro/macro aggregation metrics, experimental study.
  - *Ch 9 Dimensionality Reduction*: classical/ad-hoc feature selection, ensemble/wrapper and evolutionary FS, linear extraction (Asymmetric PCA, MinPD/NFnF), non-linear autoencoders, ur-CAIM discretization.
  - *Ch 10 Data Intrinsic Characteristics*: complexity measures, small disjuncts/sub-concepts, lack of data, overlapping/separability, noise, borderline examples, dataset shift, imperfect data; instance typing into safe/borderline/rare/outliers by neighborhood composition.
  - *Ch 11 Imbalanced Data Streams*: stream properties (unbounded, one scan, high arrival rate, evolving distributions, costly labels); real vs virtual concept drift; data-level/algorithm-level stream methods (Undersampling Naïve Bayes, GOS-IL, Sequential SMOTE, RLSACP/ONN, DCIL-IncLPSVM, KOIL, GH-VFDT, CSPT); ensemble approaches (SE, SERA, REA, BD, Learn++.CDC, EONN, ESOS-ELM, OOB/UOB online bagging, DWMIL, GRE); evolving number of classes (Learn++.NC, ECSMiner, MCM, AnyNovel, CBCE, CLAM/SCARN); limited ground-truth access (online active learning with Bayesian probit, Online-MSU, CSOAL, Stream-GP).
  - *Ch 12 Non-classical problems*: semi-supervised (incl. PU learning), multilabel imbalance quantification, multi-instance, ordinal classification/imbalanced regression.
  - *Ch 13 Big Data*: MapReduce/Hadoop/Spark/Mahout/MLlib; distributed preprocessing studies, cost-sensitive studies, applications; challenges (partition-induced minority scarcity, small disjuncts, variety).
  - *Ch 14 Software*: Java KEEL suite & Weka (with imbalanced-focused plugins/packages), R packages (Unbalanced, Smotefamily, ROSE), Python scikit-learn imbalanced-learn toolbox, Spark-based Big Data solutions.

## Key Results

Conceptual/synthesis work; key quantitative anchors reported in the text:

| Claim | Numbers as reported |
|---|---|
| Trivial model beats "good" model on accuracy (Fig. 2.2 toy 1:100 problem) | Model 1: 99.01% accuracy, 0% positive-class accuracy; Model 2: 98.61% accuracy |
| Three confusion matrices with identical accuracy (Fig. 3.1) | All 99%; kappa values 0, 0.66, 0.66; with inverse-proportion costs L = 1, 0.1, 0.5 and κw = 0, 0.98, 0.5 |
| Kubat et al. oil-spill pioneer dataset | 41 oil spills vs 896 lookalikes (IR > 20) |
| KEEL binary imbalanced benchmark used in Ch 7 | 66 datasets, IR ranging 1.5–129 |
| Ensemble experiment protocol | 125 runs per method/dataset (5-fold DOB-SCV × 5 seeds) |
| Average g-mean (test) over 66 datasets | RUS 0.8076 · SMOTE 0.8222 · UnderBagging 0.8536 · SMOTEBagging 0.8421 · RUSBoost 0.8554 · SMOTEBoost 0.8312 · EUSBoost 0.8606 · EasyEnsemble 0.8577 · **UnderBagging_RE 0.8691 (best)** |
| Statistical tests | Wilcoxon: every ensemble significantly beats plain RUS/SMOTE at 95%; SMOTE alone beats RUS alone (p=0.00024) but RUS-based ensembles dominate SMOTE-based ones; Friedman aligned ranks rank 1 = UnderBagging_RE (142.95), rank 2 EUSBoost (215.17); UnderBagging_RE significantly outperforms all others (Holm APV ≤ 0.00189) |
| Diversity finding (Wang & Yao) | Strong negative correlation between Q-statistic and GM/AUCROC under imbalance → prefer high-diversity ensembles |
| AdaBoost illustration | Decision stumps ≈60% accuracy each; ensemble reaches 95% train / 90% test |

Qualitative key claims:
- IR alone does not determine difficulty; small sample size, overlap, noise, and small disjuncts do.
- No universal performance measure exists; choice is domain-dependent (Ch 3).
- Ensembles pay off statistically over standalone preprocessing despite added complexity.
- Counter-intuitively, RUS provides better diversity inside ensembles than SMOTE, reversing the standalone ordering.
- Ensemble pruning (RE-GM) turned the strongest overall method (UnderBagging_RE).

## Conclusions & Implications

Authors' claims: imbalanced classification requires abandoning accuracy-oriented design end-to-end — proper metrics (G-mean, AUCPR, MCC), targeted preprocessing (SMOTE family, evolutionary/clustering undersampling), cost-sensitive thresholds learned from ROC analysis when true costs are unknown, and ensemble wrappers that add diversity. Open challenges named: instance-level cost sensitivity, hybrid sampling+cost methods, cost-matrix estimation on drifting data streams, and extension to multilabel/regression/time-series settings.

For practitioners building payment/fintech AI systems: (1) never report plain accuracy for fraud/RTO models — the book's 99%-accuracy-trivial-model argument applies verbatim to payment fraud where fraud rates can be far below 1%; (2) treat block-vs-decline decisions explicitly through a cost matrix (average monetary loss of accepting a fraudulent transaction vs customer loss from rejecting a valid transaction — the book's own credit-card-fraud framing) and tune thresholds on ROC iso-performance lines rather than defaulting to 0.5; (3) prefer simple, strong baselines (UnderBagging + threshold/pruning, EasyEnsemble, RUSBoost) before exotic methods; (4) use calibrated probabilities (Brier/reliability diagnostics) if risk scores feed downstream agents or human reviewers; (5) production payment data is a stream with drift — Ch 11's imbalanced-stream toolbox (OOB/UOB online bagging, Learn++.CDC, cost-sensitive online active learning for label budget) is directly relevant to monitoring and retraining loops.

## Limitations

Acknowledged by authors (marked in chapter summaries):
- No clear rule exists for choosing between preprocessing vs algorithm-level adaptation ("There is no clear rule that tells us which strategy is best", Ch 5).
- Cost matrix definition remains "a difficult choice in practical applications"; IR-based cost initialization is an oversimplification because IR is not the sole source of difficulty.
- RareBoost collapses unless positive-class accuracy exceeds 50%; DataBoost-IM cannot handle highly imbalanced data (exponential instance explosion example given).
- Hellinger distance splitting is binary-only; one-vs-all extension gave only moderate results.
- ROC-based cost tuning is sub-optimal (no guarantees across all possible costs).
- Imbalanced Big Data classification "still at an early stage of development".
- Few attempts on improving combination phase (dynamic selection/aggregation) relative to diversity creation.

Inferred by me:
- 2018 publication predates deep-learning-era imbalance handling (focal loss, representation learning on tabular payment data) and gradient-boosting libraries (XGBoost/LightGBM scale_pos_weight workflows are not evaluated).
- Experiments use UCI-style KEEL datasets; none are payment/fraud-scale industrial datasets, so transfer of the RUS-vs-SMOTE-in-ensembles conclusion to production payment streams is untested here.
- The illustrative Ch 7 study excludes cost-sensitive ensembles (authors judged fixed general cost patterns unfair), so that family lacks comparative evidence within the book itself.

## Relevance to Our Hackathon

Razorpay-track relevance:
- **Fraud/RTO risk on imbalanced payment data**: the book is the canonical playbook for exactly our setting — fraud and RTO labels are extreme-minority classes. Its four-family taxonomy maps onto a concrete hackathon pipeline: start with G-mean/AUCPR evaluation, then benchmark UnderBagging/EasyEnsemble/RUSBoost vs SMOTE variants vs class-weighted XGBoost (DEC-style per-class penalties).
- **Cost-sensitive thresholds (block vs false-decline)**: Ch 4 gives the exact machinery — expected-cost minimization, threshold p* = C(1,0)/(C(1,0) − C(0,1)), expert-supplied cost matrices for fraud (money lost on missed fraud vs churn from false declines), and ROC iso-performance threshold search when costs are unknown. Directly implementable as a post-hoc threshold tuner on top of any scorecard.
- **Drift monitoring of production payment models**: Ch 11 (imbalanced streams, virtual/real drift, online bagging OOB/UOB, Learn++.CDC, active-learning label budgets) informs how we detect when merchant-behavior drift degrades the fraud/RTO model and how to retrain cheaply with limited human-labeled chargeback ground truth.
- **Explainability**: Ch 6's Hellinger trees and interpretable cost-sensitive decision trees support regulator/merchant-friendly explanations for block decisions; Ch 10's safe/borderline/rare/outlier instance typing gives a language for explaining *why* a specific transaction was scored risky.
- **Evaluation discipline for demos**: adopt the book's statistical rigor (DOB-SCV folds, Wilcoxon/Friedman+Holm) when comparing hackathon models so results survive judge scrutiny; report calibration plots alongside AUCPR for trust.
- **Tooling**: KEEL, imbalanced-learn (Python), and Spark-based implementations listed in Ch 14 let us prototype quickly at payment-data scale.
