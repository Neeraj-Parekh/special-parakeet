# Figures & Tables — CBA White Paper: Agentic AI Payments (January 2026)

Images inspected from `.cache/images/25ae47bbaae0/` (img_p001_11.png, img_p018_162.png). No rendered page PNGs were extracted for this source (text-based PDF); embedded images below.

The document contains **1 numbered figure (Figure 1), 1 cover graphic, and 4 lettered tables (I–IV)**. Tables I–IV are cleanly readable and logged; Table II (the quantitative-comparison rail table) is extracted to tables.csv.

## Cover graphic (unnumbered, PDF p. 1)
- **ID / page:** unnumbered-p1 (img_p001_11.png, 1445×1870)
- **Type:** report cover (graphic design + stock photo)
- **Construction inference:** professional layout; dark-navy diagonal design with orange-tinted glass-building photo; DWT × CBA logos
- **Content exactly as shown:** "Davis Wright Tremaine LLP × CBA | CONSUMER BANKERS ASSOCIATION" logos; title "Agentic AI Payments: Navigating Consumer Protection, Innovation, and Regulatory Frameworks"; "January 2026"
- **Takeaway:** the white paper is **co-branded with law firm Davis Wright Tremaine LLP** (whose partner Eric Goldberg co-led the second webinar) — relevant to the industry-sponsored framing noted in Limitations.
- **Supports:** summary header (venue/year) and the Limitations note on industry sponsorship.

## Figure 1 — Average number of total payments
- **ID / page:** Figure 1, doc p. 16 (PDF p. 18; img_p018_162.png, 783×343); caption in text: "Source: Federal Reserve 2025 Diary of Consumer Choice"
- **Type:** stacked bar chart
- **Construction inference:** vector chart (Excel/PowerPoint-style) embedded as raster; blue title banner; standard legend
- **Axes / legend / series exactly as shown:** x-axis years 2016–2024; y-axis implied average number of monthly payments (unlabeled); stacked series legend: Cash (green), Check (dark navy), Credit (purple), Debit (light blue), ACH (orange), Mobile Payment App (white), Other (pale blue). Bar totals printed atop each bar: **45 (2016), 41 (2017), 43 (2018), 38 (2019), 35 (2020), 36 (2021), 39 (2022), 46 (2023), 48 (2024)**.
- **Takeaway numbers:** cash segment falls 14 (2016) → 7 (2022–2024); credit grows 8 → 17 (2024); debit 12 → 14; ACH 4 → 6; total payments dip to 35 (2020, pandemic) then rebound to 48 (2024) — supports the paper's claim that consumer payments concentrate on card/ACH rails that would carry agentic payments.
- **Quality:** sharp; segment labels readable for major series; small Check/Mobile/Other segments unlabeled per-segment (too thin); no y-axis gridline values — minor.
- **Supports:** summary "Payment rails" discussion (card networks + ACH dominance) and Table II framing.

## Table I — An Emerging Consensus on What Agentic AI Is (doc p. 9)
- **Type:** qualitative comparison table, 4 columns (Feature / Generative AI / Standard Automation (e.g., Autopay) / Agentic AI (Agentic Payment Tools)) × 4 rows (Primary Function, Decision Making, User Role, Example)
- **Key cells:** examples "Write an email to my bank." / "Pay my electric bill on the 15th." / "Find and buy the best laptop under $500 for a 13-year old."; Decision Making: Low / None / High
- **Quality:** clean vector table. **Supports** summary "Definitional core".

## Table II — The Payment Rails Trade-Off (doc p. 18)
- **Type:** ordinal comparison data table; rows Card Networks / ACH / BNPL–Embedded Credit / Stablecoins–x402; columns Settlement Speed / Chargeback Rights / Liability Clarity / Reversibility
- **Values:** Delayed/Yes/High/Yes; Delayed/Limited/Medium/Limited; Varies/Fragmented/Medium-Low/Varies; Instant/None/Low/No
- **Quality:** clean. **Supports** summary Key Results table (verified cell-by-cell, exact match) and skill.yaml `score_rail_consumer_protection`. Extracted to tables.csv.

## Table III — Examples of Vulnerabilities by Stakeholder (doc p. 35)
- **Type:** qualitative matrix; rows Misaligned Incentives / Operational Failure / Data & Privacy / Legal–Liability / TPRM / Market Stability; columns Consumer / Bank-Issuer / Merchant impact
- **Notable cell:** Operational Failure consumer impact "Agent buys wrong item or quantity (e.g., **500 vs 5 apples**)" — internally inconsistent with prose 4.C.i ("5 pounds … approximately 20 apples"); original-paper inconsistency, logged honestly.
- **Supports** summary risk catalog.

## Table IV — Regulatory Gap Analysis (doc pp. 45–46)
- **Type:** qualitative 3-column framework table (Regulatory Domain / Intention of Developers / Framework Today / Agentic AI "Gap"); 7 domains: MRM ("non-bank loophole"), Supervisory Examination ("reactive enforcement"), TPRM ("visibility blind spots"), EFTA/TILA ("access device" trap), Agency Law ("software" exception), UDAP/UDAAP ("opacity barrier"), E-SIGN/UETA ("robo-reader" gap)
- **Supports** summary "Legal gap analysis (Table IV)" — all seven gap names verified verbatim.

## Tables.csv
Extracted: Table II (ordinal ratings). Tables I/III/IV are qualitative-text tables without numeric values; their content is fully logged above rather than forced into CSV.
