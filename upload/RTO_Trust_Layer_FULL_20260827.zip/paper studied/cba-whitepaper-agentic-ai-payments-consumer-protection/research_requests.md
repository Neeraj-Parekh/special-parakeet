# Research Requests — CBA White Paper: Agentic AI Payments

- [High] Implement a "mandate vs. access-device" test in a mock checkout: compare liability outcomes when credentials are shared raw vs. via a signed, scoped mandate token; simulate disputed transactions where the agent exceeded scope and measure how often the evidence package resolves in issuer vs. consumer favor.
- [High] Build an agent-aware fraud simulator that distributes transactions across accounts/merchants/time buckets to evade velocity limits (per paper 4.C.iv) and evaluate which features (device/session attestation, agent-ID, fleet-level aggregation) restore detection power; report AUC/PR-AUC on imbalanced synthetic labels.
- [High] Prototype an FCRA-style dispute flow for agent-initiated payments: expose model inputs + mandate parameters to the disputing consumer and measure resolution time and reversal accuracy vs. a black-box baseline.
- [Med] Quantify rail trade-off impact: simulate chargeback loss rates for card vs. instant-settlement rails under agent error rates from the paper's failure catalog (wrong item, wrong quantity, missed price windows); compute expected consumer losses per 10k orders.
- [Med] Test fraud-model degradation when traffic shifts to cloud-hosted agents: retrain a geo/velocity-based detector with and without agent-origin features and quantify detection drop (paper 4.A.iv mismatch).
- [Med] Design and user-test disclosure language for conflicted recommendation ranking (referral fees/commission-driven ordering); measure comprehension and override rates.
- [Low] Model herding risk: N agents following identical "best value" logic converge on one SKU; measure price spikes, stockouts, and downstream RTO/cancellation rates under staggered vs. synchronized execution.
- [Low] Draft a lightweight "agent certification" checklist (identity, scope enforcement, audit logging, conflict disclosure) and pilot it as a gateway trust registry for a demo merchant checkout.
