# Figures & Tables Deep Dive — challenges-in-deploying-ml-case-studies
Source: `2011.09926v3.pdf` (b5b0896b89b8) — 29 pages, ACM Comput. Surv. 2022. Rendered pages inspected: `page_003.png` (p.3), `page_004.png` (p.4). Embedded img_*.png count: 0. Source text scan: zero mentions of "Figure 1/2/3" — only Table 1.

## Inventory (n=1 logical table, split across 2 pages; 0 figures)

### Table 1 — Taxonomy of deployment challenges (page 3, first half)
- **ID / Page**: Table 1 (caption: "All considerations, issues and concerns explored in this study. Each is assigned to the stage and step of the deployment workflow where it is commonly encountered.") — rendered page 3 (header footer: ACM Comput. Surv., Vol. 1, No. 1, Article 1. Publication date: January 2022. — footer pagination 1:3). Logical page 3 of PDF (page_003.png).
- **Type**: Data table (3-column taxonomy, textual, no numbers/plots)
- **Construction inference**: Vector typeset via LaTeX ACM template (booktabs-style `tabular` with `\hline`, serif body, bold header row, ruled borders). Not matplotlib/gnuplot/hand-drawn/raster screenshot. Crisp vector rendering at ~305KB PNG, >150dpi.
- **Axes / Legend / Units / Series**: Columns exactly: `Deployment Stage | Deployment Step | Considerations, Issues and Concerns`. No units/numeric axes. Header row bold. Row content:
  - `Data management | Data collection | Data discovery`
  - `Data management | Data preprocessing | Data dispersion / Data cleaning` (two rows in cell, line-broken)
  - `Data management | Data augmentation | Labeling of large volumes of data`
  - Footnote `²` below table: "There is a requirements formulation stage that Ashmore et al. do not consider a part of the ML workflow. Similarly, we see this as a challenge across many domains and thus out of scope of this study. We refer interested readers to the work by Takeuchi and Yamamoto [17]." Preserved verbatim.
- **Concrete takeaways readable**: 1 discovery concern in collection, 2 in preprocessing (dispersion, cleaning), 1 in augmentation (labeling volume) on this page; totals continued on next page. Demonstrates mapping granularity Ashmore workflow allows.
- **Quality / editing observations**: High venue quality. Fonts consistent Times/ Libertine serif, header bold sans mix consistent. No blur, no watermark, no cropped axis, no low-res raster. Table borders thin black, cell padding normal. Footnote superscript placement correct. No pasted-from-another-doc appearance. Slightly heavy black lines are ACM style, not artifact.
- **Supports / contradicts summary.md claim**: Directly supports Methodology claim "Analysis: Qualitative mapping ... results consolidated in Table 1" and every Key Results row that cites "Table 1 taxonomy" as organization. No contradiction.

### Table 1 Continued — (page 4, second half)
- **ID / Page**: Table 1. Continued: "All considerations, issues and concerns explored in this study..." — rendered page 4 (header "Andrei Paleyes, Raoul-Gabriel Urma, and Neil D. Lawrence", footer "ACM Comput. Surv., Vol. 1, No. 1, Article 1..." pagination 1:4) — page_004.png.
- **Type**: Data table (continuation of same 3-column taxonomy)
- **Construction inference**: Same LaTeX vector tabular, continuation without repeating caption header style "Table 1. Continued:" in 9pt italic-like. Same crisp vector.
- **Axes / Legend / Units / Series**: Same three columns. Full rows read exactly as image:
  - `(Data management cont.) | (augmentation cont. — blank Stage/Step cell) | Access to experts / Lack of high-variance data` (2 concerns in same blank-step cell, implies under Data augmentation)
  - ` | Data analysis | Data profiling`
  - `Model learning | Model selection | Model complexity / Resource-constrained environments / Interpretability of the model`
  - `Model learning | Training | Computational cost / Environmental impact / Privacy-aware training`
  - `Model learning | Hyper-parameter selection | Resource-heavy techniques / Unknown search space / Hardware-aware optimization`
  - `Model verification | Requirement encoding | Performance metrics / Business driven metrics`
  - `Model verification | Formal verification | Regulatory frameworks`
  - `Model verification | Test-based verification | Simulation-based testing / Data validation routines / Edge case testing`
  - `Model deployment | Integration | Operational support / Reuse of code and models / Software engineering anti-patterns / Mixed team dynamics`
  - `Model deployment | Monitoring | Feedback loops / Outlier detection / Custom design tooling`
  - `Model deployment | Updating | Concept drift / Continuous delivery`
  - `Cross-cutting aspects | Ethics | Aggravation of biases / Fairness and accountability / Authorship / Decision making`
  - `Cross-cutting aspects | Law | Country-level regulations / Abiding by existing legislation / Focus on technical solution only`
  - `Cross-cutting aspects | End users' trust | Involvement of end users / User experience / Explainability score`
  - `Cross-cutting aspects | Security | Data poisoning / Model stealing / Model inversion`
  - Total taxonomy: 4 main stages + 1 cross-cutting, ~10 steps + 4 cross sub-aspects, ~32 individual concerns (count matches source lines 140-224).
- **Concrete takeaways readable**: Enumerates every challenge discussed in §3-7. Headline: every stage has ≥3 concerns; cross-cutting adds 4 major axes. Enables quote: "We do not attempt to prioritize challenges" (p.3 line noted below table).
- **Quality / editing observations**: Identical vector quality to p.3. No blur/watermark. Row lines continuous across page break, no orphans — confirms single Table 1 split for pagination, not two separate tables. Font sizes consistent 8pt table vs 9pt body. No inconsistent pasted image artifact. Venue-quality consistent.
- **Supports / contradicts summary.md claim**: Supports Key Results taxonomy bullets for Model learning through Security, and Limitations note "workflow taxonomy borrowed from Ashmore et al. so classification granularity inherits its choices". Mirrors summary Key Results stage/step mapping exactly. No contradiction; summary correctly lists all 32 concerns albeit condensed into representative bullets.

### Absence statement
- **No figures with plots/diagrams/photos**: Exhaustive text search of b5b0896b89b8.txt (1609 lines) returns zero instances of "Figure" as caption; grep for "Fig." returns only inside references (e.g., cited work figures, not this paper's figures). Rendered pages 3-4 contain only tables; embedded_images count = 0 per figures_index.json. Therefore paper contains **zero line charts, bar charts, heatmaps, confusion matrices, architecture diagrams, flowcharts, photos, or screenshots** produced by authors. Industry examples are described qualitatively via citations, not visualized. This is consistent with a survey paper synthesizing case studies rather than presenting primary experiments.
- **No numeric result tables**: No tables with performance numbers, ablation scores, or statistical tests. Only taxonomy table above. Hence performance claims (e.g., $50k–$1.6m, 70-94%, 650–4013 queries) live in body text and citations, not in tables/figures.

## Summary assessments
- **Venue-quality signal**: High — ACM Computing Surveys production typesetting, consistent serif/sans fonts, vector tables, proper running headers/footers with volume/DOI/footer, footnote handling professional. Not a preprint paste-up despite arXiv v3 tag; publication date footer matches metadata year.
- **Readability**: 100% cleanly readable; no cropped axes or unreadable numbers (no numbers to read beyond stage names).
- **Technique fabric**: No matplotlib/ggplot — pure LaTeX tabular; no color.
- **Editing flags**: None beyond expected ligature handling in txt extraction (ﬁ, ﬂ). No watermarks.

## Cross-check to summary.md
- Methodology "Table 1" reference validated verbatim.
- Every numeric claim in summary Key Results originates from *text citations*, not from these tables — correct per source.
- No figure content missing from summary because no plotted figures exist; summary correctly does not claim any plotted figure.
