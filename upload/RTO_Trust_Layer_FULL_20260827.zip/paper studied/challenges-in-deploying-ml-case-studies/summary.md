# Challenges in Deploying Machine Learning: a Survey of Case Studies

| Field | Value |
|---|---|
| **Authors** | Andrei Paleyes (University of Cambridge), Raoul-Gabriel Urma (Cambridge Spark), Neil D. Lawrence (University of Cambridge) |
| **Venue / Year** | ACM Computing Surveys (ACM Comput. Surv.), 2022 (arXiv:2011.09926v3) |
| **Type** | survey (journal article) |
| **DOI / URL** | https://doi.org/10.1145/3533378 ; arXiv:2011.09926 |
| **Processed** | 2026-08-26T05:29:23Z |
| **Source PDFs** | 2011.09926v3.pdf + sha256 d943c38c |

> Version 2 — v2 full-read verification pass (2026-08-26). Verified against complete 1609-line source + visual inspection of Table 1 (p.3–4); zero plotted figures.
> Version 1 — generated from extracted PDF text.

## Abstract
"In recent years, machine learning has transitioned from a field of academic research interest to a field capable of solving real-world business problems. However, the deployment of machine learning models in production systems can present a number of issues and concerns. This survey reviews published reports of deploying machine learning solutions in a variety of use cases, industries and applications and extracts practical considerations corresponding to stages of the machine learning deployment workflow. By mapping found challenges to the steps of the machine learning deployment workflow we show that practitioners face issues at each stage of the deployment process. The goal of this paper is to lay out a research agenda to explore approaches addressing these challenges."

## Plain-Language Restatement
Getting a machine-learning model to actually work inside a live business system is much harder than training it in a lab. The authors read dozens of published war stories from companies across many industries and catalogued everything that goes wrong, organized by stage of the deployment process: managing data, learning models, verifying them, and running/updating them in production. They show problems appear at every single stage, plus cross-cutting issues around ethics, law, user trust and security. The point is to convince researchers that deployment is worth studying systematically instead of leaving every team to rediscover the same pitfalls.

## Problem Statement
Academic ML literature barely covers the end-to-end difficulty of putting models into production; existing knowledge lives mostly in scattered industry case studies, blog posts and business surveys (e.g., Algorithmia reported most companies take 8–90 days to deploy a single model, with 18% taking longer; an IDC survey of 2,473 organizations found a large share of AI deployments fail due to lack of expertise, biased data and high costs). Prior academic surveys were either narrow (single aspect like explainability, or software-engineering angle e.g. Amershi et al.) or sector-specific; the only general-purpose predecessor (Baier et al.) focused on the IT sector. This survey widens scope across industries and maps concrete practitioner-reported issues onto every step of a defined deployment workflow.

## Methodology
- **Framework**: Adopts the ML deployment workflow of Ashmore et al. with four stages — Data management, Model learning, Model verification, Model deployment — each broken into finer steps; alternatives mentioned include CRISP-DM and TDSP. Stages run partly in parallel with feedback loops; treated as abstraction, not timeline.
- **Corpus**: Published case-study papers (single-project experiences), review papers (ML applications per industry/field), and "lessons learned" papers. Only papers from the last five years considered (few exceptions). No interviews conducted by authors themselves. Business/interview reports (Algorithmia, IDC, O'Reilly, dotscience, dimensional research) used as context.
- **Analysis**: Qualitative mapping of each reported challenge to the workflow stage/step it is encountered at; results consolidated in Table 1 (challenges taxonomy). No quantitative meta-analysis or statistical tests (not stated in text beyond counts of examples).
- **Cross-cutting analysis**: ethics, law, end users' trust, security examined as aspects affecting all stages.

## Key Results
Practitioners face challenges at *every* step. Taxonomy (Table 1) with notable reported evidence:

| Stage | Step | Representative challenge & evidence |
|---|---|---|
| Data management | Collection | Data discovery hard at scale (Twitter microservices scatter entity data); some data only exists in logs or must be generated via synthetic API calls |
| Data management | Preprocessing | Data dispersion/integration: Firebird (Atlanta Fire Dept.) merged 12 datasets; spatial/address cleaning very time-consuming |
| Data management | Augmentation | Labeling volume: one 1-GB/s interface delivers up to 1.5M packets/sec (network traffic); expert-access bottlenecks in medical imaging ("The Final Percent"); RL suffers lack of high-variance data because exploration on real systems is unsafe; label tooling errors up to ~100% for certain applications |
| Data management | Analysis | Data profiling/visualization tools scarce; Microsoft survey: data scientists cite data issues as main reason to doubt work quality |
| Model learning | Selection | Simpler models often chosen: Airbnb search started complex DL, failed repeatedly, shipped a single-hidden-layer NN with 32 ReLU units; Europa Clipper spacecraft used threshold/PCA anomaly detectors for resource reasons; decision trees favored for interpretability (bank churn prediction, manufacturing) |
| Model learning | Training | Cost: full BERT training costs $50k–$1.6m in cloud compute depending on size; environment: neural architecture search emits CO2 comparable to four cars over their lifetime (Strubell et al.); privacy: membership-inference attacks reach 70–94% accuracy against major ML-as-a-service providers |
| Model learning | Hyper-parameter selection | HPO grows exponentially worst-case; unknown search spaces block practical HPO; hardware-aware joint optimization needed for embedded/mobile |
| Model verification | Requirement encoding | Booking.com (150 production models): proxy metrics like clicks often fail to convert to business metrics; need domain/KPI metrics (conversion, cancellations, support tickets); fairness/bias validation recommended |
| Model verification | Formal verification | Rarely done mathematically; banking regulation (UK PRA, ECB guidelines) mandates model-risk frameworks and extensive test suites |
| Model verification | Test-based | Simulation-based testing limited (ISS software-defined-radio cognitive engine experiment could only run subset of planned tests; autonomous vehicles sim-to-real gap); need pipeline data-validation routines (Breck et al.) |
| Model deployment | Integration | Code/model reuse saves effort (Pinterest unified three separate image-embedding efforts into universal embeddings); anti-patterns: glue code, pipeline jungles, correction cascades, abstraction boundary erosion, configuration debt (Sculley et al.); mixed researcher/engineer teams should share codebase, version control, code reviews |
| Model deployment | Monitoring | Community still early on what metrics/alarm triggers matter; feedback loops where models influence own inputs; outlier detection needed (poor calibration → overconfident OOD predictions); police early-intervention-system team had to build all integrity/anomaly/performance checks from scratch — out-of-the-box platforms don't fit problem specifics |
| Model deployment | Updating | Concept drift = changes in p(X,y) (discrete after events, e.g., 2008 financial crisis, or continuous); continuous delivery for ML must handle change along **three axes: code, model, data**; updates can break human trust — "compatible" updates defined by Bansal et al.; backward incompatibility arises from optimization stochasticity/noisy data |
| Cross-cutting: Ethics | Bias amplification | Criminal-justice risk scores proxy race via neighborhood; gender bias in translation (male defaults in STEM fields); darker-skinned females most misclassified in commercial facial analysis; deepfakes/misuse concerns (EMBERS civil-unrest forecaster) |
| Cross-cutting: Law | Regulation | GDPR lacks precise language for 'right to explanation' (Wachter et al.); healthcare data laws slow ML cycles in Japan; DeepMind/Royal Free NHS Streams triggered a data-protection investigation; FDA action plan for medical ML |
| Cross-cutting: Trust | Users | Sepsis Watch: early stakeholder engagement + accountability mechanisms beat interpretability alone as trust-builder; explainability demanded by stakeholders and credit-scoring users (custom XGBoost loan-decision explanations deployed at QuickBooks Capital); UX failures sink adoption ("Brilliant Doctor" rural China; contrast Firebird's tailored UI; EMBERS high-recall vs high-precision UI modes) |
| Cross-cutting: Security | Attacks | Data poisoning: 8% poisoned training samples caused wrong dosage for half of patients (medical linear model); Microsoft Tay corrupted via feedback loop within 16 hours; model stealing: Tramèr et al. replicated production models from Google/Amazon/Microsoft with 650–4,013 queries in 70–2,088s; model inversion recovers private training data from confidence values — GDPR compliance concern |

Solution directions (Section 8): (a) **Tools/services** — end-to-end platforms (AWS SageMaker, Microsoft ML, Uber Michelangelo, TensorFlow TFX, MLflow); QA suites (Jenga, CheckList, Data Linter); weak supervision (Snorkel, Snuba, cleanlab); AutoML (Auto-keras, Auto-sklearn, TPOT) but caution in high-stakes settings; drift detection (Alibi Detect, Azure ML, SageMaker); caveat: each tool adds dependency burden. (b) **Holistic approaches** — datasheets for datasets, model cards, DVC versioning, Data-Oriented Architectures replacing microservices for traceable data flows, ML Technology Readiness Levels (MLTRL), Google best-practices rules (Zinkevich), VDI big-data guidelines for manufacturing.

## Figures & Tables
- **Table 1 (p.3–4, taxonomy data table, LaTeX vector)**: Complete 3-column taxonomy of all deployment challenges mapped to Ashmore workflow — 4 stages + cross-cutting; 32 concerns e.g., Data discovery → Data profiling, Model complexity → Hardware-aware optimization, Regulatory frameworks, Feedback loops/Outlier detection, Concept drift; no numeric plots — purely qualitative stage/step → concern mapping supporting the paper's claim that every stage harbors issues.
- **Zero plotted figures**: No line/bar/heatmap/confusion-matrix/architecture/flowchart/photo/screenshot figures in this survey; all quantitative evidence (e.g., $50k–$1.6m BERT cost, 70–94% membership inference, 650–4013 model-stealing queries) lives in cited body text, not in figures.

## Conclusions & Implications
Authors claim deployment challenges are ubiquitous across all workflow stages and industries, that valuable industry experience goes unpublished, and that academia should engage with these pragmatic problems through cross-disciplinary dialog (software engineering, HCI, systems, policymaking). For practitioners building payment/fintech AI: expect pain at every stage — budget for data integration and labeling, prefer simple interpretable models first (Airbnb lesson), define business-driven metrics before launch (Booking.com lesson), build drift/outlier monitoring bespoke rather than trusting off-the-shelf platforms, treat CD as covering code+model+data, and plan for adversarial attacks (poisoning via feedback loops is directly relevant to fraud models retrained on new labels).

## Limitations
*(Acknowledged by authors)*: coverage far from complete, especially non-technical challenges; no original interviews; only papers from last five years; no prioritization/severity ranking of challenges; brief illustrative-only treatment of tools; no cross-industry comparative analysis yet (proposed as further work). Relative shortage of academic deployment-experience reports means reliance on grey literature. *(Inferred)*: qualitative selection may carry publication/selection bias toward Big-Tech stories; no quantitative frequency estimates per challenge; workflow taxonomy borrowed from Ashmore et al. so classification granularity inherits its choices; findings pre-date LLM-era MLOps tooling.

## Relevance to Our Hackathon
Directly applicable blueprint for shipping the Razorpay-track RTO/fraud model:
- **CI/CD for models**: the "three axes of change" framing (code, model, data) tells us our hackathon demo pipeline needs data-versioned retraining triggers, not just GitHub Actions on code; compatibility-aware updating warns us to regression-test fraud-model score distributions before redeploying.
- **Monitoring**: replicate the police-EIS pattern — checksum-based data-integrity checks, rank-order correlation tracking, top-k churn as performance metric — for RTO predictions; add outlier detection so overconfident out-of-distribution COD shipments get routed to manual review instead of auto-declined.
- **Cost-aware infra**: BERT-scale cost numbers ($50k–$1.6m) and the Airbnb simple-model story justify starting hackathon modeling with logistic/XGBoost-class models and only escalating complexity if business metrics demand it.
- **Business-metric alignment**: Booking.com's proxy-metric failure maps to choosing RTO-relevant KPIs (return rate, delivery success, refund loss) rather than AUC alone.
- **Trust/explainability**: QuickBooks Capital's XGBoost explanation technique is a template for explaining merchant-facing RTO holds; DPDP/GDPR-style constraints echo the law section (model inversion = privacy attack on customer features).
- **Security**: poisoning via feedback loops is realistic when fraud labels come from chargebacks/adversaries — sanitize retraining data.
