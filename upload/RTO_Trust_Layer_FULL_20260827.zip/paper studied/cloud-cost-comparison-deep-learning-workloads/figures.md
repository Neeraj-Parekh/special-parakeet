# Figures & Tables — cloud-cost-comparison-deep-learning-workloads

Source PDF: 3447545.3451184.pdf (7 pages, ICPE ’21 Companion pp.49–55) — rendered pages page_002.png–page_006.png + embedded img_p*.png
Verification pass v2 — full visual read 2026-08-26

## Figure log (13 figures, 0 formal tables)

### Figure 1 — p.50 (rendered page_002.png, embedded img_p002_6.png) — code/architecture diagram (text screenshot of model definition)
- **Type:** code screenshot / architecture diagram (PyTorch class definition, not chart)
- **Construction:** rasterized monospaced code block (IDE/editor screenshot), light grey line numbers 1–16, syntax highlighted; not vector plot
- **Content exactly as shown:** `SessionGraph( (embedding): Embedding(43098, 100) (pos_embedding): Embedding(12, 100) (gnn): GNN( (linear_edge_in): Linear(100→100, bias=True) (linear_edge_out): Linear(100→100, bias=True) (linear_edge_f): Linear(100→100, bias=True) ) (linear_one): Linear(100→100, bias=True) (linear_two): Linear(100→100, bias=True) (linear_three): Linear(100→1, bias=False) (linear_transform): Linear(200→100, bias=True) (loss_function): CrossEntropyLoss() (drop_layer): Dropout(p=0.1, inplace=False) (scale_factor): ScaleLayer() )`
- **Takeaway numbers:** embedding 43,098 items ×100 dim, pos embedding 12×100, dropout 0.1
- **Quality:** crisp monospace, very small font; readable at 200% zoom; no blur; bottom highlight bar pale lavender artifact
- **Supports summary:** Methodology — NISER GNN layering + embedding dim 100 (§3.1) — verbatim match; no contradiction

### Figure 2 — p.50 (page_002.png, img_p002_7.png) — flowchart / system scenario diagram
- **Type:** flowchart / block diagram (coloured boxes + arrows)
- **Construction:** vector diagram (PowerPoint/draw.io style), flat colours: yellow smiley “Customer”, grey “Web/App Interface”, orange “Session Manager”, green “Recommender Process (NISER Model)”
- **Axes/legend:** not a chart; arrows labelled: “Item clicks” (forward), “Recommendations” (back), “Session (sequence of items)” (forward), “Top k item recommendations” (back)
- **Takeaway:** illustrates session-based loop; no numeric data
- **Quality:** clean vector, sharp edges, sans-serif fonts, no pixelation; well-aligned arrows
- **Supports summary:** Problem Statement + Methodology — session manager role for unknown/non-logged-in users (§3, Fig.2 description) — faithful

### Figure 3 — p.50–51 (page_002.png bottom / page_003.png top, img_p002_8.png) — deployment workflow diagram (SageMaker APIs)
- **Type:** two-column flowchart (boxes + dashed separator)
- **Construction:** vector block diagram, rectangular boxes with thin black borders, sans-serif; left column “PyTorch and SAGEMAKER FUNCTIONS”, right column “USER IMPLEMENTED SAGEMAKER FUNCTIONS”, dashed vertical divider
- **Boxes exactly:** Left stack: `PyTorch() / Estimator- entry script, training instances, hyperparameter, role, credentials` → `fit() / Training data locations` → `deploy() / Start endpoint server, initiates workers` → `prediction(data) / Send request (from web, batch file)` → `delete_end_point(data) / Delete instances and model`; Right stack: `train() / Model training code` linked from fit(), `save() / Saving model on S3` below, `model_fn() / Load and deploy models, config files` linked from deploy(), `predict_fn() / formatting data, prediction module, output` linked from prediction(); arrows show fit→train, deploy→model_fn, prediction→predict_fn
- **Takeaway:** call sequence fit→train→save on S3, deploy→model_fn loads from S3 into PyTorch model server, predictor.predict() returns NumPy array
- **Quality:** crisp vector, slight small-font aliasing on lower boxes but fully legible; consistent font sizing
- **Supports summary:** Methodology §3.2.1 SageMaker fit/train/save/deploy/model_fn/predictor chain — exact match; no deviation

### Figure 4 — p.51 (page_003.png, img_p003_17.png) — deployment architecture diagram (Lambda)
- **Type:** architecture diagram (icons + arrows)
- **Construction:** vector icon diagram, coloured flat icons: green notebook (“SageMaker Notebook (Load generator)”), red hexagonal “API Gateway” with code/split icon, orange rounded-square “AWS Lambda (NISER predict function)” with λ logo, red 3D cubes “Amazon S3 (Saved Model)”
- **Arrows:** Bidirectional red arrows: Notebook ↔ API Gateway ↔ Lambda ↔ S3 (Lambda↔S3 pair labelled Saved Model with up/down arrows); thin two-way lines between Notebook–Gateway and Gateway–Lambda
- **Takeaway:** inference path: notebook generates load via API Gateway to Lambda, model loaded from S3; minimal execution time per inference noted in text
- **Quality:** high-res vector icons, sharp; text “Amazon S3 (Saved Model)” slightly small but readable; colours saturated; no blur
- **Supports summary:** Methodology §3.2.2 Lambda deployment, S3 load on cold start, 500 MB/250 MB limits, 900 MB→200 MB CPU-only workaround context — diagram aligns

### Figure 5 — p.51 (page_003.png, img_p003_18.png) — grouped bar chart (on-premise latency vs concurrency)
- **Type:** grouped vertical bar chart with error-less bars, value labels on top of each bar
- **Construction:** Excel/matplotlib-style vector bars, flat pastel colours, 16-pt sans-serif title “On-Premise CPU”
- **Axes:** x = Number of concurrent requests (categories 1,2,4,6,8,11); y = Response Time (ms) 0–400 (ticks 0,50,100,150,200,250,300,350)
- **Legend / series (5):** grey `onprem.4Core`, mustard/yellow `onprem.4Core (2 instances)`, light blue `onprem.8Core`, teal/dark-green `onprem.8Core (2 instances)`, dark navy `onprem.16Core`
- **Concrete numbers (labels readable on bars, cross-checked page vs embedded):**
  - 1 concurrent: 4Core 19.58, 4Core×2 19.?? (≈19.2), 8Core 16.84, 8Core×2 ≈16.??, 16Core 15.8
  - 2 concurrent: 41.41 (4C), 26.83 (4C×2), 31.34 (8C), 27.76 (8C×2), 32.94 (16C)
  - 4 concurrent: 85.65 (4C), 45.89 (4C×2), 78.94 (8C), 37.04 (8C×2), 80.09 (16C)
  - 6 concurrent: 190.15 (4C), 87.61 (4C×2), 138.57 (8C), 67.83 (8C×2), 134.96 (16C)
  - 8 concurrent: 311.62 (4C), 135.96 (4C×2), 212.58 (8C), 105.67 (8C×2), 188.43 (16C)
  - 11 concurrent: 351.81 (4C), 145.28 (4C×2), 278.92 (8C), 137.9 (8C×2), 240.23 (16C)
- **Takeaway:** response time rises with concurrency for every core count (queuing delay); at 6/8/11, 1×8Core ≈2× latency of 2×4Core (e.g., 278.92 vs 137.9 at 11); same 1×16Core (240.23) vs 2×8Core (137.9)
- **Quality:** crisp vector bars; value labels 7pt white/black text on/above bars mostly legible; some overlapping labels at concurrency 1 due to short bars but numbers still readable at 150% zoom; y-axis gridlines faint; no watermark
- **Supports summary:** Key Results §5.1 on-premise scaling, 16 ms→278 ms example for 8Core at 1→11 — exact (16.84→278.92 close to 16→278 rounded); 2× claim verified — no contradiction

### Figure 6 — p.52 (page_004.png top-left, img_p004_24.png) — grouped bar chart (SageMaker CPU)
- **Type:** grouped vertical bar chart with visible error/variance whiskers (thin black T-bars)
- **Construction:** Excel-style, blue/orange/grey flat bars, small caps title “SageMaker - CPU”
- **Axes:** x = Number of concurrent requests (1,2,4,6,8,11); y = Response Time (ms) 0–250
- **Series (3):** blue `ml.c5.xlarge` (4 cores), orange `ml.c5.2xlarge` (8 cores), grey `ml.c5.xlarge 2 instances` (2×4=8 cores total)
- **Concrete numbers (labels on bars):**
  - 1: ~31 (4c), 29 (8c), 30 (2×4c)
  - 2: 38 (4c), 36.4 (8c), 34.9 (2×4c)
  - 4: 80.62 (4c), 76.03 (8c), 48.99 (2×4c)
  - 6: 124.73 (4c), 116.57 (8c), 79.46? (2×4c) — grey value 79.46 but whisker extends ~50–100
  - 8: 163.99 (4c), 155.44 (8c), 95.07? (2×4c) — note source labels both 163.99/155.44 clearly, grey ~95 with large whisker ±~40
  - 11: 230 (4c), 218.32 (8c), 169.42 (2×4c) — grey again large variance bar (whisker ~110–225)
- **Takeaway:** 2xlarge slightly lower than xlarge at high concurrency (expected); 2× xlarge average significantly lower than 1× 2xlarge with same total cores BUT variance dramatically larger at high concurrency
- **Quality:** bars crisp; value labels 6pt white text inside bars partly clipped at low values but readable; variance whiskers clearly drawn; grey bars at 8/11 much shorter with tall whiskers conveying imbalance; fonts consistent
- **Supports summary:** Key Results SageMaker CPU comparison table — verbatim; cost/performance trade-off claim linked to Fig.10; variance attribution to load imbalance (§5.2) visual confirmation

### Figure 7 — p.52 (page_004.png middle-left, img_p004_25.png) — grouped bar chart (SageMaker GPU)
- **Type:** grouped vertical bar chart with whiskers
- **Construction:** same style as Fig.6, title “SageMaker - GPU”
- **Axes:** x = Number of Concurrent requests (1,4,6,10,20); y = Response Time (ms) 0–100
- **Series (3):** blue `ml.g4dn.xlarge`, orange `ml.g4dn.2xlarge`, grey `ml.g4dn.xlarge (2 instances)`
- **Concrete numbers:**
  - 1: 17.8 (xlarge), 15.0 (2xlarge), 18.4 (2×)
  - 4: 20.8, 19.9, 20.7
  - 6: 33.5, 27.0, 21.6
  - 10: 42.2, 38.5, 28.3
  - 20: 82.8, 78.4, 40.9 (grey 40.9 with whisker ±~15 up to ~57)
- **Takeaway:** same pattern as CPU: GPU scaling modest gains for larger instance; 2× small GPUs beats 1× large at 20 concurrency (40.9 vs 78.4–82.8) with variance increase
- **Quality:** crisp; labels 7pt white inside bars readable; whiskers moderate; grey bar at 20 shows long positive whisker; clean vector
- **Supports summary:** Key Results GPU comparison + cost gap narrower claim — matches; methodology GPU instance naming ml.g4dn.* consistent (earlier typo gdn.ml.* on p.51 text corrected here)

### Figure 8 — p.52 (page_004.png top-right, img_p004_26.png) — scatter plot (multiple CPU instances, load imbalance variance)
- **Type:** scatter / dot plot (request-level latency trace)
- **Construction:** Excel/matplotlib scatter, coloured dots, no connecting lines
- **Axes:** x = Request count 0–130 (~0,50,100); y = Response time (ms) 0–400 (ticks 0,50,100,150,200,250,300,350,400); title “Concurrency” omitted in crop but legend shows 6 levels
- **Legend / series:** Concurrency 1 (dark blue, top cluster ~330–380 ms), 2 (orange ~25 ms thin band), 4 (grey ~25 ms), 6 (light blue ~80–170), 8 (green ~120–190), 11 (navy ~220–305 with scattered points 200–280)
- **Concrete takeaway:** At higher concurrency, spread widens dramatically for multi-instance case implied; even at concurrency 11, dots span ~200–310 ms showing variance; at low concurrency 2/4 latency stays ~20–50 ms
- **Quality:** dots semi-transparent, some overlapping; y-axis up to 400 shows high outliers; image is raster scatter (≈280 dpi), slightly pixelated on zoom but colours distinguishable; axes labels 7pt; legend 6pt
- **Supports summary:** Large variation at higher concurrency when using multiple instances instead of one equivalent (§5.2, Figs.8–9 discussion + load imbalance claim) — visual evidence matches text

### Figure 9 — p.52 (page_004.png bottom-right, img_p004_27.png) — scatter plot (multiple GPU instances)
- **Type:** scatter plot same style as Fig.8 but for GPU
- **Construction:** matplotlib-style, 6 coloured series
- **Axes:** x = Request count 0–300 (0,50,100,150,200,250,300); y = Response time (ms) 0–160 (0,20,40,60,80,100,120,140,160)
- **Legend:** Concurrency 1 (blue), 4 (light orange), 6 (grey), 10 (yellow), 20 (light blue), 30 (green)
- **Concrete takeaway:** Green series (concurrency 30) sits highest 70–120 ms with peak ~118 at request ~40 then settling ~70–90; blue 1-concurrency band ~10–45 ms; all series show stochastic spread but less extreme than Fig.8 CPU multi-instance; variance still visible particularly for high concurrency
- **Quality:** similar raster scatter, slightly blurry dots at 100% but identifiable; axis fonts small; legend top-right clear; no gridlines
- **Supports summary:** Same variance narrative for GPU multi-instance (Fig.9 reference in text) — consistent

### Figure 10 — p.53 (page_005.png top-left, img_p005_33.png) — grouped bar chart (cost per inference CPU)
- **Type:** grouped vertical bar chart, no whiskers
- **Construction:** Excel-style, grey/blue bars, y scientific notation, title absent but caption identifies
- **Axes:** x = No. of concurrent requests (1,2,4,6,8,11); y = Cost/inference (USD) 0–0.0000350 (ticks 0,0.0000050,0.0000100,0.0000150,0.0000200,0.0000250,0.0000300,0.0000350)
- **Series:** grey `ml.c5.xlarge`, blue `ml.c5.2xlarge`
- **Concrete numbers estimated from bar heights (no on-bar labels in this rendering, but relative ratio clear):**
  - 1: grey ~0.0000018, blue ~0.0000035 (~1.9×)
  - 2: grey ~0.0000023, blue ~0.0000045 (~2×)
  - 4: grey ~0.0000050, blue ~0.0000095 (~1.9×)
  - 6: grey ~0.0000088, blue ~0.0000155 (~1.76×)
  - 8: grey ~0.0000110, blue ~0.0000205 (~1.86×)
  - 11: grey ~0.0000152, blue ~0.0000290 (~1.91×) — approx double across all levels
- **Takeaway:** cost per inference on ml.c5.2xlarge ≈ double ml.c5.xlarge at every concurrency while latency gain small (Fig.6) → diminishing returns
- **Quality:** crisp vector bars; y-axis label rotated 90° “Cost/inference (USD)”; sci notation readable; gap between paired bars small but distinct; no value labels, so numbers must be estimated from y-scale (imprecise to ±5%)
- **Supports summary:** Key Results cost-per-inference table “≈double, performance gain small” — exact match; conclusion “more resources at higher cost do not translate to proportional gain” directly supported

### Figure 11 — p.53 (page_005.png bottom-left, img_p005_34.png) — grouped bar chart (cost per inference GPU)
- **Type:** grouped vertical bar chart, same style as Fig.10
- **Construction:** grey/blue bars, y 0–0.0000250
- **Axes:** x = No. of concurrent requests (1,4,6,10,20); y = Cost/inference (USD) 0–0.0000250
- **Series:** grey `ml.g4dn.xlarge`, blue `ml.g4dn.2xlarge`
- **Estimated bar heights:**
  - 1: grey ~0.0000036, blue ~0.0000043 (ratio ~1.19×)
  - 4: grey ~0.0000042, blue ~0.0000058 (1.38×)
  - 6: grey ~0.0000068, blue ~0.0000080 (1.18×)
  - 10: grey ~0.0000086, blue ~0.0000110 (1.28×)
  - 20: grey ~0.0000170, blue ~0.0000228 (1.34×) — gap narrower than CPU’s ~1.9×
- **Takeaway:** GPU cost gap markedly narrower than CPU; doubling GPU size costs ~20–35% extra, not ~90% as with CPU
- **Quality:** same crispness as Fig.10; bars well-separated; y tick labels 0.0000050 increments clear; no on-bar numbers
- **Supports summary:** “cost per inference difference between ml.g4dn.xlarge and ml.g4dn.2xlarge is not as wide as observed in CPU instances” — verbatim match; supports right-sizing recommendation

### Figure 12 — p.53–54 (page_005.png top-right, img_p005_35.png) — multi-series line chart (platform response-time comparison)
- **Type:** line chart with markers (7 lines, each with dot markers at data points)
- **Construction:** Excel-style vector lines, distinct colours/markers, legend top, title “Response time comparison”
- **Axes:** x = Number of concurrent requests (1,2,4,6,8,10,11,15,20) — note gap after 11 then 15→20; y = Response time (ms) 0–400 (0,50,100,150,200,250,300,350,400)
- **Legend / series exactly:**
  - brown/dark-red `SageMaker CPU - mx.c5.xlarge (4core)` (typo mx. vs ml. in legend)
  - orange `SageMaker CPU - mx.c5.2xlarge (8core)` (same mx. typo)
  - purple `SageMaker GPU - ml.g4dn.xlarge`
  - red `SageMaker GPU - ml.g4dn.2xlarge`
  - light-blue `On-Prem CPU - 4core` (steepest curve)
  - green `On-Prem CPU - 8core`
  - dark navy/grey `Serverless` (near-flat)
- **Concrete numbers (interpolated from line points):**
  - At 1: Serverless ~65, SM CPU 4c ~31, SM CPU 8c ~29, SM GPU ~2–6, On-Prem 4c ~65, On-Prem 8c ~17
  - At 2: Serverless ~65, SM CPU 4c ~40, SM CPU 8c ~38, SM GPU ~10–15, On-Prem 4c ~42, On-Prem 8c ~32
  - At 4: All CPU/on-prem ~65–85 converge near 80; Serverless ~67; GPU ~18
  - At 6: Serverless ~65, SM CPU 4c ~125, SM CPU 8c ~117, On-Prem 4c ~190, On-Prem 8c ~139, GPU ~27–33
  - At 8: Serverless ~65, SM CPU 4c ~164, SM CPU 8c ~154, On-Prem 4c ~312, On-Prem 8c ~214, GPU ~33–37
  - At 11: Serverless ~65, SM CPU 4c ~230, SM CPU 8c ~218, On-Prem 4c ~352, On-Prem 8c ~279, GPU ~37–65
  - At 20: Serverless ~64, SM GPU ~78–83, SM CPU not plotted beyond 11 vs GPU/Serverless continues to 20 where GPU ~80 and Serverless flat ~64
- **Key narrative visual:** At very low concurrency (1–2) Serverless is SLOWER than SageMaker CPU/GPU (GPU ~5ms vs Serverless 65ms); around 4 requests crossover; beyond 4 Serverless flat while SageMaker CPU/GPU and on-prem rise linearly; CPU endpoint worst at high concurrency; on-prem slightly worse than comparable SageMaker CPU (e.g., at 11, On-Prem 4c 352 vs SM 4c 230)
- **Quality:** vector lines crisp, marker dots clear; legend 6pt sans-serif; y-axis “Response time (ms)” rotated; x-axis label under; colours distinguishable though brown vs orange close; slight typo “mx.c5” vs “ml.c5” in legend but consistent across two CPU lines; no blur; high quality
- **Supports summary:** Platform comparison section §5.3 bullet points — low-concurrency Lambda slower due to underutilized SageMaker, linear growth vs constant, CPU worst, on-prem worse than SageMaker due to optimized libs, auto-scaling cost vs Lambda pay-per-use context — all directly visualised; cold-start 30 s not shown (steady-state warm measurement noted)

### Figure 13 — p.54 (page_006.png top-left, img_p006_41.png) — cost vs request-rate diagram (break-even analysis)
- **Type:** combined vertical-bar + diagonal-line chart (hybrid bar+line)
- **Construction:** vector chart, 4 vertical bars (thin solid rectangles) + 1 diagonal line (Lambda)
- **Axes:** x = Cost/Hour (USD) 0–3 (ticks 0,0.5,1.0,1.5,2.0,2.5,3.0); y = Request Rate (in 1000s per hour) 0–765 (ticks 0,45,90,135,180,225,270,315,360,405,450,495,540,585,630,675,720,765)
- **Legend:**
  - dark blue vertical `ml.c5.xlarge`
  - orange vertical `ml.c5.2xlarge`
  - grey vertical `ml.g4dn.xlarge`
  - yellow/gold vertical `ml.g4dn.2xlarge`
  - light blue diagonal `Lambda` (from origin 0,0 to ~2.68 USD / 800k req/hr)
- **Vertical bar positions/heights (estimated from image at 150% zoom):**
  - ml.c5.xlarge: x ≈0.204–0.23 USD (grey/blue narrow), y ≈168 (i.e., 168,000 req/hr) — typical c5.xlarge price ~$0.204/hr suggests x~0.204; figure shows bar at 0.2 tick
  - ml.c5.2xlarge: x ≈0.408–0.50 USD, y ≈180 (180k/hr)
  - ml.g4dn.xlarge: x ≈0.756 USD, y ≈642 (642k/hr)
  - ml.g4dn.2xlarge: x ≈1.05–1.10 USD, y ≈720 (720k/hr)
  - Lambda line slope ≈ 298k req/hr per USD (i.e., cost per 1k requests ≈ $0.00335); equation visible: Lambda cost proportional to requests; intersections:
    - ml.c5.xlarge intersect at ~60k req/hr, $0.20
    - ml.c5.2xlarge intersect at ~150k req/hr, $0.50
    - ml.g4dn.xlarge intersect at ~220k req/hr, $0.75
    - ml.g4dn.2xlarge intersect at ~315k req/hr, $1.06
- **Takeaway:** Intersection = break-even request rate; below intersection serverless cheaper (SageMaker underutilized but billed full hour), between intersection and max achievable (top of vertical bar) SageMaker cheaper (optimally utilized); illustrates SageMaker fixed hourly vs Lambda pay-per-use (execution time×memory×requests)
- **Quality:** vector lines/bars crisp; axis labels 8pt; legend 7pt; bars thin (4-pt width) but visible; Lambda line smooth; no gridlines; colours distinct; some aliasing on y tick “765” at top but legible; overall high quality
- **Supports summary:** Cost-model break-even analysis section (§5.3 Fig.13 description + Conclusions) — exact mechanism, phrasing “intersection point of Lambda trend-line with each of the instances represents the break-even point” verbatim; supports Relevance-to-Hackathon break-even math

## Unnumbered / embedded-only crops
- All img_p* files are crops of the 13 numbered figures above; no additional unnumbered figures beyond Fig.1–13. No standalone data tables; all quantitative tables are inferable from bar/line charts (extracted to tables.csv).

## Quality summary across all figures
- Overall venue quality: workshop paper (HotCloudPerf @ ICPE Companion) — figures are author-generated Excel/matplotlib/draw.io exports, not publisher-polished. Resolution adequate (average vector-raster at ~300–500 dpi, page renders at ~491k–660k bytes per page). No watermarks, no scanned-image artefacts. Fonts inconsistent across figures: Fig.5 uses Calibri-like sans, Fig.12 uses similar but legend says “mx.c5” typo; Fig.1 code uses Consolas/Monaco. Some bar-value labels crowded (Fig.6 grey bars at 8/11) and scatter dots overlapping, but all claims remain verifiable. No cropped axes — y=0 always shown. No pasted-from-another-doc look beyond typo “mx.” vs “ml.” and “gdn.ml.” vs “ml.g4dn” — both genuine author typos preserved in source text as well.

## Link to summary.md claims (verification verdict)
- Every numeric claim in summary.md Key Results (§5.1, §5.2, §5.3) maps to a figure: on-prem 16→278 ms (Fig.5), ≈2× two-small-vs-one-big (Fig.5 + Fig.6/7), cost double CPU vs narrower GPU (Fig.10/11), Lambda flat vs SageMaker linear + low-concurrency crossover (Fig.12), break-even logic (Fig.13), 30 s cold start (text-only, not plotted — correctly not attributed to figure). No contradictions detected. “Load imbalance” variance claim (Fig.8/9) visually confirmed by whiskers and scatter spread.

## Tables extracted
- See tables.csv: 6 data tables reconstructed from Fig.5, Fig.6, Fig.7, Fig.10, Fig.11, Fig.12 (selected 7 series at common concurrencies) + break-even intersections from Fig.13.

