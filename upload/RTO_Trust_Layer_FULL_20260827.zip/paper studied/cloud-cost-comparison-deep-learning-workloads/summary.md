# Performance and Cost Comparison of Cloud Services for Deep Learning Workload

| Field | Value |
|---|---|
| **Authors** | Dheeraj Chahal, Mayank Mishra, Surya Palepu, Rekha Singhal (TCS Research, Mumbai, India) |
| **Venue / Year** | HotCloudPerf 2021 Workshop @ ICPE '21 Companion (ACM/SPEC Int'l Conference on Performance Engineering), April 19–23, 2021, Virtual Event, France; pp. 49–55 |
| **Type** | workshop paper (experimental evaluation) |
| **DOI / URL** | https://doi.org/10.1145/3447545.3451184 |
| **Processed** | 2026-08-26T05:29:23Z |
| **Source PDFs** | 3447545.3451184.pdf + sha256 73067863 |

> Version 2.0.0 — v2 full-read verification pass (word-by-word + figure deep-dive). Source sequentially read in 1200-line chunks (529 lines single chunk); notes at .cache/notes/cloud-cost-comparison-deep-learning-workloads.md; figures logged in figures.md; tables in tables.csv.

## Abstract
"Many organizations are migrating their on-premise artificial intelligence workloads to the cloud due to availability of cost-effective and highly scalable infrastructure, software and platform services. To ease the process of migration, many cloud vendors provide services, frameworks and tools that can be used for deployment of applications on cloud infrastructure. Finding the most appropriate service and infrastructure for a given application that results in a desired performance at minimal cost, is a challenge. In this work, we present a methodology to migrate a deep learning model based recommender system to ML platform and serverless architecture. Furthermore, we show our experimental evaluation of AWS ML platform called SageMaker and the serverless platform service known as Lambda. In our study, we also discuss performance and cost trade-off while using cloud infrastructure."

## Plain-Language Restatement
When companies move AI systems to the cloud, they must choose between managed ML platforms (always-on servers you pay for by the hour) and serverless functions (you pay only per request). The authors took a real deep-learning product recommender (NISER) and measured speed and cost of serving it on AWS SageMaker versus AWS Lambda, plus their own on-premise server. They found that bigger machines cost about double per prediction but give only small speed gains, that splitting load over several smaller machines beats one big machine, and that serverless wins for bursty traffic while always-on endpoints win when traffic is steady and high.

## Problem Statement
Choosing cloud infrastructure that meets a performance target at minimal cost is hard: vendors offer many instance types and paradigms (ML platforms like SageMaker/Azure ML/TFX/MLflow for automated training-deployment-inference vs serverless like Lambda/Azure Functions/Google Cloud Functions/IBM OpenWhisk). Prior comparisons were missing: SageMaker-vs-serverless comparison for a DL recommender had not been explored ("first effort" claim); prior work (Zheng et al./MArk) studied SLO-aware inference but not this platform pairing at different instance scales.

## Methodology
- **Workload**: NISER — a graph neural network (GNN) based session-based recommendation model (Gupta et al., arXiv:1909.04276) predicting next top-k items from click sequences; items represented as embeddings of length 100. Useful for unknown/non-logged-in users since it needs only recent actions.
- **Deployment schemes**:
  - *On-premise*: Intel server, 28 physical cores, 256 GB memory; Python 3.6, PyTorch version 17.1 (as printed) on CentOS 7; NISER process given 4, 8 or 16 cores; also tested 2 process instances. Load generated via Jupyter notebook.
  - *AWS SageMaker*: fit API → train method in PyTorch estimator entry script; training data pre-loaded on S3; trained model saved to S3; deploy API → model_fn loads from S3 into a SageMaker PyTorch model server inside an endpoint; predictor.predict() returns NumPy array. Instances: ml.c5.large, ml.c5.xlarge (4 vCPU) and ml.c5.2xlarge (8 vCPU) CPU; ml.g4dn.xlarge and ml.g4dn.2xlarge GPU families.
  - *AWS Lambda*: deployment/inference only (training via SageMaker APIs). Constraints hit: Lambda gives 500 MB total storage, only 250 MB for deployment packages; full PyTorch+NumPy ≈ 900 MB, so CPU-only PyTorch build (~200 MB) was used. Each function configured with 3 GB memory ⇒ 2 vCPU cores allocated. Model loaded from S3 on first request (cold start); event-handler code contains predict(). Serverless experiments used provisioned concurrency; timings taken warm and in steady state.
- **Metrics & protocol**: round-trip response time under increasing concurrency (number of concurrent users); cost per inference; maximum achievable request rate vs hourly fixed cost; steady-state data points. No statistical tests reported.

## Key Results

**On-premise scaling behavior:**
- Response time rises with concurrency regardless of core count: e.g., 8-core allocation goes 16 ms (1 request) → 278 ms (11 concurrent requests), mainly queuing delay.
- At concurrency 6/8/11, one 8-core instance ≈ **2× the response time** of two 4-core instances; same pattern for one 16-core vs two 8-core.

**SageMaker instance comparison (CPU):**

| Setup | Observation |
|---|---|
| ml.c5.xlarge (4 cores) vs ml.c5.2xlarge (8 cores) | 2xlarge slightly lower latency at high concurrency |
| 2× ml.c5.xlarge (8 cores total) vs 1× ml.c5.2xlarge (8 cores) | 2-instance average response time significantly lower; BUT larger variance at high concurrency due to load imbalance distributing requests across model servers |

**Cost per inference:**

| Comparison | Result |
|---|---|
| ml.c5.2xlarge vs ml.c5.xlarge (CPU) | Cost/inference ≈ **double**, performance gain small |
| ml.g4dn.2xlarge vs ml.g4dn.xlarge (GPU) | Cost/inference gap narrower than CPU case |

Conclusion drawn: more resources at higher cost do not translate to proportional performance gains; users must match SLA + budget.

**Platform comparison (on-prem vs SageMaker CPU/GPU vs Lambda):**
- At very low concurrency Lambda is slower than SageMaker CPU/GPU (SageMaker resources underutilized).
- As concurrency rises: SageMaker saturates and latency grows linearly; Lambda spawns instances proportional to requests giving roughly constant response time; CPU endpoint worst at high concurrency (vs GPU endpoint and Lambda).
- On-premise response time slightly worse than comparable SageMaker CPU — attributed to optimized libraries/environment in SageMaker.
- SageMaker auto-scaling mitigates latency growth but costs more than pay-per-use; scaling takes minutes vs seconds for serverless.
- Cold start observed on Lambda: **30 seconds** for first request.

**Cost-model break-even analysis:**
- SageMaker cost ∝ uptime (independent of usage); Lambda cost = f(execution time, memory, number of requests).
- Plotting Lambda cost trend against each instance's hourly price: intersection = **break-even request rate**. Below it → serverless cheaper (instances underutilized but billed full hour); between break-even and max achievable rate → SageMaker cheaper (instances optimally utilized).

Contextual figures cited from related work: Uber Michelangelo ~1 million predictions/sec, Facebook FBLearner ~6 million predictions/sec; SPEC RG Cloud catalogued 86 serverless use cases.

## Figures & Tables

- **Figure 1 (p50, code diagram):** NISER `SessionGraph` PyTorch definition — embeddings 43,098×100 + pos 12×100, GNN, 3 linear_edge, 4 linear layers, CrossEntropyLoss, Dropout 0.1.
- **Figure 2 (p50, flowchart):** Session-based recommendation loop — Customer → Web/App Interface → Session Manager ⇄ Recommender Process (NISER) — shows item-clicks/session and top-k recommendation flow for anonymous users.
- **Figure 3 (p50–51, workflow):** SageMaker API call chain — `PyTorch() → fit() → deploy() → prediction() → delete_end_point` mapped to user `train()/save()/model_fn()/predict_fn()` with S3 persistence and `predictor.predict()` returning NumPy array.
- **Figure 4 (p51, architecture):** Lambda deployment — SageMaker Notebook (load generator) ↔ API Gateway ↔ AWS Lambda (NISER predict) ↔ Amazon S3 (Saved Model); illustrates 500 MB/250 MB package limits and S3 cold-load path.
- **Figure 5 (p51, grouped bar, On-Premise CPU):** Latency vs concurrency 1/2/4/6/8/11 — 8Core 16.84 ms→278.92 ms; at 6/8/11 one 8Core ≈2× two 4Cores (e.g., 278.92 vs 137.9 at 11); same for 1×16Core vs 2×8Core.
- **Figure 6 (p52, grouped bar, SageMaker CPU):** ml.c5.xlarge (4c) vs ml.c5.2xlarge (8c) vs 2× ml.c5.xlarge — 2× small avg significantly lower (e.g., 79.46 vs 124.73 at 6) but variance whiskers explode at 8/11 (load imbalance).
- **Figure 7 (p52, grouped bar, SageMaker GPU):** ml.g4dn.xlarge vs ml.g4dn.2xlarge vs 2× ml.g4dn.xlarge — same pattern; at 20: 82.8/78.4 vs 40.9 ms showing horizontal win.
- **Figure 8 (p52, scatter, CPU multi-instance):** Request-count vs latency dots for concurrency 1/2/4/6/8/11 — spread widens at high concurrency (11: ~200–310 ms) visually proving load-imbalance variance.
- **Figure 9 (p52, scatter, GPU multi-instance):** Same for concurrency 1/4/6/10/20/30 — green 30 peaks ~118 ms at req ~40 then ~70–90 ms; variance smaller than CPU but still present.
- **Figure 10 (p53, grouped bar, cost CPU):** Cost/inference (USD) — ml.c5.2xlarge ≈2× ml.c5.xlarge at every concurrency (e.g., 0.0000152 vs 0.000029 at 11) for negligible latency gain.
- **Figure 11 (p53, grouped bar, cost GPU):** Cost/inference GPU — gap narrower (~1.2–1.35×, e.g., 0.000017 vs 0.0000228 at 20) vs CPU’s ~1.9×.
- **Figure 12 (p53, 7-line chart, platform comparison):** SageMaker CPU/GPU vs On-Prem 4c/8c vs Serverless (warm) — Serverless flat ~65 ms; SageMaker underutilized at 1–2 (GPU ~5 ms beats 65 ms), then Lambda wins after ~4; CPU worst at 11 (SM 230 vs On-Prem 352, Serverless 65); on-prem slightly worse than SM equivalent (optimized libs).
- **Figure 13 (p54, bar+diagonal, break-even):** Cost/Hour (USD) vs Request Rate (1k/hr) — vertical bars ml.c5.xlarge ~0.20/168k, ml.c5.2xlarge ~0.50/180k, ml.g4dn.xlarge ~0.75/642k, ml.g4dn.2xlarge ~1.06/720k; Lambda diagonal slope ~0.00335/1k; intersections at ~60k/150k/220k/315k are break-even rates (below Serverless cheaper, between→SageMaker cheaper).

Full visual log and numeric extract: `figures.md` + `tables.csv`; all figures vector/raster Excel-style, high quality, no blur/watermark, y=0 shown, legend typo “mx.c5” vs “ml.c5” preserved.

## Conclusions & Implications
Authors conclude: (a) scaling up instance size does not proportionally improve cost-efficiency; (b) horizontal splits (two smaller instances) outperform one equivalent big instance on average latency but add imbalance-induced variance; (c) serverless auto-scaling beats dedicated endpoints for bursty workloads, while ML platforms win for long-running workloads with optimal utilization; (d) hybrid balancing — redirect bursty traffic to serverless while keeping an always-on ML-platform baseline — can mitigate cold starts without over-provisioning; future work targets profiling-driven mapping of apps to optimal infrastructure using on-premise characterization models. For practitioners: measure your own break-even request rate before choosing serving infra, prefer many-small over one-big, and budget for cold-start mitigation if going serverless.

## Limitations
*(Acknowledged)*: SageMaker and Lambda have fundamentally different pricing models making comparison inherently challenging; cold start remains unsolved (they only cite mitigation literature); auto-scaling granularity differences (minutes vs seconds). *(Inferred)*: single model (NISER, embedding dim 100) and single region/vendor (AWS) limit generality; absolute numbers are 2021 prices/hardware; no confidence intervals or repeated-trials statistics; load imbalance cause asserted not instrumented; training cost excluded from comparison (inference only); Lambda package-size workaround (CPU-only PyTorch) means GPU-class serverless inference untested.

## Relevance to Our Hackathon
This paper is the playbook for **cost-aware serving choices for the RTO/fraud risk scoring service at Razorpay scale**:
- **Break-even math**: compute the fraud/RTO inference break-even request rate exactly as Figure 13 does (hourly endpoint cost ÷ per-request Lambda cost) to justify our hackathon demo's infra choice; bursty checkout-hour traffic favors serverless, steady batch scoring favors dedicated endpoints.
- **Horizontal scaling rule**: deploy 2 small containers instead of 1 large one behind the load balancer (paper's 2× latency finding), but expect tail-latency variance from load imbalance — relevant to p99 SLAs on payment-path decisions.
- **Cost-per-inference discipline**: doubling machine size ≈ doubling cost for marginal gain — so right-size scoring instances and spend savings on monitoring instead.
- **Cold starts**: a 30 s cold start is unacceptable for inline payment authorization; keep warm pools/provisioned concurrency or fall back to an always-on endpoint for synchronous paths, serverless for async re-scoring/burst.
- **Package constraints**: model artifacts must fit serverless limits (250 MB deployment package lesson) → quantize/prune the RTO model or split artifact loading from S3.
- **Methodology transfer**: the paper's measurement protocol (round-trip latency vs concurrency, steady-state sampling, warm functions) is directly reusable as our hackathon benchmark harness.
