# Cost Curves: An Improved Method for Visualizing Classifier Performance

| Field | Value |
|---|---|
| **Authors** | Chris Drummond, Robert C. Holte |
| **Venue / Year** | Machine Learning (Springer), Vol. 65, pp. 95–130, 2006 (received 18 May 2005, accepted 5 March 2006, published online 8 May 2006) |
| **Type** | journal article |
| **DOI / URL** | DOI 10.1007/s10994-006-8199-5 |
| **Processed** | 2026-08-26T05:29:31Z |
| **Source PDFs** | s10994-006-8199-5.pdf — published journal version, primary (sha256 prefix 60e05dbe); ML_2006.pdf — 23 Nov 2005 revised-manuscript preprint, secondary (sha256 prefix 89ed1b75) |

> Version 1 — generated from extracted PDF text.

## Abstract

"This paper introduces cost curves, a graphical technique for visualizing the performance (error rate or expected cost) of 2-class classifiers over the full range of possible class distributions and misclassification costs. Cost curves are shown to be superior to ROC curves for visualizing classifier performance for most purposes. This is because they visually support several crucial types of performance assessment that cannot be done easily with ROC curves, such as showing confidence intervals on a classifier's performance, and visualizing the statistical significance of the difference in performance of two classifiers. A software tool supporting all the cost curve analysis described in this paper is available from the authors."

## Plain-Language Restatement

When you compare two fraud-detection models, a single number like accuracy or AUC hides crucial information: which model is better depends on how common fraud is and how costly each kind of mistake is. ROC curves capture this but are hard to read — slopes must be judged visually and you cannot easily tell if one model's advantage is statistically real. This paper introduces "cost curves": plot expected cost on the y-axis against probability-times-cost PC(+) on the x-axis, so every classifier becomes a straight line whose height directly *is* its performance at that operating condition. Crossing points, advantage sizes, confidence intervals, and significance all become simple vertical readings.

## Problem Statement

Scalar measures (error rate, AUC) impose "a one-dimensional ordering on what is fundamentally two dimensions of performance" and cannot show under which costs/class ratios one classifier beats another — Adams & Hand are quoted: if ROC curves cross, "a summary measure integrating over all possible values of the cost ratio would be worthless." ROC plots preserve information but cannot answer seven questions researchers routinely ask by visual inspection: (1) classifier's expected cost given specific costs/class probabilities; (2) when it beats trivial always-positive/always-negative classifiers; (3) when C1 outperforms C2; (4) size of the performance difference; (5) averaging results over independent evaluations (e.g., 10-fold CV); (6) confidence intervals on performance; (7) where differences between C1 and C2 are statistically significant. The paper fills this methodological gap with a representation exploiting human visual strengths.

## Methodology

Theory + visualization methodology paper, illustrated on UCI datasets (Japanese credit, German credit, Sonar, Splice referenced; experiments with C4.5, 1R decision stumps, Naive Bayes):

1. **ROC recap**: confusion matrix → TP/FP rates; convex hull via iso-performance line slope TP1−TP2)/(FP1−FP2) = [p(−)·C(+|−)]/[p(+)·C(−|+)]; operating range defined by slopes to trivial points (0,0), (1,1).
2. **Cost-curve construction**: bidirectional point/line duality with ROC space. A classifier = straight cost line from (0, FP) to (1, FN): Y = (FN − FP)·p(+) + FP. Generalized axes:
   - x-axis PC(+) = p(+)·C(−|+) / [p(+)·C(−|+) + p(−)·C(+|−)] ("probability times cost"), ranges 0–1;
   - y-axis normalized expected cost Norm(E[Cost]) = [FN·p(+)·C(−|+) + FP·p(−)·C(+|−)] / [same denominator] = FN·PC(+) + FP·PC(−).
   - Inverse mappings: slope S in ROC space ↔ X = 1/(1+S) in cost space.
   - Dominance ↔ being below everywhere; ROC upper convex hull ↔ lower envelope of cost lines (hull points = envelope segments).
3. **Seven analyses** (one section each):
   - Performance reading: direct y-value; contrasted with Flach's diagonal-intersection construction on ROC plots.
   - Operating range vs trivial classifiers: exact intersection intervals read off diagonals (e.g., lower envelope operating range 0.17 < PC(+) < 0.84 on sonar vs approximate ROC estimate 0.05–0.94); reproduced Domingos (1999)-style oversampling/undersampling experiments on sonar — oversampled trees' operating range 0.28 < PC(+) < 0.75, undersampled 0.25 < PC(+) < 0.82, both excluding the extreme tested cost ratios 5:1 and 10:1, i.e., such classifiers should never be deployed there.
   - Classifier choice: crossing point of cost lines directly gives the PC(+) where models tie (Japanese credit example: 1R stump vs C4.5 tree cross at p(+) = 0.445).
   - Difference magnitude: vertical distance = weighted-Manhattan (not Euclidean) expected-cost difference, E[Cost1] − E[Cost2] = (TP2−TP1)·p(+)·C(−|+) + (FP1−FP2)·p(−)·C(+|−); example pair differs ~20% max (0.25 vs 0.3) near PC(+) ≈ 0.3/0.7 and negligibly near 0.5; tangled C4.5 splitting-criterion ROC curves (DKM/ENT/GINI/ACC from Drummond & Holte 2000b) become cleanly separated cost curves showing DKM≈ENT for 0.3<PC(+)<0.6.
   - Averaging: vertical vs horizontal ROC averaging both fail (average curve's cost ≠ average of costs); vertical averaging in cost space averages performance per operating point — the desired estimate — and maps back onto the iso-performance line joining the two original ROC vertices.
   - Confidence intervals: bootstrap resampling of the confusion matrix conditioned on row marginals (deployment class frequency fixed/unknown; two binomials; ≥500 resamples typically, 100 shown for exposition; O(n²) interval algorithm of Miller et al.); σ_NEC = √(p(+)²σ²_FN + (1−p(+))²σ²_FP) is minimized at p(+) = m/(m+n), the test-set class distribution (when P1=P2) — hence intervals narrowest there and broadest at extremes.
   - Significance testing: overlapping individual CIs is unsound (equivalent to assuming perfect negative correlation ρ=−1; σ_Z ranges from |σX−σY| at ρ=1 to σX+σY at ρ=−1). Correct method: bootstrap a 3-dimensional confusion matrix (two layers by true class, rows/columns = labels by each classifier; sample two 4-valued multinomials per layer) which captures classifier correlation without estimating ρ; subtract paired cost lines to get a distribution of difference-lines and its CI. Difference significant wherever the zero line exits the band; can be significant only for part of the range (e.g., only if PC(+) > 0.7).
4. **Hybrid classifiers / selection criteria** (Section 5): performance-independent criterion (train/test conditions matched, e.g., threshold = PC(+)) visualizable as bold segments; cost-minimizing selection (= ROC convex hull / lower envelope) shown strictly better — Naive-Bayes-on-sonar hybrid under performance-independent selection is suboptimal almost everywhere and worse than trivial classifiers for PC(+) < 0.2 or > 0.7 (only large-scale study cited: Weiss & Provost 2003); Neyman-Pearson criterion (fix max FP, maximize TP) easy in both spaces; workforce-utilization constraint TP·P + FP·N ≤ W is a negatively sloped ROC line mapping to a possibly far-out-of-range negative PC(+) point — ROC preferable here. Empirical selection criteria make piecewise cost curves biased estimates unless retested on fresh data (citing Bengio & Mariéthoz 2004), which changes proper comparative-experiment design.
5. **Limitations section**: binary focus (multi-class math extends trivially but visualization needs 1-vs-all projections; bootstrap suffers sparsity), class-based additive cost model, prior-shift-only notion of "all" distributions (Webb & Ting 2005), single loss function (relation to Expected Performance Curves of Bengio et al. 2005), no multi-dataset single plot, individual cost lines hard to see among many (remedy: highlight), and inapplicability to ranking tasks (hence PR/lift curves excluded).

## Key Results

Conceptual/methodological contribution; quantitative anchors reported:

| Analysis | Reported numbers |
|---|---|
| Japanese credit class priors | 44.5% positive (Japanese) vs 70% positive (German credit UCI datasets); Splice dataset true DNA ratio ≈ 1:20 vs 1:1 in data |
| 1R stump vs C4.5 tree (Japanese credit) | Cost lines intersect at p(+) = PC(+) = 0.445; stump better above, tree below |
| Sonar C4.5 with tuned undersampling | Lower envelope never exceeds 25% normalized expected cost |
| Operating range, sonar ensemble | Exact (cost curves): 0.14 < PC(+) < 0.85 (single classifier set), envelope 0.17–0.84; approximate (ROC slopes): 0.05–0.94 |
| Domingos-style sampling reproduction (sonar, C4.5) | Oversampling operating range 0.28–0.75; undersampling 0.25–0.82; both exclude tested cost ratios 5:1 and 10:1 |
| Splitting criteria comparison (sonar) | DKM dominates; DKM vs ENT differ little for 0.3 < PC(+) < 0.6; GINI dominates ACC over most of shared range |
| Example performance gap | Max ~20% normalized-cost difference at PC(+) ≈ 0.3 and 0.7; negligible near 0.5, <0.2, >0.8 |
| Naive Bayes hybrid (sonar) | Performance-independent threshold selection suboptimal nearly everywhere; worse than trivial classifiers outside 0.2 < PC(+) < 0.7 |

Qualitative key claims: cost curves answer all seven routine evaluation questions by eye; ROC's awkward slope judgments become simple x-position lookups; averaging, CIs, and significance have correct, visually interpretable constructions only in cost space; empirical (performance-dependent) selection invalidates standard same-training-set comparisons.

## Conclusions & Implications

Authors' claims: cost curves retain ROC's desirable properties (dominance, hull/envelope duality, cost-model generality) while adding direct readability of expected cost, exact operating ranges, meaningful curve averaging, performance confidence intervals, and per-operating-point significance tests; a free software tool implements everything. They also flag that hybrid selection procedures change experimental methodology (fresh test round needed).

For practitioners building payment/fintech AI systems: this paper supplies the correct instrument for choosing block thresholds under uncertainty about fraud prevalence and asymmetric costs — exactly the block-vs-false-decline trade-off. Reading a model's cost line at the PC(+) matching your business cost ratio tells you expected loss immediately; the crossing point between candidate models says precisely when to switch models as cost assumptions drift; operating-range analysis warns when a heavily rebalanced training recipe produces a model worse than "decline nothing"; and the correlated-bootstrap significance test lets you prove a new risk model genuinely beats the incumbent across deployment conditions rather than on one averaged metric. The performance-independent-selection warning is an MLOps red flag: naively setting the score threshold equal to the assumed fraud rate is demonstrably suboptimal; select empirically cost-minimizing thresholds and re-validate on fresh data.

## Limitations

Acknowledged by authors:
- Two-class visualization only; multi-class requires projection (math extends, bootstrap gets sparse).
- Class-level additive cost model; costs tied to classes not instances (citing Zadrozny et al. 2003); "all distributions" restricted to prior shifts keeping likelihoods fixed (Webb & Ting 2005).
- Tied to one loss function; generalizations (Expected Performance Curves) lose intuitive power.
- No effective way to show several datasets in one plot (unlike scalar measures).
- Individual cost lines become unreadable among many thresholds; workforce-utilization criterion visualizes better in ROC space; not applicable to ranking tasks (excludes PR/lift analysis).
- Hybrid classifiers built by empirical selection need fresh test data for unbiased estimates.

Inferred by me:
- Requires someone to supply a cost ratio (or distribution prob(x)) to be actionable; with unknown business costs only relative statements are possible — no absolute rupee/dollar losses can be read off (authors state this explicitly as a property of normalization).
- Illustrations use small UCI datasets (30-instance worked examples, sonar, credit); no large-scale payment/fraud case study, so computational practicality of the O(n²) CI algorithm and multinomial bootstrap at millions of transactions is untested here.
- Assumes stationary within-class likelihoods; combining with concept-drift monitoring (changing p(X|y)) is outside scope and would need extension.
- Tool availability URL from 2006 (AICML demo page) may be stale today; Weka's built-in cost-curve support is noted as more limited than the authors' tool.

## Relevance to Our Hackathon

Razorpay-track relevance:
- **Cost-sensitive thresholds (block vs false-decline)**: core payoff. Express the block decision through PC(+) built from our measured costs (expected loss per missed fraud/RTO shipment vs goodwill/churn cost of a false decline); the cost-line reading replaces gut-feel thresholds with explicit expected-loss minimization, and sensitivity to cost mis-estimation is visible as horizontal movement along the x-axis rather than re-running experiments.
- **Model selection under uncertain prevalence**: fraud rate varies by merchant category, season, and rail. Cost curves show exactly the PC(+) range where our challenger model beats the champion, enabling per-segment model routing instead of one global winner — including detecting segments where we'd do better declining nothing (trivial classifier).
- **Statistically honest comparisons for judges**: the 3-D-matrix correlated-bootstrap significance plot demonstrates whether our new RTO/fraud model's improvement is significant at the *operating points we'll actually deploy*, avoiding the classic overlap-of-CIs fallacy the paper dismantles.
- **Evaluation of resampling strategies**: their sonar reproduction shows oversampling/undersampling-trained models have narrow operating ranges — directly applicable caution for our SMOTE/undersampled RTO pipelines: validate at the true deployment PC(+), don't just report metrics at balanced 50/50 test conditions.
- **MLOps guardrails**: adopt "cost-minimizing selection + fresh validation data" as policy for any auto-tuned threshold service; the paper proves performance-independent threshold-setting (threshold := assumed positive rate) can underperform even trivial policies.
- **Explainability/compliance**: cost-line charts are inherently explainable artifacts for merchant/risk committees — one picture answering "when would we switch models and why."
