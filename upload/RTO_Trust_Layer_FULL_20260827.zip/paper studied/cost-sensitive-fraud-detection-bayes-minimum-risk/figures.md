# Figures & Tables Log — cost-sensitive-fraud-detection-bayes-minimum-risk

Source key: `dd56f08dfb1c` (primary). Secondary `bc2b8ef00a97` contains byte-similar versions of the same paper's charts (same captions); primary version's images used per spec.

## Tables (from text + page images)

| ID | Page | Type | Content / construction | Takeaway numbers |
|---|---|---|---|---|
| Table I | p.1 | data table (typeset) | Confusion-matrix schematic TP/FP/FN/TN | Defines positive = fraud |
| Table II | p.1 | data table | Hand et al. fixed-FN cost matrix: FP=Ca, FN=100·Ca | Baseline cost model later shown to fail |
| Table III | p.1 | data table | Proposed real-cost matrix: FP/TP=Ca, FN=Amtᵢ | Core contribution |
| Table IV | p.3 | data table | 15 selected database attributes (date, account/card no., tx type Internet/Card-present/ATM, amount EUR, merchant ID/group, country×2, card type, gender, age, bank, fraud label) | Dataset schema |
| Table V | p.3 | data table | Total 750,000 tx / 3,500 frauds / 0.467% / €866,410; Train 625k/2,900/0.464%/€721,349; Test 125k/600/0.480%/€148,562; S1–S50 keep 2,900 frauds at 290k/58k/29k/17.5k/5.8k tx | All dataset split numbers |
| Table VI | p.6 | data table | Cost results varying Ca ∈ {1.00, 2.50, 5.00} for 15 algorithm variants | RF-MR A best at every Ca: 20,929 / 36,634 / 52,003 € |

## Figures

| ID | Page | Type | Construction inference | Axes/legend/series | Readable takeaways | Quality notes | Supports |
|---|---|---|---|---|---|---|---|
| Figure 1(a) | p.4 | line chart | Rasterized Excel-style plot (grey plot area, diamond/square/triangle markers) | X: Train,S1,S5,S10,S20,S50; Y: F1-Score 0–0.30; legend RF(blue)/LR(red)/C4.5(green) | RF peaks ≈0.245 at S5; RF@Train ≈0.04; C4.5 flat ≈0.05–0.16; LR lowest at Train ≈0 | Moderate res; no gridlines beyond ticks; values read approximately | F1-best is S5, not S50 — metric-selection divergence |
| Figure 1(b) | p.4 | grouped bar chart | Same Excel-style rasterized rendering | X: Train…S50; Y: Cost in €, 0–160,000; legend RF/LR/C4.5 | RF@S50 ≈€48k lowest; Train bars ≈€129–147k ≈ no-model baseline region | Consistent fonts; y-labels use European decimal comma ("160,000 €") | Higher fraud % in training ⇒ lower cost (up to 76% savings) |
| Figure 2(a) | p.5 | dual-axis combo (bars + lines) | Rasterized Excel-style; purple bars right axis, colored lines left axis | X: C4.5,C4.5-T,LR,LR-T,RF,RF-T; right Y: Cost 0–100,000 €; left Y: 0–1.00; legend Cost/Precision/Recall/F1-Score | RF-T bar ≈€45.5k with recall ≈0.80; LR-T bar worst ≈€88k | Precision/F1 lines compressed near axis (fraud rate ~0.48%) making them hard to read | Threshold optimization helps only RF (−€2,165) |
| Figure 2(b) | p.5 | dual-axis combo | Same style | X: C4.5,C4.5-MR H,LR,LR-MR H,RF-T,RF-MR H | LR-MR H ≈€96k worst; RF-MR H ≈€68k worse than RF-T | Same readability limits | Fixed 100·Ca BMR matrix never improves results |
| Figure 2(c) | p.5 | dual-axis combo | Same style | X: C4.5,C4.5-MR,LR,LR-MR,RF-T,RF-MR | LR-MR ≈€45.5k strong; RF-MR ≈€59k degraded vs RF-T | — | Real-cost matrix fixes LR but breaks unadjusted RF (overestimated probabilities) |
| Figure 2(d) | p.5 | dual-axis combo | Same style | X: C4.5,C4.5-MR A,LR-MR,LR-MR A,RF-T,RF-MR A | RF-MR A lowest bar ≈€36.6k; recall falls to ≈0.55–0.57 vs RF-T ≈0.80 | — | Headline result: adjusted-probability BMR on RF = best cost (23% saving) |

## Extraction notes
- No vector figure sources available; all six charts are embedded raster images (~711×358 px) of Excel-style plots — honest quality assessment: adequate for qualitative comparison, not for precise value recovery; exact values come from Table VI.
- Numeric table Table VI extracted to `tables.csv`.
