# Research Requests

- [High] Train RF/LR/C4.5 on a synthetic COD e-commerce dataset with order-value labels; evaluate with the paper's cost measure (FN=order value, FP=₹review cost) and show how often the F1-best model differs from the money-best model.
- [High] Implement the Bayes minimum risk layer (Eq. 5) on top of an XGBoost RTO-probability model and A/B-simulate blocked vs shipped shipments to quantify savings vs a global 0.5 threshold.
- [High] Verify empirically that Eqs. (6)–(7) prior-ratio calibration after SMOTE/under-sampling reduces cost on Razorpay-style transaction data; compare against isotonic and Platt recalibration.
- [Med] Reproduce the S1–S50 under-sampling sweep on the Kaggle ULB creditcard dataset and plot the F1-vs-cost crossover point found in Fig. 1 of the paper.
- [Med] Replace the fixed administrative cost Ca with a per-channel cost (SMS+call+manual review) and test whether RF-MR A's dominance across Ca ∈ {1, 2.5, 5} still holds.
- [Med] Extend the real-cost matrix to time dimension: add delayed-detection cost (fraud continuing n days) and compare with the single-shot Amtᵢ cost.
- [Low] Test whether recall dropping ~25% while cost improves 23% (RF-MR A vs RF-T) creates customer-complaint externalities; estimate complaint cost at which F1 selection becomes optimal again.
- [Low] Wrap the cost measure as an sklearn scorer and use it inside GridSearchCV hyperparameter tuning; check for training-set overfitting analogous to the paper's LR-T result.
