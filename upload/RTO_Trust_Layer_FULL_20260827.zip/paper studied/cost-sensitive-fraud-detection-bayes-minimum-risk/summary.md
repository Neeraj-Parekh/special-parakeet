# Cost Sensitive Credit Card Fraud Detection using Bayes Minimum Risk

| Field | Value |
|---|---|
| **Authors** | Alejandro Correa Bahnsen, Aleksandar Stojanovic, Djamila Aouada, Björn Ottersten (Interdisciplinary Centre for Security, Reliability and Trust — SnT, University of Luxembourg) |
| **Venue / Year** | 2013 12th International Conference on Machine Learning and Applications (ICMLA 2013), pp. 333–338 |
| **Type** | conference paper |
| **DOI / URL** | DOI 10.1109/ICMLA.2013.68 (from IEEE copyright footer of `bahnsen2013.pdf`) |
| **Processed** | 2026-08-26T06:51:01Z |
| **Source PDFs** | CostSensitiveCreditCardFraudDetectionUsingBayesMinimumRisk_2013.pdf (`60c6a718`), bahnsen2013.pdf (`4cbc0e63`) |

> Version 1 — generated from extracted PDF text. Two versions of the same paper were read in full; the ICMLA-published version (`bahnsen2013.pdf`) supplies the venue/DOI footer, while the primary preprint-style file contains the explicit probability-adjustment equations.

## Abstract

> "Credit card fraud is a growing problem that affects card holders around the world. Fraud detection has been an interesting topic in machine learning. Nevertheless, current state of the art credit card fraud detection algorithms miss to include the real costs of credit card fraud as a measure to evaluate algorithms. In this paper a new comparison measure that realistically represents the monetary gains and losses due to fraud detection is proposed. Moreover, using the proposed cost measure a cost sensitive method based on Bayes minimum risk is presented. This method is compared with state of the art algorithms and shows improvements up to 23% measured by cost. The results of this paper are based on real life transactional data provided by a large European card processing company."

## Plain-Language Restatement

Banks lose real money to card fraud, but researchers usually judge fraud detectors with abstract metrics like F1-score that ignore how much each mistake actually costs. The authors propose measuring performance directly in Euros: an undetected fraud costs exactly the amount stolen, and any alert costs a small administrative fee (~€2.50) to investigate. They then build a decision layer (Bayes minimum risk) that uses these per-transaction costs plus the model's fraud probability to decide whether to flag each transaction, cutting total fraud losses by up to 23% versus standard random forests on real data from a large European card processor.

## Problem Statement

State-of-the-art credit card fraud detectors are evaluated with misclassification rate, precision, recall and F1 — measures that implicitly treat a false positive (wrongly flagged transaction) the same as a false negative (missed fraud). In reality an FN costs the full stolen amount (from a few to thousands of Euros), while an FP costs only an administrative fee. Prior work (Hand et al.) differentiated FP/FN costs but assumed a *constant* FN cost (100×Ca), which is unrealistic. The gap: no evaluation measure or classifier used the actual monetary amounts at stake. This matters because model selection on F1 leads to choosing models that barely save money versus doing nothing.

## Methodology

- **Cost measure (Eq. 1):** C = Σᵢ yᵢ(pᵢCa + (1−pᵢ)Amtᵢ) + (1−yᵢ)pᵢCa over m transactions; FN cost = transaction amount Amtᵢ, FP/TP cost = administrative cost Ca.
- **Cost matrices:** Table I classical confusion matrix; Table II Hand et al. fixed-FN matrix (FN = 100·Ca); Table III proposed real-financial-costs matrix (FN = Amtᵢ).
- **Bayes minimum risk (BMR):** classify as fraud if R(pf|x) ≤ R(pl|x) where R(pf|x) = L(pf|yf)P(pf|x) + L(pf|yl)P(pl|x). With fixed matrix → Eq. (4): CaP(pf|x)+CaP(pl|x) ≤ 100·CaP(pf|x). With real costs → Eq. (5): CaP(pf|x)+CaP(pl|x) ≤ Amtᵢ·P(pf|x).
- **Probability adjustment after under-sampling (Eqs. 6–7, primary source):** P*(pf|x) = P(pf|x)·Porig/Pund; P*(pl|x) = 1 − P*(pf|x) — corrects the inflated fraud prior caused by under-sampling.
- **Dataset:** real transactions from a large European card processing company, year 2012. Full DB: 80,000,000 transactions × 27 attributes; ~20,000 labelled frauds (0.025%). Selected attributes (Table IV): date/hour, account number, card number, transaction type (Internet / Card present / ATM), amount (EUR), merchant ID, merchant group, country, country of residence, card type, gender, age, issuer bank, fraud label. +260 derived attributes via transaction aggregation over recent hours (e.g., number of internet transactions in last 6h by same person in same country).
- **Experimental subset:** 750,000 transactions, 3,500 frauds (0.467%), €866,410 fraud loss. Train = Jan–Oct 2012 (625k tx, 2,900 frauds, €721,349), Test = Nov–Dec 2012 (125k tx, 600 frauds, €148,562).
- **Under-sampling variants (train only):** S1/S5/S10/S20/S50 with 1/5/10/20/50% frauds (290k/58k/29k/17.5k/5.8k tx, all keeping 2,900 frauds).
- **Algorithms (scikit-learn):** logistic regression (ℓ2 regularization), C4.5 decision tree (default parameters), random forest (max estimators per split = 10, Gini criterion). Plus thresholding optimization (Sheng & Ling) minimizing training cost, BMR with fixed matrix (-MR H), BMR with real-cost matrix (-MR), and BMR with adjusted probabilities (-MR A).
- **Evaluation:** F1, precision, recall + cost measure with Ca = €2.50; sensitivity analysis varying Ca ∈ {1.00, 2.50, 5.00}.

## Key Results

Baseline: doing nothing costs the full test-set fraud amount, €148,562.

**Traditional algorithms across under-sampling levels (Fig. 1, Ca=€2.50, approximate values read from charts):**

| Training DB | Best F1 (RF) | Approx. RF cost |
|---|---|---|
| Train (no under-sampling) | ≈0.04 | ≈€144k |
| S5 | ≈0.245 (max) | ≈€89k |
| S20 | ≈0.175 | ≈€54k |
| S50 | ≈0.095 | ≈€48k |

F1-optimal selection (S5) yields almost no savings vs no model; S50 training saves up to 76% despite low F1.

**Final comparison (Table VI — exact costs in Euros):**

| Algorithm | Ca=1.00 | Ca=2.50 | Ca=5.00 |
|---|---|---|---|
| C4.5 | 35,466 | 57,726 | 86,215 |
| LR | 46,530 | 59,157 | 80,202 |
| RF | 33,641 | 47,669 | 61,969 |
| C4.5-T | 35,531 | 57,888 | 86,215 |
| LR-T | 56,704 | 87,127 | 94,977 |
| RF-T | 26,598 | 45,504 | 66,374 |
| C4.5-MR H | 35,531 | 57,888 | 79,879 |
| LR-MR H | 56,357 | 95,190 | 104,027 |
| RF-MR H | 37,964 | 67,977 | 90,092 |
| C4.5-MR | 35,120 | 56,176 | 83,117 |
| LR-MR | 28,320 | 45,472 | 62,570 |
| RF-MR | 32,380 | 58,165 | 71,694 |
| C4.5-MR A | 31,631 | 56,551 | 70,127 |
| LR-MR A | 27,212 | 48,915 | 69,185 |
| **RF-MR A** | **20,929** | **36,634** | **52,003** |

- Threshold optimization: only RF improves (cost −€2,165 to €45,504, same F1); LR-T degrades badly (€87,127) → authors conclude it overfits the training data.
- BMR with fixed 100·Ca matrix is worse everywhere (LR-MR H €95,190) → constant FN cost assumption is unrealistic.
- BMR with real costs: LR-MR saves €13,685 vs plain LR; but RF-MR degrades (€58,165) because under-sampled models overestimate fraud probabilities.
- **Best overall: RF-MR A (adjusted probabilities) = €36,634 at Ca=€2.50 ⇒ 23% savings vs RF**, verified for all Ca ∈ [1.00, 5.00]. Its recall drops ~25% vs RF-T, but it detects high-amount frauds ("the most relevant" ones).

## Conclusions & Implications

The authors conclude that: (1) algorithm selection must use real financial costs, not traditional statistics — the two disagree; (2) a fixed FP/FN cost difference is insufficient; the actual per-transaction amount must be the FN cost; (3) a Bayes minimum risk classifier built on the real-cost matrix gives substantially higher savings than state-of-the-art baselines, especially when estimated probabilities are re-calibrated after under-sampling.

For practitioners building payment/fintech AI systems: attach a Euro-denominated cost matrix to any probabilistic fraud/RTO model and make decisions via expected-risk comparison rather than a fixed 0.5 threshold; always recalibrate probabilities if you resample during training; expect the cost-optimal model to look worse on F1/recall while saving more money.

## Limitations

*(Acknowledged by authors)* Thresholding optimization overfits training data; fixed-FN cost matrices perform poorly; BMR without probability adjustment is inconsistent when probabilities come from under-sampled training.
*(Inferred by me)* Single dataset from one processor/year; results shown mainly via bar-chart figures whose exact per-algorithm precision/F1 values are hard to read; no confidence intervals or statistical significance tests reported; Ca treated as known and constant; derived-attribute engineering (260 attrs) not fully specified; no online/streaming or concept-drift evaluation despite fraud patterns shifting.

## Relevance to Our Hackathon

- **Direct template for RTO/fraud loss economics:** replace F1 with the paper's cost measure — FN cost = shipment value / transaction amount, FP cost = investigation cost. Exactly applicable to Razorpay-track RTO risk prediction on COD e-commerce shipments where the loss is the order value.
- **Bayes minimum risk as a drop-in decision layer:** any calibrated classifier (XGBoost/LightGBM score) can be wrapped with Eq. (5)'s expected-cost comparison; thresholds become per-order (amount-dependent) instead of global.
- **Probability recalibration after resampling:** Eqs. (6)–(7) are essential whenever SMOTE/under-sampling is used on imbalanced fraud data — otherwise cost-sensitive decisions misfire.
- **Metric-selection trap:** the paper empirically demonstrates that the F1-best model ≠ money-best model; hackathon demos can quantify this on our own data.
- **Ensemble baseline:** RF with Gini, 10 estimators, on aggregation-derived behavioral features is a strong reproducible baseline for fraud detection on imbalanced data.

## Figures & Tables

- **Table I (p.1)** — confusion-matrix schematic (data table): TP/FP/FN/TN definitions. Supports metric definitions in Methodology.
- **Table II (p.1)** — cost matrix, fixed FN = 100·Ca (Hand et al.). Supports the "constant FN unrealistic" claim contradicted in Results.
- **Table III (p.1)** — proposed real-cost matrix, FN = Amtᵢ. Core methodological contribution.
- **Table IV (p.3)** — database attributes list (15 selected attributes). Supports dataset description.
- **Table V (p.3)** — train/test/under-sampled database sizes (750k/625k/125k; S1–S50; fraud ratios 0.467%/0.480%; fraud amounts €866,410/€721,349/€148,562). Supports all dataset numbers.
- **Figure 1a+1b (p.4)** — line chart (F1-Score vs Train,S1–S50) + grouped bar chart (Cost in €): RF peaks ≈0.245 F1 at S5 but cost-minimum at S50 (≈€48k); Excel-style rasterized charts, grey plot area, readable axes. Supports "F1 selection ≠ cost selection".
- **Figure 2a (p.5)** — dual-axis combo chart (purple cost bars right axis 0–100,000 €; precision/recall/F1 lines left axis 0–1.00) for C4.5…RF-T: only RF improves (≈€45.5k, recall ≈0.80); LR-T worst ≈€88k. Matches Table VI.
- **Figure 2b (p.5)** — same format, fixed-FN BMR (-MR H): LR-MR H worst ≈€96k; supports "fixed-cost BMR fails".
- **Figure 2c (p.5)** — real-cost BMR (-MR): LR-MR ≈€45.5k strong, RF-MR ≈€59k degraded; matches text.
- **Figure 2d (p.5)** — adjusted-probability BMR (-MR A): RF-MR A lowest bar ≈€36.6k with recall ≈0.55–0.57 vs RF-T ≈0.80; supports the headline 23%-savings result.
- **Table VI (p.6)** — exact cost sensitivity table (reproduced above in Key Results; also extracted to tables.csv).

*Quality note:* all six charts are rasterized Excel-style plots embedded in the IEEE two-column layout; moderate resolution, consistent fonts, no watermarks; exact numeric labels absent so values are read against gridlines (approximate).
