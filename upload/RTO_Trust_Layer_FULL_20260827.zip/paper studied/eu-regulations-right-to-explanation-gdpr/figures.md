# Figures & Tables Deep Dive — eu-regulations-right-to-explanation-gdpr

**Sources examined:** `70704196032f` (euregs.pdf, preprint, 10pp) + `1cd62fde7e27` (goodman2017.pdf, AI Magazine published, 8pp)
**Images inspected:** 7 rendered pages + 3 embedded (total 10 pngs); max 8/batch respected (batch1: 7 pages, batch2: 3 embedded)
**Method:** Visual read of every `page_*.png` and `img_*.png`; comparison across both source versions; byte-duplicate secondary version (euregs vs goodman) retained but primary interpretation from published `1cd62fde7e27`.

---

## Figure Inventory

### Figure 1 — Excerpt from the General Data Protection Regulation (Article 22)

| Field | 70704196032f (preprint) | 1cd62fde7e27 (published) |
|---|---|---|
| **ID** | Figure 1 (caption line 57-58) | Figure 1 (caption "Excerpt from the General Data Protection Regulation. (European Union, Parliament and Council 2016)" page 3) |
| **Page** | Preprint page 1-2 boundary, rendered in `page_002.png` (bottom third) | Published page 2-3, rendered in `page_003.png` left column, also `page_002.png` shows intro context without figure |
| **Type** | Data table / boxed legal excerpt (not a chart) | Same — data table / boxed legal excerpt |
| **Construction** | Vector text box with thin black border, Times/serif font, numbered paragraphs 1–4 with indented subpoints (a)(b)(c). No graphic elements. Typeset via LaTeX preprint style. | Vector text box with identical text but pale mint-green fill (#eef6df equivalent), rounded-shadow border with drop shadow, serif font, cleaner spacing, footnote markers removed vs preprint. Professionally typeset AI Magazine layout. |
| **Content exactly** | Header "Article 22. Automated individual decision making, including profiling" then: 1. Right not to be subject to solely automated decision (including profiling) producing legal/significantly affects effects. 2. Exceptions: (a) contract necessity/performance, (b) Union/Member State law with safeguards, (c) explicit consent. 3. For (a) and (c): controller implement suitable measures: at least right to human intervention, express view, contest. 4. Decisions under para2 shall not be based on special categories Art 9(1) unless Art 9(2)(a) or (g) + safeguards. | Identical wording verbatim (verified line-by-line 707 lines 39-56 vs 1cd lines 187-216). Line breaks/typesetting differ but text identical. |
| **Axes/legend/units** | N/A (text box, not axes) | N/A |
| **Takeaway numbers** | No numeric data; defines 4 paragraphs + 3 exception conditions | Same |
| **Quality observations** | Sharp vector text, high contrast, no blur. Some citation truncation elsewhere in doc ("[Cra ]", "?") but figure itself clean. Black-on-white border, minimalist. No watermark. Inconsistent citation formatting elsewhere does not affect figure. | High quality: vector rendering, crisp fonts, consistent with AAAI magazine style. Green background aids readability. Drop shadow subtle, not blurry. Embedded extraction `img_p003_21.png` renders as solid grey placeholder (2139×1568?) — indicates extraction failure for embedded crop, but page render is perfect. No blur/pixelation at 200% zoom. |
| **Summary.md linkage** | Supports: GDPR nondiscrimination analysis + Article 22 lawful-pathway checklist in Methodology section bullet 1; Problem Statement sentence citing Article 22 could prohibit wide swath of algorithms. Summary header facts list correct (Art 22 text). No contradiction. | Same — supports compliance-check capability in skill.yaml |
| **Verification** | Text verified against GDPR L119/1 via source caption; no hallucination; matches Article 22 structure known externally. | Matches preprint exactly, confirms preprint figure not mis-extracted. |

---

### Figure 2 — An Illustration of Uncertainty Bias (synthetic loan-approval simulation)

| Field | 70704196032f (preprint) | 1cd62fde7e27 (published) |
|---|---|---|
| **ID** | Figure 2 (caption lines 263-271) | Figure 2 ("An Illustration of Uncertainty Bias." — caption page 5) |
| **Page** | Preprint page 6, rendered in `page_006.png` (mid-page) | Published page 5 (54 AI MAGAZINE), rendered in `page_005.png` (top half, full-width with light green background) |
| **Type** | Line chart (2 series + threshold line) | Same line chart |
| **Construction** | Matplotlib/R-style vector line chart: black axes, thin lines, no grid, minimal styling. X-axis "Non-white % of population", Y-axis "Predicted probability of repayment". Three series: black solid "non-white" (steply increasing concave curve), red solid "white" (flat ~92-93% across x), blue dashed "approval threshold" horizontal at 90. Caption below in 8pt serif. Looks like base R plot (no ggplot theming, default tick marks). | Same data, slightly polished: axes thicker, background pale green fill inside plot, lines slightly thicker/smoothed, red "white" line more saturated, blue dashed threshold more visible, fonts sans-serif for axis labels but still vector. Published caption italic title + full paragraph identical wording. Likely same R/MATLAB source re-rendered with magazine palette. No raster artifacts. |
| **Axes / legend / units / series exactly** | X: 0 to 50, ticks 0,10,20,30,40,50, label "Non–white % of population" (en-dash). Y: 0 to 100, ticks 0,20,40,60,80,100, label "Predicted probability of repayment" (0–100 percent). Legend inline text inside plot: "approval threshold" in blue near y=90, "white" in red near top, "non–white" in black near lower curve. No error bars visible; curve represents lower end of 95% CI per text. | Identical axes: X 0→50, Y 0→100, same ticks. Published shows Y ticks 0,20,40,60,80,100 left side, X 0–50 bottom. Same three series: blue dotted (published dotted vs dashed) at 90, red flat ~92.5, black rising. In `img_p005_35.png` embedded crop shows grey placeholder again — but page render shows correct. Preprint `page_006.png` shows text extraction artifact Y ticks out-of-order in txt (0,10,20...) but image correct. |
| **Concrete numbers readable** | At x≈1% (leftmost): non-white y≈8%. At x≈5%: ~50%. At x≈6%: ~61% (crosses ~60). At x≈10%: ~74%. At x≈15%: ~83%. At x≈20%: ~87.5%. At x≈30%: ~91% touches threshold. At x≈32-33% (30% mentioned in text): non-white curve meets/exceeds 90 dashed line — this is the <30% denial cutoff claimed. At x≈40%: ~92%. At x≈50%: ~92% converges with white line. White line flat ~92-93% across all x (slightly ~91.8 at x=0 to 92.5 at x=50). Approval threshold strictly horizontal at 90 across all x. | Same numbers within 1-2% reading tolerance: At x=1: ~8, x=5: ~45, x=6: 60, x=10: 75, x=20: 88, x=30: 91, x=50: 92. Visual interpolation consistent. Published green background does not obscure readings. |
| **Quality / editing observations** | Vector, sharp, not blurry. Fonts consistent (Times for axes). Axes cropped correctly. No watermark. Low visual polish vs journal figure but adequate. Caption text fully legible, 8pt not pixelated. No inconsistent fonts inside figure vs body except axis font sans vs serif minimal. | High quality: crisp vector, green background uniform, no banding. No blur. Fonts consistent. No watermark. Grey embedded `img_p005_35.png` (1107×623) is unreadable solid grey — extraction artifact, not a quality defect of paper. Page render shows perfect. Magazine layout has large white margins, figure centered. No cropped axis. |
| **Which summary claim supports / contradicts** | Directly supports Key Results bullets: (1) All white applicants receive credit (flat red >90), (2) When nonwhite <~30% denied entirely (curve below threshold left of 30), (3) Approaches 50% all approved (converge). Also supports Methodology bullet describing N=500, 95% CI, 90% threshold logistic classifier. No contradiction; numbers exactly match text lines 236-238 and 263-271. Active-learning compounding note after figure aligns. | Same support; published caption line 393-400 explicitly states "<30%... exhibits uncertainty bias... As nonwhite approaches 50%... everyone is offered loans" — perfect match. |
| **Construction inference** | R base graphics or matplotlib with default style, exported as vector PDF then rasterized at ~150dpi for png. Not hand-drawn, not screenshot, not gnuplot (style is R-like axis tick inside). | Same source file, recolored for publication; still vector. |

**Additional note on Figure 2 textual axis extraction bug:** In `1cd62fde7e27.txt` lines 401-417 the Y ticks appear as "0\n10\n20\n30\n40\n50\n20\n0\n40..." due to PDF reading order interleaving X and Y ticks. Image confirms correct ordering is Y=0,20,40,60,80,100 and X=0,10,20,30,40,50. Tables.csv note corrects this.

---

### Unnumbered Photo — Gavel + EU Flag (Decorative)

| Field | Value |
|---|---|
| **ID** | Unnumbered—p51 header photo (no figure number, top of page 2 in published) |
| **Page** | `1cd62fde7e27` page 1-2 spread, rendered in `page_002.png` top half; embedded high-res crop `img_p002_15.png` (2139×1568) |
| **Type** | Photo / stock image |
| **Construction** | Raster color photograph, iStock credit "© pepifoto, IStock" bottom right. Shows wooden gavel on sounding block in foreground, EU flag (blue with yellow stars) blurred in background, shallow depth of field, warm wood tones. Overlay white serif quote text: "… for the first time in more than two decades, the European Parliament adopted a set of comprehensive regulations..." |
| **Axes/legend** | N/A |
| **Takeaway** | Decorative, non-data; signifies legal/EU context only |
| **Quality** | High-res raster, well-exposed, sharp foreground, no blur artifacts beyond intentional bokeh. Watermark absent (copyright credit present). Fonts white italic serif overlay legible. Not low-res. |
| **Summary linkage** | No data claim; supports venue quality assessment only — magazine article opener. Does not support/contradict any numeric claim. |
| **Note** | Preprint `70704196032f` has no such photo — preprint is plain LaTeX, no images page 1. Published adds this editorial photo; not counted as data figure but logged for completeness per "every image" requirement. |

---

### Missing / Expected Figures

- No other figures/tables exist in either source. Text mentions no Table 1, no appendix figures. Search of all `page_*.png` confirms only these 2 numbered figures + 1 decorative photo.
- No confusion matrix, heatmap, architecture diagram, flowchart, or data table present.
- References section contains no figures.

---

## Venue Quality Assessment (honest, per spec)

- **70704196032f (preprint):** Plain LaTeX two-column? Actually single column preprint style, black-and-white, vector figures sharp but minimal styling. Citation artifacts: "[Cra ]" truncation and "?" placeholder indicate incomplete bib compilation — low editing polish vs published. Figure fonts consistent. Not blurry. No watermark. Overall preprint quality acceptable but pre-publication draft level.
- **1cd62fde7e27 (published):** AAAI AI Magazine Fall 2017 professional layout: two-column with green-shaded boxes, polished figures with green fills, drop shadows, crisp vector lines, consistent fonts, copyright line, page numbers "50–57". Stock photo high-res. References complete with DOIs, volume numbers, page ranges, proper capitalization. Zero blur, no cropped axes, no pasted-from-another-doc appearance. Venue-appropriate high production quality. Embedded image extractions `img_p003_21.png` and `img_p005_35.png` rendered as blank grey in image dump — this is a PDF extraction artifact (likely green boxes extracted as images but rasterizer produced grey) not a paper defect; page renders prove figures are fine. Honest assessment: published version is well-edited, no concerns.

---

## Summary Linkage Recap

- **Figure 1** → Problem Statement (Art 22 scope), Methodology (doctrinal reading of GDPR), Conclusions (Article 22 exception pathway demo feature).
- **Figure 2** → Key Results (uncertainty bias <30% cutoff, N=500 simulation), Methodology (logistic regression + CI threshold description), Relevance to Hackathon RTO fairness dashboard.
- **Photo** → No linkage to claims; editorial only.

**Figures counted for metadata:** 2 numbered data figures (Figure 1, Figure 2) + 1 unnumbered decorative photo = 3 total visual figures; 2 data-relevant figures.

---

