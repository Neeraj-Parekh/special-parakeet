# European Union Regulations on Algorithmic Decision Making and a "Right to Explanation"

| Field | Value |
|---|---|
| **Authors** | Bryce Goodman (Oxford Internet Institute); Seth Flaxman (Department of Statistics, University of Oxford) |
| **Venue / Year** | AI Magazine (AAAI), Fall 2017, Vol. 38, No. 3 (pp. 50–57) — published version; earlier arXiv-style preprint also in corpus |
| **Type** | journal article |
| **DOI / URL** | (not stated in text; copyright line: © 2017, Association for the Advancement of Artificial Intelligence. ISSN 0738-4602) |
| **Processed** | 2026-08-26T05:29:27Z |
| **Source PDFs** | goodman2017.pdf (primary, AI Magazine version) — sha256 ac33e234; euregs.pdf (preprint version) — sha256 c5a15241 |

> Version 2 — v2 full-read verification pass (2026-08-26). Verified true.

## Abstract

> "We summarize the potential impact that the European Union's new General Data Protection Regulation will have on the routine use of machine-learning algorithms. Slated to take effect as law across the European Union in 2018, it will place restrictions on automated individual decision making (that is, algorithms that make decisions based on user-level predictors) that 'significantly affect' users. When put into practice, the law may also effectively create a right to explanation, whereby a user can ask for an explanation of an algorithmic decision that significantly affects them. We argue that while this law may pose large challenges for industry, it highlights opportunities for computer scientists to take the lead in designing algorithms and evaluation frameworks that avoid discrimination and enable explanation."

## Plain-Language Restatement

The GDPR — EU privacy law effective 2018 — restricts fully automated decisions that significantly affect people (like loan approvals or insurance pricing), and pushes toward a right to ask why an algorithm decided what it did. The authors explain what this means for machine learning: you cannot just delete "sensitive" variables because other features correlate with them, and even fair-looking models can systematically disfavor underrepresented groups purely due to statistical uncertainty ("uncertainty bias"). They demonstrate this with a loan-approval simulation and argue the field should treat explanation and fairness as algorithm-design requirements.

## Problem Statement

Gap addressed: machine-learning practice (correlation-driven prediction, black-box models) is structurally misaligned with GDPR obligations — Article 22's restrictions on solely automated decisions with legal/significant effects, Recital 71's mandate to prevent discriminatory effects, and Articles 13/14's requirement of "meaningful information about the logic involved." It matters because Article 22 could "potentially prohibit[] a wide swath of algorithms currently in use in recommendation systems, credit and insurance risk assessments, computational advertising, and social networks," and non-compliance now carries EU-wide fines of €20 million or 4% of global revenue (Article 83(5)), with explicitly global scope (Article 3(1)).

## Methodology

Legal analysis + illustrative simulation:
- **Doctrinal reading of the GDPR**: distinction between Directive (1995 DPD, national implementation) and Regulation (directly applicable law); fines regime (Art. 83(5)); global jurisdiction (Art. 3(1)); enforcement rights (Arts. 77–80: complaint to supervisory authority, judicial remedies, compensation/liability Art. 82, representation by bodies); definitions (personal data, processing, profiling as automated processing for evaluation).
- **Nondiscrimination analysis**: minimal vs maximal interpretations of "sensitive data" constraints (Article 9 categories; Recital 71). Minimal = only explicit sensitive variables (ineffective due to proxies — postal code/geometry examples; Calders & Verwer quote). Maximal = all correlated variables (infeasible at scale — Deloitte actuaries example predicting health status from buying history; IP address/race correlations).
- **Uncertainty-bias simulation** (the paper's only experiment): repeatedly generated synthetic datasets of size N=500 varying the true proportion of nonwhites in the population; true repayment probability fixed at 95% independent of race; logistic regression classifier; risk-averse decision rule = extend credit only if lower end of the 95% confidence interval exceeds a fixed 90% approval threshold.
- **Explanation analysis**: application of Burrell's (2016) three transparency barriers (intentional concealment; technical literacy gaps; mismatch between high-dimensional optimization and human-scale reasoning) mapped onto GDPR Articles 12 and 13; model-class interpretability spectrum (linear → SVMs/Gaussian processes → random forests → deep neural nets); pointer to quantitative input influence methods (Datta, Sen & Zick 2016).

## Key Results

Simulation result (uncertainty bias): with ground truth equal across groups (95% repayment regardless of race),
- All white applicants receive credit (large-sample CI tight around 95% > 90% threshold).
- When nonwhite share of the population is below ~30%, nonwhite applicants are denied credit entirely — purely from sampling uncertainty, since their confidence intervals straddle the threshold.
- As the nonwhite share approaches 50%, uncertainty converges and everyone is approved.
- The authors warn active learning compounds this: initial bias toward well-represented groups grows over time as more examples are collected for them.

Qualitative results:
- GDPR nondiscrimination dilemma: minimal interpretation is ineffective; maximal interpretation is infeasible → motivates human-intelligible explanations.
- Distinction drawn between rights of access/notification (Arts. 13–15) and the additional Article 22 safeguards including "meaningful information about the logic involved."
- Interpretability trade-off table (conceptual): linear models easy to interpret but limited capacity; ensembles hard (aggregation); neural nets hardest.
- Silver lining argument: unlike human decision-making (documented extraneous-factor biases), algorithmic discrimination can be identified and corrected with technical interventions (citing discrimination-aware data mining literature).

## Figures & Tables

- **Figure 1 — Excerpt from GDPR Article 22 (data table / boxed legal text, preprint p2 `page_002.png` mint-green box p3 `page_003.png` in published):** Verbatim 4-paragraph legal text (right not to be subject to solely automated decisions; exceptions contract/law/consent; safeguards human intervention/express view/contest; special-category restriction); no numeric data; crisp vector, drop-shadow in published.
- **Figure 2 — An Illustration of Uncertainty Bias (line chart, preprint p6 `page_006.png`, published p5 `page_005.png` green background):** X Non-white % 0–50, Y Predicted probability 0–100; white flat ~92–93%, approval threshold dashed at 90, non-white rising from ~8% at 1% to 60% at 6%, 75% at 10%, 88% at 20%, crosses 90 at ~30% → denial cutoff; at 50% converges (~92% all approved). Demonstrates <30% denied 100%, parity at 50%.
- **Unnumbered photo — Gavel + EU flag (published p2 `page_002.png` top, `img_p002_15.png`):** High-res iStock stock photo (© pepifoto), gavel on sounding block with blurred EU flag, decorative non-data editorial image.

## Conclusions & Implications

Authors' claims: GDPR is "a vital acknowledgement that... few if any decisions are purely 'technical'"; challenges are "good problems to have," pushing the field toward transparent, fair, inspectable models (ex ante and ex post); properly applied algorithms can be more accurate AND more transparent/fair than human decision-makers.

For practitioners building payment/fintech AI systems:
- Any automated risk decision that "similarly significantly affects" a user (RTO-based order blocking, loan declines, fraud account freezes) needs: a lawful Article 22 pathway (contract necessity / explicit consent / law authorization), plus safeguards — human intervention on request, ability to express a view, contest the decision.
- Feature engineering alone cannot discharge anti-discrimination duties; proxy correlation audits and uncertainty-aware thresholds are needed — especially for imbalanced segments (exactly the small-cohort problem our RTO/COD data will have).
- Build an explanation pipeline (feature-attribution reports per adverse decision) before launch, not after regulators ask; log enough context at decision time to reconstruct "meaningful information about the logic."

## Limitations

Acknowledged by authors:
- "This is by no means a comprehensive overview of the legal landscape"; conditions for ethically permissible access to sensitive data (Article 9) are out of scope; human-intervention requirements need further investigation.
- Uncertainty-bias illustration uses a deliberately simple synthetic setup; real classifiers consider complicated feature combinations where rare combinations have very few observations.
- It is unclear whether companies must disclose learning algorithms/training data, and whether such information would be public (their footnote 8).
- Whether bias-correction techniques get adopted in practice "remains to be seen."

Inferred (by me):
- The simulation is hypothetical with no empirical validation on real lending data; the 30%/90%-threshold numbers are illustration-specific, not general laws.
- Written pre-GDPR-application (2017): subsequent jurisprudence (e.g., debates on whether a literal "right to explanation" exists in GDPR) is not covered.
- No treatment of enforcement outcomes, cost of compliance, or modern XAI tooling (post-2016 SHAP/LIME era).

## Relevance to Our Hackathon

This is the canonical citation for two hackathon pillars:

1. **Explainability duty for automated blocking decisions**: Our RTO-risk model that blocks/re-routes COD shipments is precisely a "solely automated decision... similarly significantly affect[ing]" a merchant/customer. The paper gives us the compliance checklist (Article 22 exception path + human review + contestation + logic disclosure) to demo as a product feature: an "adverse decision explainer" panel showing top features, confidence intervals, and a request-human-review button.

2. **Uncertainty bias on imbalanced fraud/RTO data**: The 500-sample logistic-regression experiment is directly transferable: simulate merchant cohorts where one segment is <30% of training data and show how risk-averse thresholds deny them service despite identical true risk. This motivates calibrated-per-segment thresholds, oversampling, or conformal prediction in our RTO model — and a fairness dashboard comparing approval rates across merchant segments.

3. **Consent UX**: The paper distinguishes access/notification from meaningful profiling safeguards — supporting our DPDP/GDPR-style consent design where users consent to profiling with explicit explanation of logic, not buried T&Cs.

4. **Audit trail**: Burrell's three transparency barriers map to our audit-trail requirements: intentional concealment (we publish decision schemas), technical literacy (plain-language reasons), high-dimensionality (feature attribution summaries).
