# Hybrid Machine Learning-Based Multi-Stage Framework for Detection of Credit Card Anomalies and Fraud

| Field | Value |
|---|---|
| **Authors** | Hatoon S. Alsagri (College of Computer and Information Sciences, Imam Mohammad Ibn Saud Islamic University (IMSIU), Riyadh 11673, Saudi Arabia; hsagri@imamu.edu.sa) |
| **Venue / Year** | IEEE Access, vol. 13, 2025, pp. 77039–77048 |
| **Type** | journal article |
| **DOI / URL** | 10.1109/ACCESS.2025.3565612 |
| **Processed** | 2026-08-26T08:59:14Z |
| **Source PDFs** | Hybrid_Machine_Learning-Based_Multi-Stage_Framework_for_Detection_of_Credit_Card_Anomalies_and_Fraud.pdf (sha256 9a668494…) |

> Version 1 — generated from extracted PDF text.

## Abstract

> "Recently, tremendous growth in e-business has arisen in an increasing number of online transactions. Such widespread adaptation of e-payments has been going along with the increase in deceitful activities, which results in tremendous losses in the financial sector. This led to a novel research paradigm using statistical and auto-data-driven techniques to detect anomalies and fraud. Thus, traditional techniques fail to provide a secure medium for online transactions. Consequently, building a credit card fraud (CCF) detector is essential for secure online operations. Therefore, based on the abovementioned constraints, this paper presents a comprehensive study incorporating heterogeneous machine learning (ML) techniques for CCF detection. The proposed framework utilizes a multi-stage classification system that employs multiple classifiers, i.e., logistic regression, support vector machine (SVM) XGBoost, Random Forest, K-Nearest Neighbors (KNN), and Deep Neural Network (DNN). Furthermore, to accomplish the intensive class imbalance, the proposed technique uses a sampling technique with an internal features selection technique implemented based on voting among different methods. The key finding indicates that the proposed model surpasses the existing DNN simple voting, traditional stacking framework with a fraud recall value of 0.901, a legitimate recall value of 0.995, and a model cost value of 0.421."

## Plain-Language Restatement

Credit-card fraud is extremely rare compared with legitimate spending, so naive fraud detectors either miss fraud or wrongly flag honest customers. This paper builds a fraud detector that first rebalances the training data in a smart way — keeping the "hard" borderline legitimate transactions that look like fraud — and then lets six different machine-learning models vote, with a second-level model making the final call. On a public dataset of 284,807 real European card transactions, the system catches over 90% of frauds while wrongly accusing fewer than 0.5% of legitimate ones, and it cuts the bank's expected fraud losses to 42.1% of what they would be without any model.

## Problem Statement

Rule-based fraud systems are interpretable but computationally intensive, depend on expert subjectivity, are hard to maintain, and cannot generalize to new fraud patterns (paper's motivation, Sec. I). ML replacements hit the core obstacle: CCF is "one of the most imbalanced problems in machine learning applications" — fraud cases are an extreme minority. Classical resampling (e.g., SMOTE) improves minority detection but "introduced noticeable false positive errors for the majority class" — many non-fraud cases falsely classified as fraud. The gap: a resampling strategy that neutralizes imbalance *without* inflating majority-class false positives, plus a classifier stack that beats simple voting/traditional stacking under such imbalance.

## Methodology

- **Dataset**: public Kaggle credit card dataset (MLG-ULB `creditcardfraud`): 284,807 transactions by European cardholders, recorded within two days in September (last quarter of) 2013; all features PCA-transformed into 28 encoded features plus plain-text transaction time and amount; 492 frauds = 0.173% class percentage. (Sec. IV-A)
- **Two experimental tracks**: (a) bypass all data-handling stages and classify directly; (b) run the full data pipeline before classification. (Sec. IV-B)
- **Data pipeline (Figure 1)**: Handling nulls & dropping duplicates (KNN imputation module, though the Kaggle set has no empty values) → outlier check (Isolation Forest, chosen for multi-variable outliers) → feature selection (exploring feature variability against labels).
- **Proposed distribution-based resampling (Algorithm 1)**: split data into imbalanced train (I) and test (T); split I into minority (X) and majority (Y); use KNN to label each Y sample as a *boundary point* (B) or *mass point* (M); draw random sets B1…Bm from B; cluster M with k-means and draw random sets G1…Gk from the K clusters; draw random sets X1…Xn from X; mix combinations of {Bi}, {Gj}, {Xi} into Modified Training Sets. Rationale: force the model to consider boundary points while avoiding SMOTE-style noise and under-sampling information loss.
- **Proposed multi-stage identification (Figure 2)**: first layer runs six heterogeneous classifiers — Logistic Regression, SVM, XGBoost, Random Forest, KNN, DNN — each emitting a local output class + classification probability; a second-layer **Linear SVM** consumes only those decisions + probabilities and produces the final classification. Claimed advantages: neutralizes first-layer misclassifications, weighs credibility via decision probability, and the second layer never needs the full feature set.
- **Baselines**: each sub-model individually, simple (max) voting, and traditional stacking.
- **Grid-searched hyperparameters** (Sec. V): LR: Alpha=0.3, fit_intercept=True, normalize=True, solver=sag; SVM: kernel='rbf', degree=2, gamma='scale', coef_0=0.01, shrinking=False; XGBoost: verbosity=true, validate_parameters=true, min_split_loss=0.002, max_depth=10; Random Forest: max_depth=7, min_sample_split=3, no. of trees=60, min_samples_leaf=6; DNN: hidden_layer_sizes=2, activation=ReLU, learning_rate=0.001, solver='Adam'; KNN: k=5. DNN structure comprises two hidden layers followed by a softmax layer. (Text also says two models, DNN and CNN, were developed; only DNN appears in results.)
- **Metrics (Table 2)**: Specificity TN/(FP+TN), Sensitivity TP/(FN+TP), Precision TP/(TP+FP); plus recall, FPR, F1; accuracy deemed meaningless under imbalance.
- **Cost model (Eqs. 1–3)**: C_Investigation = Y·Amt (Y = cases predicted fraud but legitimate; Amt = investigation cost); C_overall = C_Investigation + Σ_FN Trans_Amount_i; Model Cost_f = C_overall(f)/C_overall(withoutModel).

## Key Results

**Table 4 — final framework comparison** (configuration: running data pipelines / using the proposed resampling method):

| Model | Fraud Recall | Legitimate Recall | Model Cost |
|---|---|---|---|
| DNN Only | 0.889 | 0.995 | 0.462 |
| Simple Voting | 0.89 | 0.995 | 0.464 |
| Traditional Stacking Framework | 0.897 | 0.996 | 0.459 |
| **Proposed Framework** | **0.901** | **0.995** | **0.421** |

**Table 3 — sub-models** (Fraud Recall / Legit Recall / Model Cost; best proposed-sampling rows bolded conceptually):

| Model | Sampling | No pipeline: Fraud / Legit / Cost | With pipeline: Fraud / Legit / Cost |
|---|---|---|---|
| LR | Without | 0.622 / 0.896 / 0.662 | 0.67 / 0.901 / 0.531 |
| LR | SMOTE | 0.791 / 0.92 / 0.591 | 0.854 / 0.967 / 0.47 |
| LR | Proposed | 0.801 / 0.959 / 0.504 | 0.881 / 0.977 / 0.433 |
| SVM | Without | 0.77 / 0.92 / 0.6 | 0.821 / 0.996 / 0.587 |
| SVM | SMOTE | 0.802 / 0.911 / 0.529 | 0.888 / 0.907 / 0.418 |
| SVM | Proposed | 0.839 / 0.976 / 0.511 | 0.892 / 0.996 / 0.49 |
| XGB | Without | 0.704 / 0.966 / 0.591 | 0.776 / 0.989 / 0.571 |
| XGB | SMOTE | 0.821 / 0.981 / 0.58 | 0.834 / 0.988 / 0.572 |
| XGB | Proposed | 0.849 / 0.982 / 0.517 | 0.886 / 0.998 / 0.514 |
| RF | Without | 0.76 / 0.909 / 0.559 | 0.781 / 0.971 / 0.507 |
| RF | SMOTE | 0.802 / 0.963 / 0.531 | 0.809 / 0.985 / 0.571 |
| RF | Proposed | 0.835 / 0.979 / 0.521 | 0.87 / 0.991 / 0.499 |
| KNN | Without | 0.68 / 0.89 / 0.609 | 0.699 / 0.909 / 0.6 |
| KNN | SMOTE | 0.801 / 0.917 / 0.553 | 0.82 / 0.93 / 0.518 |
| KNN | Proposed | 0.838 / 0.941 / 0.568 | 0.869 / 0.99 / 0.501 |
| DNN | Without | 0.781 / 0.98 / 0.522 | 0.779 / 0.992 / 0.513 |
| DNN | SMOTE | 0.809 / 0.979 / 0.519 | 0.884 / 0.959 / 0.481 |
| DNN | Proposed | 0.87 / 0.984 / 0.503 | 0.889 / 0.995 / 0.462 |

Qualitative findings from the text and Figures 3–4:
- DNN is superior to the other algorithms run individually; the full end-to-end data pipeline enhances performance and decreases bias tendency; proposed resampling > raw > SMOTE.
- Figure 3: f1-measure of the proposed scheme is higher than SVM, KNN, and RF under over/under-sampling comparisons (proposed oversampling bar ≈0.80 vs SVM ≈0.79, KNN ≈0.63, RF ≈0.71; values read from chart).
- Figure 4: cost function of the proposed scheme is lower than competing techniques (proposed ≈0.28 undersampling / ≈0.40 oversampling vs KNN ≈0.40/≈0.56; values read from chart).

## Conclusions & Implications

Authors conclude the heterogeneous multi-stage framework detects CCF "with minimum false positive and false pessimistic predictions," achieving over 0.9 fraud recall while keeping legitimate recall above 0.995, and that the architecture transfers to other ML applications with intensive class imbalance. For practitioners building payment-fraud systems: (1) feeding first-layer decisions *and* their probabilities into a lightweight linear meta-learner beats voting and vanilla stacking, and slashes meta-layer feature requirements; (2) distribution-aware resampling that preserves boundary points is a credible alternative to SMOTE when false positives on good customers carry real investigation cost; (3) reporting bank-KPI cost ratios (Eq. 3) aligns model selection with business outcomes rather than raw accuracy.

## Limitations

*(Acknowledged by authors)*: multi-stage classification consumes more processing resources as data size grows (Sec. I); evaluation limited to one public benchmark dataset; the interpretability layer is proposed but not evaluated in depth.
*(Inferred by me)*: the Kaggle PCA-anonymized dataset lacks merchant/MCC, geo, and behavioral features of production fraud; CNN is announced but never reported; Figure 3's caption says "MCC Results" while its y-axis is f1-measure and the text invokes a nonexistent reference [69] and "merchant category codes (MCC)" confusingly — the comparison figures appear disconnected from the main pipeline experiments; no statistical significance tests or variance across runs are reported despite "multiple runs and experiments"; reference numbering is misaligned in places (e.g., [69] absent from the reference list, refs end at [67]).

## Relevance to Our Hackathon

Directly reusable for a Razorpay-track fraud/RTO stack: (1) the **two-layer stacking with decision probabilities** is cheap to port — run XGBoost + DNN + logistic base models on RTO-risk features and let a linear meta-model learn when to trust whom; the meta-model needing only predictions, not raw features, simplifies serving. (2) The **boundary/mass-point resampling** idea fits COD/RTO labels (heavily imbalanced) and targets exactly our pain: raising fraud/RTO recall without drowning legit shipments in false holds. (3) The **bank cost KPI (Model Cost ratio)** is a template for our own cost-sensitive threshold tuning — replace investigation cost with RTO reverse-logistics cost. (4) The imputation + Isolation Forest + feature-selection pipeline is a sensible default preprocessing block for transaction features. (5) Its honest reporting of the legit-recall tradeoff (0.995) sets the right evaluation bar: always report fraud recall AND legitimate recall AND cost together.

## Figures & Tables

- **Figure 1** (p. 77043) — flowchart, 3 boxes: "Handling Nulls and Dropping Duplicates" → "Check The Outlier's" → "Features Selection"; clean vector diagram, supports the data-pipeline description.
- **Figure 2** (p. 77044) — architecture diagram: Input Data Set fans into 6 classifier boxes (Logistic Regression, SVM, XGBoost, Random Forest, KNN, DNN); each outputs "Local Output Class Classification Probability"; a **Linear SVM** second layer produces Output Classification. Vector-drawn; confirms the meta-learner choice.
- **Figure 3** (p. 77046) — grouped bar chart, y-axis "f1 measure" (0–1), x: SVM, KNN, RF, Proposed Scheme; series Undersampling (blue) / Oversampling (orange); proposed ≈0.59/0.80 vs KNN ≈0.42/0.63 (chart-read). Caption says "MCC Results" but axis is f1-measure — internal inconsistency.
- **Figure 4** (p. 77046) — grouped bar chart, y-axis "Cost (%)" (0–0.6), same x/series; proposed lowest (≈0.28/0.40), KNN highest (≈0.40/0.56) (chart-read). Supports the cost-superiority claim.
- **Table 1** (p. 77042) — qualitative comparison of prior CCF techniques [61]–[67]: technique, working, limitations (e.g., [61] LR+DL on a Nigerian bank dataset, no real-time consideration; [66] 66 ML models, undersampling slows processing).
- **Table 2** (p. 77045) — metric definitions/formulas: Specificity TN/(FP+TN), Sensitivity TP/(FN+TP), Precision TP/(TP+FP).
- **Table 3** (p. 77046) — 6 models × 3 sampling × 2 pipeline configs; full numbers in Key Results; DNN+proposed+pipeline best individual (0.889/0.995/0.462).
- **Table 4** (p. 77046) — final comparison; proposed framework 0.901 fraud recall / 0.995 legit recall / 0.421 model cost.
- **img_p001_323.png** (p. 1) — IEEE Access journal logo banner, not a data figure.
