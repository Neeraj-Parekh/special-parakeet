# Knowledge Graph — Paper Relationships

_Edges: explicit mentions detected across summaries (author-surname+year or near-exact title), plus up to 3 strongest tag-overlap neighbours._

- **Learning from Imbalanced Data Sets** (`book-learning-from-imbalanced-data-sets`)
  - closest kin → [Learning from Imbalanced Data](./learning-from-imbalanced-data-he-garcia/summary.md) (5), [Cost Sensitive Credit Card Fraud Detection using Bayes Minimum Risk](./cost-sensitive-fraud-detection-bayes-minimum-risk/summary.md) (5), [Cost Curves: An Improved Method for Visualizing Classifier Performance](./cost-curves-classifier-performance/summary.md) (5)

- **A Survey on Concept Drift Adaptation** (`survey-concept-drift-adaptation`)
  - closest kin → [TFX: A TensorFlow-Based Production-Scale Machine Learning Platform](./tfx-production-scale-ml-platform/summary.md) (3), [Integrating MLOps with DevOps: A Blueprint for Scalable AI Deployments in Production](./mlops-devops-integration-scalable-ai-deployments/summary.md) (3), [Challenges in Deploying Machine Learning: a Survey of Case Studies](./challenges-in-deploying-ml-case-studies/summary.md) (3)

- **Cost Curves: An Improved Method for Visualizing Classifier Performance** (`cost-curves-classifier-performance`)
  - closest kin → [Learning from Imbalanced Data](./learning-from-imbalanced-data-he-garcia/summary.md) (5), [Cost Sensitive Credit Card Fraud Detection using Bayes Minimum Risk](./cost-sensitive-fraud-detection-bayes-minimum-risk/summary.md) (5), [Learning from Imbalanced Data Sets](./book-learning-from-imbalanced-data-sets/summary.md) (5)

- **Learning from Imbalanced Data** (`learning-from-imbalanced-data-he-garcia`)
  - closest kin → [Cost Sensitive Credit Card Fraud Detection using Bayes Minimum Risk](./cost-sensitive-fraud-detection-bayes-minimum-risk/summary.md) (5), [Cost Curves: An Improved Method for Visualizing Classifier Performance](./cost-curves-classifier-performance/summary.md) (5), [Learning from Imbalanced Data Sets](./book-learning-from-imbalanced-data-sets/summary.md) (5)

- **Challenges in Deploying Machine Learning: a Survey of Case Studies** (`challenges-in-deploying-ml-case-studies`)
  - closest kin → [TFX: A TensorFlow-Based Production-Scale Machine Learning Platform](./tfx-production-scale-ml-platform/summary.md) (3), [A Survey on Concept Drift Adaptation](./survey-concept-drift-adaptation/summary.md) (3), [Open Fabric for Deep Learning Models](./open-fabric-for-deep-learning/summary.md) (3)

- **Open Fabric for Deep Learning Models** (`open-fabric-for-deep-learning`)
  - closest kin → [TFX: A TensorFlow-Based Production-Scale Machine Learning Platform](./tfx-production-scale-ml-platform/summary.md) (3), [Performance and Cost Comparison of Cloud Services for Deep Learning Workload](./cloud-cost-comparison-deep-learning-workloads/summary.md) (3), [Challenges in Deploying Machine Learning: a Survey of Case Studies](./challenges-in-deploying-ml-case-studies/summary.md) (3)

- **Performance and Cost Comparison of Cloud Services for Deep Learning Workload** (`cloud-cost-comparison-deep-learning-workloads`)
  - closest kin → [Open Fabric for Deep Learning Models](./open-fabric-for-deep-learning/summary.md) (3), [TFX: A TensorFlow-Based Production-Scale Machine Learning Platform](./tfx-production-scale-ml-platform/summary.md) (2), [A Survey on Concept Drift Adaptation](./survey-concept-drift-adaptation/summary.md) (2)

- **TFX: A TensorFlow-Based Production-Scale Machine Learning Platform** (`tfx-production-scale-ml-platform`)
  - closest kin → [A Survey on Concept Drift Adaptation](./survey-concept-drift-adaptation/summary.md) (3), [Open Fabric for Deep Learning Models](./open-fabric-for-deep-learning/summary.md) (3), [Integrating MLOps with DevOps: A Blueprint for Scalable AI Deployments in Production](./mlops-devops-integration-scalable-ai-deployments/summary.md) (3)

- **Integrating MLOps with DevOps: A Blueprint for Scalable AI Deployments in Production** (`mlops-devops-integration-scalable-ai-deployments`)
  - closest kin → [TFX: A TensorFlow-Based Production-Scale Machine Learning Platform](./tfx-production-scale-ml-platform/summary.md) (3), [A Survey on Concept Drift Adaptation](./survey-concept-drift-adaptation/summary.md) (3), [Challenges in Deploying Machine Learning: a Survey of Case Studies](./challenges-in-deploying-ml-case-studies/summary.md) (3)

- **SoK: Security of Autonomous LLM Agents in Agentic Commerce** (`sok-security-autonomous-llm-agents-agentic-commerce`)
  - closest kin → [The CMA Agentic Platform: Autonomous Asset Verification and Algorithmic Auditor Governance](./cma-agentic-platform-autonomous-asset-verification/summary.md) (6), [AI Agents in Payments: Applications, Risks and Regulations](./ai-agents-payments-applications-risks-regulations/summary.md) (6), [The Agent Economy: A Blockchain-Based Foundation for Autonomous AI Agents](./agent-economy-blockchain-foundation/summary.md) (6)

- **The Role of AI Agents in Autonomous Online Purchasing** (`role-of-ai-agents-autonomous-online-purchasing`)
  - closest kin → [From Recommendations to Delegation: A Systematic Review Mapping Agentic AI in E-Commerce and Its Consumer Effects](./recommendations-to-delegation-agentic-ai-ecommerce-review/summary.md) (4), [Exploring User Acceptance of Physical Intelligent Assistants: A Study on AI-Powered Eyewear](./user-acceptance-physical-intelligent-assistants-eyewear/summary.md) (3), [Trustworthy agentic AI systems: a cross-layer review of architectures, threat models, and governance strategies for real-world deployment](./trustworthy-agentic-ai-systems-cross-layer-review/summary.md) (3)

- **Agentic AI Payments: Navigating Consumer Protection, Innovation, and Regulatory Frameworks** (`cba-whitepaper-agentic-ai-payments-consumer-protection`)
  - closest kin → [File Viewer.pdf — TeamLease Regtech File Viewer capture hosting NPCI/UPI/OC No.201/2024-25 ('UPI Circle' — Delegated Payments for secondary users)](./teamlease-regtech-compliance-brochure/summary.md) (6), [AI Agents in Payments: Applications, Risks and Regulations](./ai-agents-payments-applications-risks-regulations/summary.md) (6), [Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B](./upi-delegated-payments-npci-oc201b-lexology/summary.md) (5)

- **AI Agents in Payments: Applications, Risks and Regulations** (`ai-agents-payments-applications-risks-regulations`)
  - closest kin → [Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B](./upi-delegated-payments-npci-oc201b-lexology/summary.md) (6), [SoK: Security of Autonomous LLM Agents in Agentic Commerce](./sok-security-autonomous-llm-agents-agentic-commerce/summary.md) (6), [Agentic AI Payments: Navigating Consumer Protection, Innovation, and Regulatory Frameworks](./cba-whitepaper-agentic-ai-payments-consumer-protection/summary.md) (6)

- **Agentic Commerce: A Systematic Review of AI-Driven Autonomous Shopping and Emerging Transaction Protocols** (`agentic-commerce-systematic-review-autonomous-shopping`)
  - closest kin → [SoK: Security of Autonomous LLM Agents in Agentic Commerce](./sok-security-autonomous-llm-agents-agentic-commerce/summary.md) (4), [From Recommendations to Delegation: A Systematic Review Mapping Agentic AI in E-Commerce and Its Consumer Effects](./recommendations-to-delegation-agentic-ai-ecommerce-review/summary.md) (4), [Blockchain Empowered Trustworthy Agent Networks: Foundations, Taxonomy, and Future Directions](./blockchain-empowered-trustworthy-agent-networks/summary.md) (4)

- **Agentic AI: Autonomy, Accountability, and the Algorithmic Society** (`agentic-ai-autonomy-accountability-algorithmic-society`)
  - closest kin → [AI Agents in Payments: Applications, Risks and Regulations](./ai-agents-payments-applications-risks-regulations/summary.md) (6), [Agentic Proxies: Governance, Accountability, and the Architecture of a Trustworthy AI Economy](./agentic-proxies-governance-trustworthy-ai-economy/summary.md) (6), [Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B](./upi-delegated-payments-npci-oc201b-lexology/summary.md) (5)

- **European Union Regulations on Algorithmic Decision Making and a "Right to Explanation"** (`eu-regulations-right-to-explanation-gdpr`)
  - closest kin → [File Viewer.pdf — TeamLease Regtech File Viewer capture hosting NPCI/UPI/OC No.201/2024-25 ('UPI Circle' — Delegated Payments for secondary users)](./teamlease-regtech-compliance-brochure/summary.md) (4), [Agentic AI Payments: Navigating Consumer Protection, Innovation, and Regulatory Frameworks](./cba-whitepaper-agentic-ai-payments-consumer-protection/summary.md) (4), [Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B](./upi-delegated-payments-npci-oc201b-lexology/summary.md) (3)

- **Liability for Autonomous Financial Agents: Autonomy, Accountability, and the Architecture of Law in the Age of Algorithmic Finance** (`liability-autonomous-financial-agents`)
  - closest kin → [Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B](./upi-delegated-payments-npci-oc201b-lexology/summary.md) (4), [SoK: Security of Autonomous LLM Agents in Agentic Commerce](./sok-security-autonomous-llm-agents-agentic-commerce/summary.md) (4), [Addendum to NPCI/UPI/2024-25/OC 201 — Introduction of IoT devices & software on UPI Circle](./npci-oc201b-upi-circle-iot-circular/summary.md) (4)

- **Agentic Proxies: Governance, Accountability, and the Architecture of a Trustworthy AI Economy** (`agentic-proxies-governance-trustworthy-ai-economy`)
  - closest kin → [AI Agents in Payments: Applications, Risks and Regulations](./ai-agents-payments-applications-risks-regulations/summary.md) (6), [Agentic AI: Autonomy, Accountability, and the Algorithmic Society](./agentic-ai-autonomy-accountability-algorithmic-society/summary.md) (6), [Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B](./upi-delegated-payments-npci-oc201b-lexology/summary.md) (5)

- **AI agent, take over?! Task delegation to agentic AI systems in the Philippines** (`task-delegation-agentic-ai-philippines`)
  - closest kin → [Exploring User Acceptance of Physical Intelligent Assistants: A Study on AI-Powered Eyewear](./user-acceptance-physical-intelligent-assistants-eyewear/summary.md) (4), [From Recommendations to Delegation: A Systematic Review Mapping Agentic AI in E-Commerce and Its Consumer Effects](./recommendations-to-delegation-agentic-ai-ecommerce-review/summary.md) (4), [Agentic AI as a service innovation: A mixed-methods study of satisfaction, trust, and continued use](./agentic-ai-as-a-service-trust-satisfaction-continuance/summary.md) (4)

- **The Agent Economy: A Blockchain-Based Foundation for Autonomous AI Agents** (`agent-economy-blockchain-foundation`)
  - closest kin → [SoK: Security of Autonomous LLM Agents in Agentic Commerce](./sok-security-autonomous-llm-agents-agentic-commerce/summary.md) (6), [Blockchain Empowered Trustworthy Agent Networks: Foundations, Taxonomy, and Future Directions](./blockchain-empowered-trustworthy-agent-networks/summary.md) (6), [The CMA Agentic Platform: Autonomous Asset Verification and Algorithmic Auditor Governance](./cma-agentic-platform-autonomous-asset-verification/summary.md) (5)

- **Blockchain Empowered Trustworthy Agent Networks: Foundations, Taxonomy, and Future Directions** (`blockchain-empowered-trustworthy-agent-networks`)
  - closest kin → [The Agent Economy: A Blockchain-Based Foundation for Autonomous AI Agents](./agent-economy-blockchain-foundation/summary.md) (6), [SoK: Security of Autonomous LLM Agents in Agentic Commerce](./sok-security-autonomous-llm-agents-agentic-commerce/summary.md) (5), [Agentic Proxies: Governance, Accountability, and the Architecture of a Trustworthy AI Economy](./agentic-proxies-governance-trustworthy-ai-economy/summary.md) (5)

- **Trustworthy agentic AI systems: a cross-layer review of architectures, threat models, and governance strategies for real-world deployment** (`trustworthy-agentic-ai-systems-cross-layer-review`)
  - closest kin → [Trust in human–AI collaboration in finance: a bibliometric–systematic literature review](./trust-human-ai-collaboration-finance-review/summary.md) (5), [Digital Product Passports as Agentic Supply Chain Infrastructure: A Strategic Framework for Fashion](./digital-product-passports-agentic-supply-chain-fashion/summary.md) (5), [Agentic Proxies: Governance, Accountability, and the Architecture of a Trustworthy AI Economy](./agentic-proxies-governance-trustworthy-ai-economy/summary.md) (5)

- **Trust in human–AI collaboration in finance: a bibliometric–systematic literature review** (`trust-human-ai-collaboration-finance-review`)
  - closest kin → [Trustworthy agentic AI systems: a cross-layer review of architectures, threat models, and governance strategies for real-world deployment](./trustworthy-agentic-ai-systems-cross-layer-review/summary.md) (5), [Digital Product Passports as Agentic Supply Chain Infrastructure: A Strategic Framework for Fashion](./digital-product-passports-agentic-supply-chain-fashion/summary.md) (4), [AI Agents in Payments: Applications, Risks and Regulations](./ai-agents-payments-applications-risks-regulations/summary.md) (4)

- **A prescriptive analytics framework for efficient E-commerce order delivery** (`prescriptive-analytics-ecommerce-order-delivery`)
  - closest kin → [Machine Learning-Based Prediction and Interpretability Analysis of Logistics Delay Risks in E-commerce Supply Chains](./ml-interpretability-logistics-delay-risk-ecommerce/summary.md) (5), [Cost Sensitive Credit Card Fraud Detection using Bayes Minimum Risk](./cost-sensitive-fraud-detection-bayes-minimum-risk/summary.md) (5), [Learning from Imbalanced Data](./learning-from-imbalanced-data-he-garcia/summary.md) (4)

- **Machine Learning-Based Prediction and Interpretability Analysis of Logistics Delay Risks in E-commerce Supply Chains** (`ml-interpretability-logistics-delay-risk-ecommerce`)
  - closest kin → [A prescriptive analytics framework for efficient E-commerce order delivery](./prescriptive-analytics-ecommerce-order-delivery/summary.md) (5), [Cost Sensitive Credit Card Fraud Detection using Bayes Minimum Risk](./cost-sensitive-fraud-detection-bayes-minimum-risk/summary.md) (4), [Learning from Imbalanced Data](./learning-from-imbalanced-data-he-garcia/summary.md) (3)

- **Analyzing the Adoption and Influence of AI in Retail Supply Chain Operations** (`ai-adoption-retail-supply-chain-operations`)
  - closest kin → [Supply Chain with Sixth Sense Agentic AI: A Proactive Intelligence Framework for Autonomous Planning](./sixth-sense-agentic-ai-supply-chain-planning/summary.md) (3), [The Role of Artificial Intelligence in Green Supply Chain Management](./ai-green-supply-chain-management/summary.md) (3), [Artificial intelligence in retail: The AI-enabled value chain](./ai-enabled-value-chain-retail/summary.md) (3)

- **The Role of Artificial Intelligence in Green Supply Chain Management** (`ai-green-supply-chain-management`)
  - closest kin → [Supply Chain with Sixth Sense Agentic AI: A Proactive Intelligence Framework for Autonomous Planning](./sixth-sense-agentic-ai-supply-chain-planning/summary.md) (3), [Analyzing the Adoption and Influence of AI in Retail Supply Chain Operations](./ai-adoption-retail-supply-chain-operations/summary.md) (3), [A prescriptive analytics framework for efficient E-commerce order delivery](./prescriptive-analytics-ecommerce-order-delivery/summary.md) (2)

- **Supply Chain with Sixth Sense Agentic AI: A Proactive Intelligence Framework for Autonomous Planning** (`sixth-sense-agentic-ai-supply-chain-planning`)
  - closest kin → [Trust in human–AI collaboration in finance: a bibliometric–systematic literature review](./trust-human-ai-collaboration-finance-review/summary.md) (3), [The Role of Artificial Intelligence in Green Supply Chain Management](./ai-green-supply-chain-management/summary.md) (3), [Analyzing the Adoption and Influence of AI in Retail Supply Chain Operations](./ai-adoption-retail-supply-chain-operations/summary.md) (3)

- **Digital Product Passports as Agentic Supply Chain Infrastructure: A Strategic Framework for Fashion** (`digital-product-passports-agentic-supply-chain-fashion`)
  - closest kin → [Trustworthy agentic AI systems: a cross-layer review of architectures, threat models, and governance strategies for real-world deployment](./trustworthy-agentic-ai-systems-cross-layer-review/summary.md) (5), [SoK: Security of Autonomous LLM Agents in Agentic Commerce](./sok-security-autonomous-llm-agents-agentic-commerce/summary.md) (5), [Addendum to NPCI/UPI/2024-25/OC 201 — Introduction of IoT devices & software on UPI Circle](./npci-oc201b-upi-circle-iot-circular/summary.md) (5)

- **Exploring User Acceptance of Physical Intelligent Assistants: A Study on AI-Powered Eyewear** (`user-acceptance-physical-intelligent-assistants-eyewear`)
  - closest kin → [AI agent, take over?! Task delegation to agentic AI systems in the Philippines](./task-delegation-agentic-ai-philippines/summary.md) (4), [Agentic AI as a service innovation: A mixed-methods study of satisfaction, trust, and continued use](./agentic-ai-as-a-service-trust-satisfaction-continuance/summary.md) (4), [The Role of AI Agents in Autonomous Online Purchasing](./role-of-ai-agents-autonomous-online-purchasing/summary.md) (3)

- **From Recommendations to Delegation: A Systematic Review Mapping Agentic AI in E-Commerce and Its Consumer Effects** (`recommendations-to-delegation-agentic-ai-ecommerce-review`)
  - closest kin → [File Viewer.pdf — TeamLease Regtech File Viewer capture hosting NPCI/UPI/OC No.201/2024-25 ('UPI Circle' — Delegated Payments for secondary users)](./teamlease-regtech-compliance-brochure/summary.md) (4), [AI agent, take over?! Task delegation to agentic AI systems in the Philippines](./task-delegation-agentic-ai-philippines/summary.md) (4), [The Role of AI Agents in Autonomous Online Purchasing](./role-of-ai-agents-autonomous-online-purchasing/summary.md) (4)

- **The CMA Agentic Platform: Autonomous Asset Verification and Algorithmic Auditor Governance** (`cma-agentic-platform-autonomous-asset-verification`)
  - closest kin → [SoK: Security of Autonomous LLM Agents in Agentic Commerce](./sok-security-autonomous-llm-agents-agentic-commerce/summary.md) (6), [AI Agents in Payments: Applications, Risks and Regulations](./ai-agents-payments-applications-risks-regulations/summary.md) (5), [Agentic Proxies: Governance, Accountability, and the Architecture of a Trustworthy AI Economy](./agentic-proxies-governance-trustworthy-ai-economy/summary.md) (5)

- **Agentic AI as a service innovation: A mixed-methods study of satisfaction, trust, and continued use** (`agentic-ai-as-a-service-trust-satisfaction-continuance`)
  - closest kin → [Exploring User Acceptance of Physical Intelligent Assistants: A Study on AI-Powered Eyewear](./user-acceptance-physical-intelligent-assistants-eyewear/summary.md) (4), [AI agent, take over?! Task delegation to agentic AI systems in the Philippines](./task-delegation-agentic-ai-philippines/summary.md) (4), [The Role of AI Agents in Autonomous Online Purchasing](./role-of-ai-agents-autonomous-online-purchasing/summary.md) (3)

- **Artificial intelligence in retail: The AI-enabled value chain** (`ai-enabled-value-chain-retail`)
  - closest kin → [A prescriptive analytics framework for efficient E-commerce order delivery](./prescriptive-analytics-ecommerce-order-delivery/summary.md) (3), [Analyzing the Adoption and Influence of AI in Retail Supply Chain Operations](./ai-adoption-retail-supply-chain-operations/summary.md) (3), [Exploring User Acceptance of Physical Intelligent Assistants: A Study on AI-Powered Eyewear](./user-acceptance-physical-intelligent-assistants-eyewear/summary.md) (2)

- **When AI Agents Act: Governance, Accountability, and Strategic Risk in Autonomous Organizations** (`when-ai-agents-act-governance-autonomous-organizations`)
  - closest kin → [Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B](./upi-delegated-payments-npci-oc201b-lexology/summary.md) (4), [The CMA Agentic Platform: Autonomous Asset Verification and Algorithmic Auditor Governance](./cma-agentic-platform-autonomous-asset-verification/summary.md) (4), [AI Agents in Payments: Applications, Risks and Regulations](./ai-agents-payments-applications-risks-regulations/summary.md) (4)

- **Cost Sensitive Credit Card Fraud Detection using Bayes Minimum Risk** (`cost-sensitive-fraud-detection-bayes-minimum-risk`)
  - closest kin → [A prescriptive analytics framework for efficient E-commerce order delivery](./prescriptive-analytics-ecommerce-order-delivery/summary.md) (5), [Learning from Imbalanced Data](./learning-from-imbalanced-data-he-garcia/summary.md) (5), [Hybrid Machine Learning-Based Multi-Stage Framework for Detection of Credit Card Anomalies and Fraud](./hybrid-multistage-credit-card-anomaly-fraud/summary.md) (5)

- **Hybrid Machine Learning-Based Multi-Stage Framework for Detection of Credit Card Anomalies and Fraud** (`hybrid-multistage-credit-card-anomaly-fraud`)
  - closest kin → [Cost Sensitive Credit Card Fraud Detection using Bayes Minimum Risk](./cost-sensitive-fraud-detection-bayes-minimum-risk/summary.md) (5), [A prescriptive analytics framework for efficient E-commerce order delivery](./prescriptive-analytics-ecommerce-order-delivery/summary.md) (4), [Learning from Imbalanced Data](./learning-from-imbalanced-data-he-garcia/summary.md) (4)

- **Addendum to NPCI/UPI/2024-25/OC 201 — Introduction of IoT devices & software on UPI Circle** (`npci-oc201b-upi-circle-iot-circular`)
  - closest kin → [Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B](./upi-delegated-payments-npci-oc201b-lexology/summary.md) (5), [File Viewer.pdf — TeamLease Regtech File Viewer capture hosting NPCI/UPI/OC No.201/2024-25 ('UPI Circle' — Delegated Payments for secondary users)](./teamlease-regtech-compliance-brochure/summary.md) (5), [SoK: Security of Autonomous LLM Agents in Agentic Commerce](./sok-security-autonomous-llm-agents-agentic-commerce/summary.md) (5)

- **Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B** (`upi-delegated-payments-npci-oc201b-lexology`)
  - closest kin → [AI Agents in Payments: Applications, Risks and Regulations](./ai-agents-payments-applications-risks-regulations/summary.md) (6), [File Viewer.pdf — TeamLease Regtech File Viewer capture hosting NPCI/UPI/OC No.201/2024-25 ('UPI Circle' — Delegated Payments for secondary users)](./teamlease-regtech-compliance-brochure/summary.md) (5), [Addendum to NPCI/UPI/2024-25/OC 201 — Introduction of IoT devices & software on UPI Circle](./npci-oc201b-upi-circle-iot-circular/summary.md) (5)

- **File Viewer.pdf — TeamLease Regtech File Viewer capture hosting NPCI/UPI/OC No.201/2024-25 ('UPI Circle' — Delegated Payments for secondary users)** (`teamlease-regtech-compliance-brochure`)
  - closest kin → [Agentic AI Payments: Navigating Consumer Protection, Innovation, and Regulatory Frameworks](./cba-whitepaper-agentic-ai-payments-consumer-protection/summary.md) (6), [Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B](./upi-delegated-payments-npci-oc201b-lexology/summary.md) (5), [Addendum to NPCI/UPI/2024-25/OC 201 — Introduction of IoT devices & software on UPI Circle](./npci-oc201b-upi-circle-iot-circular/summary.md) (5)
