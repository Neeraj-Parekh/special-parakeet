# Learning from Imbalanced Data

| Field | Value |
|---|---|
| **Authors** | Haibo He, Edwardo A. Garcia |
| **Venue / Year** | IEEE Transactions on Knowledge and Data Engineering (TKDE), Vol. 21, No. 9, pp. 1263–1284, September 2009 (accepted 1 Dec 2008, published online 19 Dec 2008) |
| **Type** | survey |
| **DOI / URL** | DOI 10.1109/TKDE.2008.239 |
| **Processed** | 2026-08-26T05:29:31Z |
| **Source PDFs** | haibohe2009.pdf (sha256 prefix f866baed) |

> Version 1 — generated from extracted PDF text.

## Abstract

"With the continuous expansion of data availability in many large-scale, complex, and networked systems, such as surveillance, security, Internet, and finance, it becomes critical to advance the fundamental understanding of knowledge discovery and analysis from raw data to support decision-making processes. Although existing knowledge discovery and data engineering techniques have shown great success in many real-world applications, the problem of learning from imbalanced data (the imbalanced learning problem) is a relatively new challenge that has attracted growing attention from both academia and industry. The imbalanced learning problem is concerned with the performance of learning algorithms in the presence of underrepresented data and severe class distribution skews. Due to the inherent complex characteristics of imbalanced data sets, learning from such data requires new understandings, principles, algorithms, and tools to transform vast amounts of raw data efficiently into information and knowledge representation. In this paper, we provide a comprehensive review of the development of research in learning from imbalanced data. Our focus is to provide a critical review of the nature of the problem, the state-of-the-art technologies, and the current assessment metrics used to evaluate learning performance under the imbalanced learning scenario. Furthermore, in order to stimulate future research in this field, we also highlight the major opportunities and challenges, as well as potential important research directions for learning from imbalanced data."

## Plain-Language Restatement

In fraud detection, disease screening, and network security, the "interesting" events are extremely rare — sometimes 1 in 10,000. Standard machine-learning algorithms assume balanced classes, so they learn to almost always predict "normal" and miss the rare but critical cases. This survey explains why that happens (data-level causes like overlap, small subgroups, and lack of examples, not just class ratios), then organizes all the known fixes: resampling the data (including SMOTE-style synthetic example generation), making learning cost-sensitive, adapting kernel/SVM methods, and active learning. It also reviews the right evaluation metrics (ROC, precision-recall, cost curves instead of accuracy) and lays out open research challenges.

## Problem Statement

Standard algorithms "assume or expect balanced class distributions or equal misclassification costs," so severe skews compromise their performance — the motivating mammography example has 10,923 negatives vs 260 positives, where classifiers typically reach ~100% majority accuracy but only 0–10% minority accuracy; at 10% minority accuracy, 234 cancerous patients would be misdiagnosed. The gap addressed: despite explosive growth in publications (Fig. 1 tracks IEEE/ACM publication counts), no comprehensive critical review unified (a) the *nature* of the problem beyond mere ratios, (b) the solution families (sampling, cost-sensitive, kernel-based, active learning), and (c) assessment metrics adequate for skew.

## Methodology

Critical literature review organized into problem characterization, solutions taxonomy, and evaluation methodology:

**Nature of the problem (Section 2):**
- Between-class imbalance magnitudes commonly 100:1, 1,000:1, 10,000:1; intrinsic vs extrinsic imbalance (extrinsic arising from time/storage factors such as sporadic transmission interruptions over balanced streams).
- Distinction between *relative imbalance* vs *imbalance due to rare instances* ("absolute rarity"): some relative-imbalance datasets are learned accurately with little disturbance — data-set **complexity is the primary determining factor of classification deterioration**, amplified by relative imbalance. Complexity comprises overlapping, lack of representative data, small disjuncts.
- *Within-class imbalance*: subconcepts (clusters A–D toy model) underrepresented within each class; intertwined with the small-disjuncts problem; illegitimate disjuncts from noise vs legitimate underrepresented subconcepts.
- Combination with small-sample-size/high-dimensionality (face recognition, gene expression): conjunction formation over many features with limited samples leads to overly specific rules/overfitting.
- Case study of decision-tree failure modes: recursive partitioning yields progressively fewer minority observations (weaker confidence estimates) and unlearned feature-conjunction concepts.

**Solutions (Section 3)** — notation S = {(x_i, y_i)}, S_min, S_maj:
1. *Sampling*: random oversampling (ties → overfitting via too-specific rules) and undersampling (risk of missing majority concepts); informed undersampling — EasyEnsemble (independent subsets of majority + multiple classifiers) and BalanceCascade (supervised removal of correctly classified majority examples N'_maj after each hypothesis H(t), iterate with cascading combination); NearMiss-1/2/3 and "most distant" KNN heuristics (NearMiss-2 competitive empirically); OSS.
   - *Synthetic sampling*: SMOTE, x_new = x_i + (x̂_i − x_i) × λ, λ∈[0,1], along segment joining instance and randomly chosen K-NN (K=6 illustrated); drawbacks: over-generalization and variance.
   - *Adaptive synthetic sampling*: Borderline-SMOTE (select instances where m/2 ≤ |S_i:m-NN ∩ S_maj| < m into DANGER; noise when all m neighbors majority); ADASYN with G = (|S_maj| − |S_min|) × β, density ratio r_i = Δ_i/K normalized into distribution, g_i = r_i × G synthetic samples per instance.
   - *Data cleaning*: Tomek links (minimally distanced opposite-class pairs removed), OSS, CNN+Tomek Links, NCL based on ENN (removes examples differing from 2 of 3 NNs), SMOTE+ENN and SMOTE+Tomek.
   - *Cluster-based*: CBO algorithm inflating every cluster (both classes) to equal size so within-class imbalance is treated alongside between-class (worked example: clusters inflated to N_CBO = 60 total, minority clusters 60/2 = 30 each).
   - *Sampling+boosting integration*: SMOTEBoost (SMOTE inside AdaBoost.M2 iterations); DataBoost-IM (seed counts ML = min(|S_maj|/|S_min|, |E_maj|), MS = min(|S_maj|·ML/|S_min|, |E_min|), synthetic sets sized |Es_min| = MS×|S_min|, |Es_maj| = ML×|S_maj|); JOUS-Boost (iid jittering of replicated oversampled points inside boosting — cheap alternative to synthetic generation).
2. *Cost-sensitive learning*: conditional risk R(i|x) = Σ_j P(j|x)C(i,j) with C(Maj,Min) > C(Min,Maj). Three technique classes: (i) dataspace weighting with adaptive boosting — translation theorem foundation; AdaC1/C2/C3 place cost items inside/outside/both in the weight update D_(t+1)(i) = D_t(i)exp(−α_t h_t(x_i)y_i)/Z_t variants; AdaCost with adjustment function β± = ∓0.5Ci + 0.5; CSB1/CSB2; cited comparative result (Sun et al., decision trees + rule association base learners, F-measure): boosted ensemble > standalone base classifier in all cases; cost-sensitive boosted > plain boosting in nearly all cases. (ii) Metatechniques on MetaCost framework. (iii) paradigm-specific fitting — decision trees: threshold-moving via ROC dominant-point selection when costs unknown (Maloof), cost-insensitive impurity functions (Gini/Entropy/DKM outperform accuracy baseline; DKM gives smaller unpruned trees at comparable or better accuracy), pruning harms minority leaves hence Laplace smoothing/Laplace pruning for better class-probability estimates; neural networks (Kukar & Kononenko's four adaptations: modify probability estimate at test time, alter outputs during training, scale learning rates by cost, replace error function with expected-cost minimization — the last shown most dominant). Also notes cost-sensitive Bayesian classifiers and SVM cost integrations.
3. *Kernel-based methods*: SVM failure analysis (total-error minimization biases boundary toward majority; worst case classifies everything majority); integration approaches — SDC (SMOTE with Different Costs), ensembles of over/undersampled SVMs, boosted asymmetric-cost SVMs (Wang & Japkowicz), GSVM-RU (granular SVMs iteratively removing "negative local support vectors" as informed undersampling, then aggregating granules); kernel modifications — OFS/ROWLS with leave-one-out AUC objective and minority-weighted cost function; boundary movement/biased penalties/class-boundary alignment (BM/BPs/CBA); kernel-boundary alignment (KBA) via adaptive conformal transformation using feature-space distance and imbalance ratio; TAF-SVM (fuzzified data, embedded costs, total-margin paradigm); k-category PSVM with Newton refinement solving linear equations; plus SCMs, KNG, hybrid one-class+binary kernel ensembles.
4. *Active learning*: Ertekin et al.'s observation that imbalance ratio within the SVM margin is much smaller than overall — query informative near-hyperplane instances from small pools using LASVM online learner with early stopping; Zhu & Hovy entropy-based uncertainty sampling with max-confidence/min-error stopping bounds for word-sense disambiguation; SALH genetic-programming subsampling with modified Wilcoxon-Mann-Whitney cost function over six datasets.
5. *Additional methods*: one-class/novelty detection (one-class SVMs, autoassociators; useful for extreme imbalance/high dimensionality; Lee & Cho: novelty detection suits extreme skew, discriminative classifiers moderate skew); Mahalanobis-Taguchi System with Chebyshev-theorem probabilistic thresholding; rank metrics + multitask learning for combined imbalance/small-sample/high-dimensionality (Caruana); brief multiclass coverage (AdaC2.M1 with GA cost search, iterative multiclass cost weighting, min-max modular decomposition, rescaling cost-sensitive NNs, eKISS).

**Assessment metrics (Section 4)**: confusion-matrix convention (minority = positive); accuracy/error-rate critique — any metric mixing both columns is distribution-sensitive (trivial all-majority classifier gets 95% at 5% prevalence while identifying 0% of minority); precision (distribution-sensitive) vs recall (not, but equivocal alone); F-Measure (β coefficient) and G-Mean = √(TP/(TP+FN) × TN/(TN+FP)); ROC curves/TP-rate-vs-FP-rate with AUC for soft classifiers (high-AUC classifier can still lose in specific ROC regions); PR curves — ROC overly optimistic under heavy skew since large FP changes barely move FP-rate when N_c ≫ P_c, while precision captures it; ROC dominance ⇔ PR-space dominance but AUC optimization does not transfer between spaces; achievable PR curve analog of convex hull; cost curves (citing Holte & Drummond) plotting expected cost E[C] = (1 − TP − FP)·PC(+) + FP over probability-cost with ROC point/line duality, adding confidence-interval/significance capabilities; multiclass extensions — n one-vs-all ROC graphs (becomes skew-sensitive because negatives pool n−1 classes), prevalence-weighted AUC combination (Provost & Domingos), Hand & Till's M measure (insensitive to class distribution and error costs), misclassification costs, and multiclass G-mean as geometric mean of per-class recalls (Sun et al.).

## Key Results

Survey — key claims/frameworks rather than new experiments:

| Item | Content as reported |
|---|---|
| Motivating dataset | Mammography: 10,923 negative vs 260 positive; typical minority accuracies 0–10%; 10% ⇒ 234 missed cancer cases |
| Common skew levels | Between-class imbalances of 100:1, 1,000:1, 10,000:1 |
| Central thesis | Data-set complexity (overlap, small disjuncts, lack of representative data) is the primary determinant of degradation; imbalance amplifies it |
| Boosting comparison (Sun et al.) | Ensembles beat standalone base learners in ALL cases (F-measure); cost-sensitive boosting beats plain boosting in nearly all cases |
| Splitting criteria | Gini/Entropy/DKM more cost-insensitive than accuracy; DKM yields smaller unpruned trees with comparable-or-better accuracy |
| Class-distribution study (Weiss & Provost, 26 datasets) | Best training distribution ≈ natural distribution if optimizing accuracy; ≈ balanced if optimizing AUC; motivated budget-sensitive progressive sampling |
| Margin insight (Ertekin et al.) | Imbalance ratio within the SVM margin ≪ overall imbalance ratio — basis for efficient active learning |
| Metric sensitivities | Accuracy & F-measure & precision: distribution-sensitive; recall, ROC TP/FP-rates, G-mean components, Hand-Till M: not |

Qualitative insights: cost-sensitive learning can be superior to sampling in certain domains (cited studies); novelty detection fits extreme skew while discriminative learning fits moderate skew; targeting within-class imbalance jointly with between-class imbalance (CBO evidence) is effective; the field lacked uniform imbalanced-learning benchmarks and standardized curve-based evaluation practices.

## Conclusions & Implications

Authors' claims: imbalanced learning requires understanding data complexity, not just reweighting ratios; solutions should be chosen among sampling, cost-sensitive, kernel, and active-learning families according to cost knowledge availability and skew severity; evaluation must move to ROC/PR/cost curves with multiclass-aware aggregates. Open directions (Section 5): (1) fundamental theory — assumptions under which imbalance methods beat original-distribution learning, optimal balance degree, complexity effects, error bounds; (2) a dedicated public benchmark platform for imbalanced learning (interoperability, lower procurement costs); (3) standardized curve-based evaluation practice; (4) incremental learning from imbalanced data streams, including autonomously handling mid-stream imbalance introduction, rebalancing during incremental learning, experience accumulation, and *imbalanced concept drifting*; (5) semi-supervised learning under imbalance (identifying whether unlabeled pools come from imbalanced distributions, label-recovery bias).

For practitioners building payment/fintech AI systems: this survey is the canonical menu for our fraud/RTO modeling stack — pick SMOTE-family generation when overlap matters (Borderline/ADASYN focus capacity on decision-boundary transactions), BalanceCascade/EasyEnsemble-style informed undersampling for large payment corpora, cost-sensitive boosting when business costs are quantifiable, and active margin sampling (LASVM-style) to spend analyst labeling budget where uncertainty concentrates. Its metric guidance mandates replacing accuracy dashboards with PR curves and cost curves for chargeback/RTO reporting, and its Section 5 agenda reads today as an MLOps roadmap: stream rebalancing policies, drift-aware incremental retraining, and semi-supervised exploitation of unlabeled transaction pools.

## Limitations

Acknowledged by authors:
- Focus on two-class problems; multiclass treated only briefly "for space considerations."
- No uniform benchmark platform existed; evaluations across papers are hard to compare (community-wide limitation documented).
- Cost matrices often unavailable or impossible to determine precisely, limiting cost-sensitive methods (explicitly discussed).
- Theoretical understanding limited: "only a very limited amount of theoretical understanding ... have been addressed"; five fundamental questions posed remain open in the paper.
- Semi-supervised and imbalanced-stream learning described as receiving "rather limited" attention.

Inferred by me:
- 2009 vintage: predates deep representation learning, focal loss, gradient-boosted tree defaults (class weighting in XGBoost/LightGBM), and modern imbalanced-learn tooling; neural-network discussion centers on MLP/backprop-era techniques.
- Survey synthesizes others' empirical results rather than running controlled comparisons; statements like NearMiss-2 being "competitive" inherit the original papers' dataset scopes (UCI-style benchmarks, none payment-industrial).
- No treatment of privacy/regulatory constraints on generating synthetic customer records (relevant when applying SMOTE-like methods to payment data).
- The ADASYN/Borderline-SMOTE descriptions rely on Euclidean distance in feature space, which is problematic for mixed categorical/numerical payment features without encoding choices (not discussed).

## Relevance to Our Hackathon

Razorpay-track relevance:
- **Fraud detection on imbalanced payment data**: the paper explicitly names fraud detection among its motivating domains (credit-card fraud citations). Directly reusable playbook: baseline RUS/ROS, then Borderline-SMOTE/ADASYN on transaction embeddings, then BalanceCascade/EasyEnsemble for scale, comparing against cost-sensitive boosted trees under PR-AUC and G-mean.
- **RTO risk prediction**: COD/e-commerce RTO labels mirror the paper's rare-positive framing; the within-class-imbalance insight suggests modeling distinct RTO sub-populations (address-quality-driven vs product-mismatch-driven) separately rather than treating RTO as one homogeneous minority concept — mitigating small disjuncts.
- **Cost-sensitive thresholds (block vs false-decline)**: the cost-matrix framework with C(Maj,Min) > C(Min,Maj) and MetaCost/threshold-moving recipes operationalize exactly the block-vs-false-decline economics; when costs can't be pinned down, Maloof's ROC dominant-point threshold selection applies.
- **Label budget efficiency**: margin-based active learning (LASVM) tells our fraud-review queue which transactions humans should adjudicate first — maximum model improvement per labeled case, directly cutting review ops cost.
- **Drift monitoring of production models**: Section 5.4's question list (mid-stream imbalance shifts, rebalancing during incremental learning, imbalanced concept drift) is effectively a requirements doc for our production monitoring: track per-window imbalance ratio and per-subgroup recall, trigger rebalancing/retraining when either shifts.
- **Evaluation discipline for demo credibility**: adopt the paper's standardization argument — report PR curves + cost curves (never raw accuracy), and use Hand-Till M or prevalence-weighted AUC if we demo multi-category risk (fraud types, RTO reasons).
