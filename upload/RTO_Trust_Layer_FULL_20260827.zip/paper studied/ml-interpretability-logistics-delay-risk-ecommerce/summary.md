# Machine Learning-Based Prediction and Interpretability Analysis of Logistics Delay Risks in E-commerce Supply Chains

| Field | Value |
|---|---|
| **Authors** | Ziyan Hu (School of Mathematics, University of Leeds, UK) |
| **Venue / Year** | 2025 2nd International Conference on Cloud Computing and Big Data (ICCBD 2025), November 14–16, 2025, Lijiang, China; ACM, pp. 234–241 |
| **Type** | conference paper |
| **DOI / URL** | https://doi.org/10.1145/3779475.3779510 (ACM ISBN 979-8-4007-2110-6/2025/11) |
| **Processed** | 2026-08-26T05:29:19Z |
| **Source PDFs** | 3779475.3779510.pdf (sha256 9525e6ec…) |

> Version 1 — generated from extracted PDF text.

## Abstract

> "This study focuses on predicting the logistics delay risk of multi-category products during the shipping process within e-commerce scenarios. The research constructs a comprehensive framework that includes traditional machine learning models such as Logistic Regression, Naive Bayes, Decision Tree, as well as ensemble strategies like Random Forest, eXtreme Gradient Boosting (XGBoost), Voting and Stacking, alongside a deep learning model—Multi-Layer Perceptron (MLP). Using the F2-score as the primary evaluation metric, the models are compared to reduce False Negative delay predictions. After Random Search optimization, the Random Forest model achieves the highest performance with an F2-score of 0.8704, demonstrating strong Precision-Recall balance and robust generalization. Feature interpretation through SHapley Additive exPlanations (SHAP) identifies 'Order status' and 'Shipping mode' as the most influential factors, while 'Order day of year' reveals seasonal variation in delay risks. This research establishes a multi-model comparison and logistics delay prediction system that thoroughly evaluates model interpretability and operational applicability. By bridging the gap between predictive performance and practical deployment, it provides valuable data-driven support for e-commerce platforms and logistics enterprises to enhance scheduling strategies and delay warning systems."

## Plain-Language Restatement

This paper predicts whether an e-commerce order will be delayed in shipping, using a large public supply-chain dataset. It compares eight kinds of models — from simple logistic regression to random forests, XGBoost, voting/stacking ensembles and a neural network — and deliberately optimizes the F2-score, which punishes missed delays more than false alarms because unnoticed delays are costlier for the business. A tuned Random Forest wins (F2 = 0.8704). SHAP explanations then show which inputs drive delay predictions: shipping mode and order status dominate, with transaction type and seasonality also contributing.

## Problem Statement

Delivery punctuality drives customer satisfaction, brand reputation, cost management, and market responsiveness, yet real logistics systems are hit by multifactorial delay causes (transportation distances, inventory practices, seasonal demand, regional traffic). Prior work either used interpretable-but-weak statistical methods (linear regression, time series) or single-model ML studies without systematic cross-algorithm comparison; moreover, opaque ML decision-making hinders enterprise deployment. The gap addressed: a thorough multi-model comparison (linear, nonlinear, ensemble, shallow deep learning) with an operationally motivated metric choice (F2 over F1) plus post-hoc interpretability (SHAP) so model outputs can support risk-warning systems.

## Methodology

- **Dataset**: DataCo Supply Chain Dataset (public, Mendeley Data, "DATACO SMART SUPPLY CHAIN FOR BIG DATA ANALYSIS"): 180,519 order records × 53 structured features; temporal coverage Jan 1, 2015 00:00:00 to Jan 31, 2018 24:00:00.
- **Target**: "Late delivery risk" binary variable (1 = late/delayed, 0 = not late).
- **Features** (Table 1): Shipping mode (Standard/First/Second/Same Day); Type of transaction (DEBIT, TRANSFER, CASH, PAYMENT); Order date/time; Order status (9 values: COMPLETE, PENDING, CLOSED, PENDING_PAYMENT, CANCELED, PROCESSING, SUSPECTED_FRAUD, ON_HOLD, PAYMENT_REVIEW); Customer city/country/segment (Consumer/Corporate/Home Office); Market (Africa, Europe, LATAM, Pacific Asia, USCA); Order region/country/city; Order item discount rate, product price, quantity, profit per order; Department name, Category name, Product name.
- **Engineered temporal features**: Order weekday (0–6), Order is weekend (binary), Order day of year (1–366), Order month (1–12), Order season (1–4).
- **High-cardinality category merging**: Order region 23→11 classes; Order country 163→11 (counts ranged 1–20,191); Order city 3,575→11 (counts 1–17,856); Department name: 11 original → 8 retained (Fan Shop, Apparel, Golf, Footwear, Outdoors, Fitness, Discs Shop, Technology) + Others = 9 final (max-min spread 54,077); Category name 50→11 (counts 54–19,961); Product name 118→top-10 + Others.
- **Preprocessing**: no missing values found; IQR-based outlier capping (values replaced by bounds, iterated until outliers negligible; outliers were ~1–10% per numeric variable); one-hot encoding with drop_first=True to avoid dummy trap; Z-score normalization of numeric features; VIF multicollinearity screening — 'Order month' VIF = 96.259 and 'Order day of year' VIF = 86.635 exceeded threshold 10, so 'Order month' was removed (all remaining VIF < 10).
- **Models (8)**: Logistic Regression; Naive Bayes; Decision Tree; Random Forest (bagging); XGBoost (boosting); Voting ensemble (equal weights and CV-F2-weighted configurations, all base models); Stacking (Logistic Regression meta-learner over all base models); Multi-Layer Perceptron (shallow).
- **Metric rationale & formulas**: Precision = TP/(TP+FP), Recall = TP/(TP+FN), F2 = 5·(Precision·Recall)/(4·Precision+Recall). FNs (unrecognized delays → complaints, contractual breach, reputation damage) cost more than FPs (extra review, manually rectifiable), hence Recall-weighted F2 as primary criterion.
- **Optimization/validation**: Random Search hyperparameter tuning (Bergstra & Bengio 2012) with three-fold cross-validation optimizing F2; final train/test split 70:30; 21 features total used (eight numerically processed + thirteen categorical one-hot encoded).

## Key Results

**Test-set performance after tuning (Table 2):**

| Model | F2-score | Precision | Recall |
|---|---|---|---|
| Logistic Regression | 0.618294 | 0.848870 | 0.578978 |
| Logistic Regression (Tuning) | 0.622694 | 0.829920 | 0.586107 |
| Naive Bayes | 0.721739 | 0.577046 | 0.770009 |
| Naive Bayes (Tuning) | 0.739694 | 0.573974 | 0.797240 |
| Decision Tree | 0.775612 | 0.780824 | 0.774319 |
| Decision Tree (Tuning) | 0.864420 | 0.560467 | 1.000000 |
| Random Forest | 0.739059 | 0.838913 | 0.717702 |
| **Random Forest (Tuning)** | **0.870418** | 0.574476 | 0.999088 |
| XGBoost | 0.636359 | 0.866306 | 0.596759 |
| XGBoost (Tuning) | 0.678725 | 0.833804 | 0.648568 |
| Voting (Equal, all) | 0.847663 | 0.649194 | 0.917810 |
| Voting (CV F2-weighted, all) | 0.847575 | 0.628087 | 0.928711 |
| Stacking (LR meta, all) | 0.798514 | 0.821131 | 0.793053 |
| MLP | 0.783394 | 0.791445 | 0.781407 |
| MLP (Tuning) | 0.801276 | 0.817317 | 0.797364 |

Key observations reported: tuned RF best (F2 = 0.8704) with near-perfect recall but modest precision (0.5745); tuned Decision Tree hits recall 1.0 with precision dropping to 0.5604 ("over-Recall"); XGBoost and MLP improved little from defaults; Stacking's linear LR meta-learner limited its edge; Voting/Stacking beat most singles but not RF. The author notes F2-based ranking diverges sharply from F1-based ranking (Stacking/MLP would look better under F1), so metric choice must follow business cost asymmetry.

**SHAP feature contributions for the tuned Random Forest (Table 3):**

| Rank | Mean \|SHAP\| feature | Score |
|---|---|---|
| 1 | Shipping mode_Standard Class | 0.101164 |
| 2 | Shipping mode_Second Class | 0.022585 |
| 3 | Order status_SUSPECTED_FRAUD | 0.014572 |
| 4 | Type_TRANSFER | 0.012669 |
| 5 | Order status_PROCESSING | 0.009344 |
| 6 | Order status_PENDING | 0.009144 |
| 7 | Shipping mode_Same Day | 0.008418 |
| 8 | Type_DEBIT | 0.004349 |
| 9 | Order day of year | 0.004151 |
| 10 | Order status_COMPLETE | 0.003929 |

Top positive-SHAP features (pushing toward predicted delay): Customer city_Glendale (0.000061), San Francisco (0.000048), Brooklyn (0.000047), Highland (0.000042), Fairfield (0.000040). Top negative-SHAP (mitigating delay): Shipping mode_Standard Class (−0.017571), Order status_SUSPECTED_FRAUD (−0.003442), Order profit per order (−0.002274), Order day of year (−0.002215), Order status_PENDING (−0.001785). Note (as printed in the text): Standard Class appears both as top mean-|SHAP| feature and top negative contributor — the table reports these columns exactly as published. Interpretation given: specific origin cities carry highest positive contributions (regional congestion, warehouse layout, order concentration); standardized shipping modes and timely status updates mitigate risk; insights consistent with the feature importance ranking derived from the Random Forest model.

## Figures & Tables

- **Table 1** (p.2, data table): variable dictionary — 16 variables in 5 groups (Logistics, Transaction feature, Order status, Geographical location, Pricing and profit, Product); target "Late delivery risk" 1=late/0=not late; 9 order-status values incl. SUSPECTED_FRAUD. Clean ACM vector table.
- **Table 2** (p.5, data table): 15-model × F2/Precision/Recall comparison; optimal bolded row Random Forest (Tuning) F2 0.870418 / P 0.574476 / R 0.999088; Decision Tree (Tuning) recall 1.000000 at precision 0.560467. All 45 cells verified digit-by-digit against page image.
- **Table 3** (p.6, data table): SHAP analysis — mean |SHAP| top-10 (Standard Class 0.101164 leads), top-10 positive (Customer city_Glendale 0.000061 leads), top-10 negative (Standard Class −0.017571 leads). All 30 pairs verified digit-by-digit. Notably Standard Class tops both mean |SHAP| and negative lists, as printed.
- The paper contains **zero figures**; the only visual content is these three native vector tables (no blur/watermarks/inconsistent fonts).

## Conclusions & Implications

Authors claim: tuned Random Forest is the preferred delay-risk model under an F2 objective; optimal-model selection is business-objective-dependent (missed-delay-sensitive vs FP-sensitive operations pick different winners); SHAP-derived drivers (shipping mode, order status, geography, seasonality) give actionable levers for scheduling and delay-warning systems. For practitioners building payment/fintech-adjacent commerce AI: this is a template for any "will this shipment/order go bad?" classifier — including RTO prediction — where missing a bad outcome is much more expensive than a false alarm; the paper justifies Fβ (β=2) metric selection from cost asymmetry, shows recall≈1.0 models come at severe precision cost that must be priced into intervention budgets, and demonstrates a production-friendly interpretability workflow (global mean-|SHAP| ranking + signed top-k lists) suitable for risk-model governance reviews.

## Limitations

*(Acknowledged by authors)*: static historical data lacking external dynamic factors (real-time transportation routes, weather, traffic); no personnel/behavioral features of delivery staff despite their known effect on service reliability; resource constraints precluded advanced AutoML hyperparameter search (suggests H2O future work). *(Inferred by me)*: the DataCo dataset's "Late delivery risk" label is derived from shipment schedules rather than realized customer returns, so it proxies logistics delay, not RTO/fraud outcomes; extreme class-of-metrics outcome (recall 0.999 with precision 0.57) may be unusable operationally without a cost curve analysis; high-cardinality merging thresholds (top-10/11 retention) are heuristic; no calibration analysis or threshold sweep is reported despite governance framing; single dataset, no external validation; some internal tension in the SHAP table (Standard Class simultaneously largest mean-|SHAP| and largest negative value) is not reconciled in the text.

## Relevance to Our Hackathon

Most directly relevant corpus paper for RTO-risk modeling mechanics: (1) adopt its F2-first evaluation stance for COD/RTO classifiers — missed RTOs (lost margin, reverse-logistics cost) outweigh false flags; report the F1-vs-F2 divergence to justify model choice to judges. (2) Its SHAP finding that *transaction/payment type* (Type_TRANSFER, Type_DEBIT) and *order status including SUSPECTED_FRAUD* rank among top predictors supports using payment-method signals (COD/prepaid/wallet, payment-status codes) as first-class RTO features — directly transferable to Razorpay order data. (3) The high-cardinality categorical handling recipe (merge cities/countries/products beyond top-N into "Others", one-hot with drop_first, VIF screen with cutoff 10) maps cleanly onto pincode/city/product-category encodings for address & delivery-risk scoring. (4) Seasonality signal via Order-day-of-year suggests adding festival-sale calendar features (Indian sale events) to RTO models. (5) The precision collapse at recall≈1.0 is a caution for intervention design: pair the classifier with the prescriptive budgeting idea from Kandula et al. (act only above precision break-even thresholds) when nudging customers to prepaid or flagging shipments.
