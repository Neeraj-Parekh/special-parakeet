# Research Requests — mlops-devops-integration-scalable-ai-deployments

- [High] Instrument every stage of our RTO-model GitHub Actions pipeline (clone, build, package, upload, deploy) and verify whether packaging/upload dominates as the paper's Kubeflow data suggests (10–21.57 s vs 2–4 s other stages); apply layer caching/artifact reuse and report percentage reduction.
- [High] Implement the full MLOps-DevOps loop for the fraud model: PR → train → register → canary → promote, plus an automatic retrain PR opened when a drift monitor fires; measure lead time from drift detection to deployed refreshed model.
- [Med] Optimize our model-validation test suite toward the paper's operating point: cut 18–35% of execution time while keeping fault-detection/risk-coverage loss ≤3%, then deliberately plant known bugs to confirm they are still caught.
- [Med] Reproduce the inner-platform correlation internally: compare deployment lead time and incident rate for teams (or branches) using the shared model-registry template versus ad-hoc notebook deploys during the hackathon sprint.
- [Med] Add a human-in-the-loop approval gate before promoting any model that changes score distributions beyond a threshold, testing the paper's collaboration-over-tools claim by logging how often analyst review blocks automation.
- [Low] Write infrastructure-as-code for the entire demo stack (endpoint, registry, monitors) so the environment is reproducible from scratch; time a cold rebuild as the reproducibility KPI.
- [Low] Benchmark against Michelangelo-scale numbers as a stress narrative: load-test our single RTO endpoint and extrapolate what architecture changes would be needed to approach 10M predictions/sec; document the gaps honestly.
- [Low] Survey which of the paper's cited challenge classes (data quality, standardization, trust/transparency/expectation management) appear in our own hackathon retro notes, producing a mini-replication of Baier et al.'s findings.
