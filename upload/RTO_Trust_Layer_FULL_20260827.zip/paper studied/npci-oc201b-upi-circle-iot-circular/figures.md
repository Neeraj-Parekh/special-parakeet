# Figures & Tables Log — npci-oc201b-upi-circle-iot-circular

Source key: `1b298dffaf71` (3-page scanned NPCI circular; text layer empty — all content read visually).

## Figures
**None.** The document is a letter-format operating circular with no charts, diagrams, or data figures. Non-content graphic elements observed (for completeness):

| ID | Page | Type | Construction inference | Content as shown | Takeaway | Quality observations | Supports |
|---|---|---|---|---|---|---|---|
| unnumbered-letterhead | 1–3 | logo/wordmark | raster scan of printed letterhead | NPCI logo (with Devanagari "भारतीय राष्ट्रीय भुगतान निगम / NATIONAL PAYMENTS CORPORATION OF INDIA") + "ALWAYS FORWARD" wordmark, top-right | authenticates issuer | slightly soft from scanning; colors intact | Document provenance (NPCI) |
| unnumbered-footer-logo | 1–3 | logo | raster scan | "Together We Build" with colored-cube motif, bottom-left | NPCI brand line | clean | n/a |
| unnumbered-decoration | 1–3 | decorative motif | vector in original, rasterized in scan | thin diagonal curved lines, top-left/bottom-right corners | n/a | n/a | n/a |
| unnumbered-address-block | 1 (only) | text block | scan | "1001A, The Capital, B Wing, 10th Floor, Bandra Kurla Complex, Bandra (E), Mumbai 400 051. T: +91 22 40009100 F: +91 22 40009101, contact@npci.org.in, www.npci.org.in, CIN: U74990MH2008NPL089067" | issuer registered address | legible | Document provenance |

## Tables
**None.** The circular contains no tabular data. All numeric limits are embedded in prose guideline items:
- Guideline 7 (p.1): max monthly limit **INR 15,000 per delegation**; max per-transaction **INR 5,000** for IoT device app/software.
- Guideline 8 (p.2): **24 hours** cooling period with cumulative transaction limit **INR 5,000/-**; auto-revoke if inactive **6 months** or on security concerns (device tampering etc.).
- Primary UPI Apps item 3 (p.2): user may authorize up to **5** IoT devices/software.
- Secondary item 6 (p.2): delegation accepted from only **one** Primary UPI App.
No tables.csv produced (no numeric tables exist to extract).

## Embedded images (img_*.png)
| File | Page | Content | Assessment |
|---|---|---|---|
| img_p001_2.png | 1 | same page-1 content as page_001.png but as a faint, very low-contrast scan layer (text barely visible; letterhead colors visible) | degraded duplicate layer |
| img_p001_4.png | 1 | same page-1 layout but dark, heavily degraded, unreadable text | degraded duplicate layer; unreadable |
| img_p002_7.png, img_p002_9.png | 2 | scan layers of page 2 (not separately read — same-layer pattern as p.1 confirmed by identical dimensions 1620×2305 and page render already legible) | degraded duplicate layers |
| img_p003_12.png, img_p003_14.png | 3 | scan layers of page 3 (same pattern) | degraded duplicate layers |

The composited `page_00*.png` renders are fully legible and were used as the primary transcription source. Scan quality overall: good contrast on renders, slight skew, no watermarks; no cropping issues.

## Summary.md cross-check
- All guideline numbers (1–8 general, 1–3 primary apps, 1–8 secondary, 1 issuer) transcribed and reflected in summary.md Methodology.
- Date (8th October 2025), ref (NPCI/UPI/OC-201B/2025-26), parent circular (NPCI/UPI/2024-25/201 dated 13th August 2024), signatory (Sourabh Tomar, Head UPI Product) verified against page 1 and page 3 renders.
