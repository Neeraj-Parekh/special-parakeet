# Research Requests — npci-oc201b-upi-circle-iot-circular

- [High] Build a synthetic OC-201B transaction generator (delegation id, device type, amount, explicit-action flag, BH purpose code) and implement the limit-validation engine (₹5,000/txn, ₹15,000/month, 24h ₹5,000 cooling, ≤5 devices); measure violation-detection recall on seeded abuse patterns like limit-splitting across hours.
- [High] Prototype an "agent asks, human approves" checkout flow that satisfies the explicit-user-action requirement: measure added latency and abandonment vs a plain OTP flow to quantify the UX cost of compliance for delegated IoT payments.
- [Med] Design an anomaly-detection feature set for BH-tagged UPI transactions (time-since-linking, amount-to-cap ratio, device-age, proximity-verification staleness, tamper-event history) and train an isolation forest to rank risky delegations in synthetic data.
- [Med] Model auto-revoke policy trade-offs: simulate 6-month-inactivity revocation vs 3-month variants; estimate false-revocation annoyance rate vs dormant-delegation takeover risk using simulated usage curves.
- [Med] Map the circular's consent chain (2FA at linking, mobile+OTP match, per-txn device validation) onto DPDP-style consent-artifact records; produce a schema a hackathon jury could verify end-to-end.
- [Med] Draft a compliance checklist diff between OC 201 (human secondary users) and OC 201-B (IoT/software delegates) to isolate what is *newly required* for non-human payers; validate against the Lexology secondary analysis in the sibling folder.
- [Low] Spec the proximity-at-linking control: compare BLE RSSI, NFC tap, and QR-scan pairing for evidence strength and spoofability; recommend one for a prototype.
- [Low] Analyze the "paid software profiles only" rule: survey which AI assistant subscription models qualify and what a PSP must verify (user profile id capture) to onboard an AI profile as secondary.
- [Low] Propose a liability matrix for failure modes the circular leaves open (issuer misses device validation, tamper signal ignored, explicit-action forged) and argue which party should bear each loss under RBI precedent.
