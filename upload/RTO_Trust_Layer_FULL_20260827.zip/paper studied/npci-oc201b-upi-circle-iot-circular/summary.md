# Addendum to NPCI/UPI/2024-25/OC 201 — Introduction of IoT Devices & Software on UPI Circle (NPCI/UPI/OC-201B/2025-26)

| Field | Value |
|---|---|
| **Authors** | National Payments Corporation of India (NPCI) — signed SD/- Sourabh Tomar, Head UPI Product |
| **Venue / Year** | NPCI operating circular addendum, 8 October 2025 (FY 2025-26) |
| **Type** | whitepaper (regulatory/operating circular — scanned, image-only PDF) |
| **DOI / URL** | (not stated in text; NPCI contact@npci.org.in, www.npci.org.in, CIN U74990MH2008NPL089067) |
| **Processed** | 2026-08-26T09:15:46Z |
| **Source PDFs** | UPI-_-OC-No_-201B-_-FY-2025-26-_-Addendum-to-NPCI_UPI_2024-25_OC-201–-Introduction-of-IoT-devices-&-software-on-UPI-Circle.pdf (sha256 141efff0…); text layer empty — content transcribed visually from page renders |

> Version 1 — generated from visual transcription of scanned page images (no extractable text).

## Abstract

*(No abstract — circular format. Opening text, verbatim:)* "With reference to UPI operating circular NPCI/UPI/2024-25/201 dated 13th August 2024, NPCI has introduced 'UPI Circle – Delegated Payments for secondary users'. Under this feature, any UPI user can authorize and delegate payments to a trusted secondary user for performing UPI transactions using any primary UPI App." / "UPI Circle is now extended to IoT (Internet of Things) devices & software profiles wherein a UPI user can link and delegate payments to their IoTs Devices & Software profiles like Smart glasses, watch, TV, AI Profiles (initially for limited users in CUG), etc. under the 'Full Delegation' framework as per defined monthly limits and security guidelines. It may be noted that debit transactions using IoT shall be only initiated by explicit user action."

## Plain-Language Restatement

India's UPI payments network lets a user delegate payment power to a trusted person ("UPI Circle"). This circular extends that delegation from people to things: smartwatches, smart glasses, TVs, and AI software profiles can now be linked and allowed to pay on the user's behalf, with strict caps (₹15,000/month, ₹5,000 per payment). Banks and apps must verify every device, get explicit user consent with two-factor authentication, and cut off dormant or tampered devices automatically.

## Problem Statement

The parent circular OC 201 (13 Aug 2024) created delegated payments for *human* secondary users. As consumer IoT and AI software agents proliferate, there was no sanctioned rails-level framework for non-human actors — devices and software profiles — to initiate UPI payments. Without one, device-initiated payments would be ad hoc, unverifiable, and fraud-prone. The addendum fills this gap by defining who may onboard, link, limit, and revoke IoT/software delegates, and what evidence (device/user IDs, proximity, consent, purpose codes) must flow through the rails. It matters because it is India's first formal regulatory accommodation of *agentic* payment actors on a major retail rail.

## Methodology

*(Not applicable — normative document, not research. Structure summarized instead.)*
- **Scope**: addendum to OC 201 under 'Full Delegation' framework; IoT device & software profiles (smart glasses, watch, TV, AI profiles — initially limited users in CUG (Closed User Group)).
- **Normative instruments**: 8 general guidelines for all members; 3 duties for Primary UPI Apps; 8 duties for Secondary Apps and PSP Banks (Certified on UPI Circle); 1 duty for Issuer Banks.
- **Controls specified**: RBI TAT/customer-compensation guidelines (20 Sep 2019) apply; ODR availability; new purpose code 'BH' in UPI raw file for these transactions/settlements; extra raw file with secondary details to Primary PSP, Secondary PSP, Issuer Bank; NPCI-permitted devices only; domestic P2M only; device proximity at linking; explicit user action for every IoT debit.
- **Numeric limits**: INR 15,000 max monthly per delegation; INR 5,000 max per transaction; 24-hour cooling period with cumulative INR 5,000; auto-revoke after 6 months of inactivity or on security concerns (e.g., device tampering); up to 5 IoT devices/software per user; delegation acceptable from only one Primary UPI App.
- **Consent & identity chain**: 2FA consent capture at linking by Primary App; mobile number + OTP validation by Secondary PSP; registered mobile must match primary user's; device/user ID captured at registration and validated on every payment request; paid-software profiles only (user profile id captured); Issuer Banks validate device id/user id + authorization details for every transaction before debit.

## Key Results

*(Non-research document — key normative claims instead of metrics.)*
- IoT/software delegates are legal on UPI under Full Delegation, but every debit must trace to explicit user action — no autonomous debit initiation.
- Hard spend caps: ₹15,000/month/delegation, ₹5,000/transaction; new delegations additionally capped at ₹5,000 cumulative in first 24 hours.
- Lifecycle safety: auto-revoke after 6 months inactivity or on tampering signals; user can manage limits/delink via Primary App; transaction history must be visible.
- Auditability: purpose code 'BH' tags these transactions in UPI raw files; a supplementary raw file with secondary details is distributed to Primary PSP, Secondary PSP, and Issuer Bank — the rails-level data trail for compliance and fraud analytics.
- Concentration/no-exclusivity rules: one delegation source (one Primary App) per IoT delegate; screen-less IoTs should support multiple secondary UPI Apps with no exclusive tie-ups.

## Conclusions & Implications

NPCI legitimizes device- and software-initiated UPI payments within a tightly fenced mandate: explicit-action triggers, low monetary ceilings, proximity + 2FA + OTP identity binding, per-transaction issuer-side device validation, and raw-file telemetry. For practitioners building payment/fintech AI systems: (1) India now has a *compliance template* for agentic payments — consent capture, delegation caps, revocation, and audit codes are the pattern to replicate for any agent-initiated payment product; (2) the 'BH' purpose code plus secondary-details raw file is a gift for fraud modeling — delegated-device transactions are separately identifiable, enabling purpose-built risk models; (3) PSPs must build device onboarding (due diligence, security evaluation, data-localization documentation) — a concrete RegTech workstream; (4) the explicit-action requirement means "agent asks, human approves" is currently the only sanctioned autonomy level on UPI.

## Limitations

*(Acknowledged by authors)*: feature initially restricted to limited users in a Closed User Group; opening to the complete user base will be communicated only "post the validations"; only domestic P2M transactions; only NPCI-permitted devices/software.
*(Inferred by me)*: scanned circular has no machine-readable text layer (hinders automated compliance pipelines — ironic for a RegTech source); monetary limits and device counts are fixed in prose without stated review cadence or indexation; "explicit user action" is not operationally defined (what counts as explicit on a screenless device?); no liability allocation if an Issuer fails per-transaction device validation; security-evaluation criteria for IoT apps are referenced but not specified in this document.

## Relevance to Our Hackathon

Directly on-theme for agentic payments on a Razorpay-style stack: (1) this circular *is* the regulatory boundary condition for any "AI agent pays" demo in India — design agent checkout flows as Full-Delegation UPI Circle links with ₹5,000/₹15,000 caps and explicit human confirmation, and the demo is compliant by construction; (2) the consent chain (display secondary details → 2FA consent → OTP mobile match → per-txn device/user-ID validation) is a blueprint for our consent-audit UX and DPDP-style consent logging; (3) the auto-revoke rules (6-month inactivity, tampering) map neatly to an agent-credential lifecycle service with revocation webhooks; (4) purpose code 'BH' + secondary-details raw file suggests a hackathon feature: anomaly detection over delegated-device transactions (new device, unusual hour, cap-adjacent amounts) — a fresh, low-competition fraud dataset seam; (5) proximity-at-linking hints at BLE/NFC-assisted pairing UX worth prototyping.

## Figures & Tables

- No figures or tables in the document (3-page letter-format circular). Letterhead elements only: NPCI logo + "Always Forward" wordmark (p.1–3), "Together We Build" logo with colored-cube motif (p.1–3), decorative diagonal line motifs, and the Mumbai BKC address block with CIN on p.1.
- Numeric limits appear in prose (guideline items 7–8, p.1–2); no numeric tables exist, so no tables.csv was produced.
- Embedded `img_*.png` files (2 per page, 1620×2305) are degraded scan layers of the same pages — one faint low-contrast copy and one dark, unreadable copy per page; the composited `page_*.png` renders are the legible primary source used for transcription.
