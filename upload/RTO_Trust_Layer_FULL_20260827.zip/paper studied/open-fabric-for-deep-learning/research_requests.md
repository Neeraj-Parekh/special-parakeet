# Research Requests — open-fabric-for-deep-learning

- [High] Compose a hackathon-scale mini-fabric for the RTO model: Kubernetes Job trainer + ART evasion test stage + AIF360 fairness stage + model packaging step, orchestrated as four independent containers; measure end-to-end build time versus a monolithic notebook pipeline.
- [High] Run the detect→mitigate→re-verify fairness loop on RTO labels segmented by merchant category and pin-code income proxy; report all five paper metrics (statistical parity difference, equal opportunity difference, average odds difference, disparate impact, Theil index) before and after a reweighing mitigation.
- [Med] Evaluate whether adversarial hardening degrades clean accuracy of the fraud/RTO classifier: attack with FGSM/PGD-style evasion at several epsilon levels, then apply one ART-class defense and tabulate clean-vs-robust accuracy trade-offs.
- [Med] Benchmark REST vs gRPC inference latency from inside and outside the cluster to validate the paper's internal-gRPC latency claim at Razorpay-like request rates (simulated load).
- [Med] Test portability claim: deploy the identical training manifest on two backends (minikube on-prem style vs managed cloud Kubernetes) and document every incompatibility encountered — operationalizing the paper's "open sourcing is hard" observation.
- [Low] Compare Horovod ring-allreduce against parameter-server distribution for a small tabular-DL RTO baseline (1–4 GPUs) and report scaling efficiency.
- [Low] Build a MAX-style annotated asset card for the shipped RTO model (classification tags, intended use, deployment config) and have another team member deploy it cold, timing time-to-first-prediction as the reuse metric.
- [Low] Assess whether 2018-era components (FfDL) still function today; if not, map each capability onto its modern equivalent (e.g., Kubeflow/KServe, current ART/AIF360 releases) and record gaps.
