# Open Fabric for Deep Learning Models

| Field | Value |
|---|---|
| **Authors** | Falk Pollok (IBM Research), Scott Boag (IBM Research), Maria-Irina Nicolae (IBM Research) |
| **Venue / Year** | NeurIPS (NIPS) 2018 Workshop, Montréal, Canada |
| **Type** | workshop paper |
| **DOI / URL** | GitHub refs in text: https://github.com/IBM/FfDL ; https://github.com/IBM/adversarial-robustness-toolbox ; https://github.com/IBM/AIF360 (no DOI stated in text) |
| **Processed** | 2026-08-26T05:29:23Z |
| **Source PDFs** | 23_open_fabric_for_deep_learning_.pdf + sha256 4d6828b0 |

> Version 1 — generated from extracted PDF text.

## Abstract
"We will show the advantages of using a fabric of open source AI services and libraries, which have been launched by the AI labs in IBM Research, to train, harden and de-bias deep learning models. The motivation is that model building should not be monolithic. Algorithms, operations and pipelines to build and refine models should be modularized and reused as needed. The componentry presented meets these requirements and shares a philosophy of being framework- and vendor-agnostic, as well as modular and extensible. We focus on multiple aspects of machine learning that we describe in the following. To train models in the cloud in a distributed, framework-agnostic way, we use the Fabric for Deep Learning (FfDL). Adversarial attacks against models are mitigated using the Adversarial Robustness Toolbox (ART). We detect and remove bias using AI Fairness 360 (AIF360). Additionally, we publish to the open source developer community using the Model Asset Exchange (MAX). Overall, we demonstrate operations on deep learning models, and a set of developer APIs, that will help open source developers create robust and fair models for their applications, and for open source sharing. We will also call for community collaboration on these projects of open services and libraries, to democratize the open AI ecosystem."

## Plain-Language Restatement
Instead of one giant all-in-one system for building AI models, IBM argues you should assemble models from small, interchangeable open-source parts. This paper introduces four such parts: one that trains deep-learning models on Kubernetes clouds (FfDL), one that protects models against adversarial attacks (ART), one that finds and removes unfair bias (AIF360), and one that lets developers share finished models like an app store (MAX). All pieces work regardless of which deep-learning framework you use.

## Problem Statement
Model building is typically monolithic — algorithms, operations and pipelines get entangled and can't be reused. Commercial deep-learning-as-a-service platforms (IBM Watson Machine Learning, AWS SageMaker, Azure ML, Google TFX, Uber Michelangelo, Facebook FBLearner) isolate infrastructure complexity but lock users into vendors; existing open-source alternatives were dominated by Kubeflow, with Microsoft Deep Learning Workspace also present. The gap addressed: an open, modular, framework- and vendor-agnostic fabric covering not just training but also security hardening, fairness, and community model sharing — deployable both on-premise and in public clouds, since some industries refuse to compute confidential models on public infrastructure.

## Methodology
Conceptual/architectural workshop paper describing a composed system of four open-source components plus integrations (demo-oriented; no benchmark evaluation reported):
- **FfDL ("fiddle")**: Kubernetes-based cloud platform for distributed deep-learning training. Microservices architecture chosen to reduce coupling between components, keep each component simple and stateless, isolate component failures, and let each component be developed, tested, deployed, scaled and upgraded independently. Resource-provisioning layer manages heterogeneous GPU/CPU pools. Training jobs defined via a **manifest** specifying framework, data access and requested resources. Public REST endpoint externally; internal gRPC to reduce latency. Storage: cloud object storage via S3 APIs for data, NFS for logs. Framework support: TensorFlow, PyTorch, Keras, Caffe2 and others, extensible. Distributed training via parameter servers or Uber's Horovod integration.
- **Adversarial Robustness Toolbox (ART)**: framework-agnostic Python library implementing state-of-the-art attacks, defenses/hardening methods and robustness-evaluation metrics for classifiers; modular interfaces allow composing methods as building blocks and extending to new approaches. Addresses evasion and poisoning attacks (citing Szegedy et al.; Biggio et al.).
- **AI Fairness 360 (AIF360)**: Python toolkit workflow — detect bias using fairness metrics (statistical parity difference, equal opportunity difference, average odds difference, disparate impact, Theil index), explain findings via natural-language explainers, mitigate bias in datasets/models, re-verify with the same metrics.
- **Model Asset Exchange (MAX)**: marketplace ("app store") to discover, share and rate models across frameworks, with standardized classification, annotation and deployment.
- **Ecosystem integrations**: Seldon for serving trained models; H2O platform integration bridging ML and DL.
No datasets, metrics tables, or statistical tests are reported (workshop talk outline).

## Key Results
Qualitative only — this is a demonstration/position paper; no quantitative results are given (not stated in text). Key claims:
- Modularization works: four independently usable components compose into a train → attack-test → harden → de-bias → publish lifecycle.
- Microservices + Kubernetes give scalability, resilience, fault tolerance, and independent component upgrades for a multi-tenant training service.
- The same fairness-metric set serves both detection and post-mitigation verification, closing the loop.
- Business motivations for fairness beyond ethics: matching strategic goals (e.g., selling to all income groups equally) and avoiding legal traps (e.g., age-based decisions constituting illegal age discrimination in the deployment country).
- Open-sourcing internal systems surfaced real challenges: moving code deeply integrated with internal infrastructure to code anyone can deploy on-premise or on public cloud involved several complications (multi-tenancy, fault tolerance, scalability, open sourcing itself).
- Positioning among peers: Kubeflow described as the most popular open-source effort, followed by FfDL and Microsoft DL Workspace.

## Conclusions & Implications
Authors claim a modular, vendor-neutral fabric of open AI services lets teams train, secure, de-bias and share models without monolithic lock-in, and invite community collaboration to democratize the AI ecosystem. For practitioners building payment/fintech AI: adopt composable tooling rather than a single vendor stack; treat robustness testing (adversarial attacks) and fairness auditing (with measurable disparity metrics) as first-class pipeline stages next to training; prefer architectures where each pipeline component can be scaled/upgraded independently; keep the option of on-premise deployment when transaction data cannot go to public clouds.

## Limitations
*(Acknowledged/inherent)*: it is a talk-outline workshop paper — no experiments, benchmarks, latency/cost numbers, dataset results, or user studies are included; robustness/fairness capabilities are asserted rather than evaluated here. *(Inferred)*: 2018-era snapshot — component names and maturity have evolved (ART/AIF360 now standalone LF-AI projects; FfDL largely dormant); composition overhead and interoperability bugs between the four components are not discussed; no guidance on sizing clusters or costs; security scope limited to adversarial ML, excluding classical application security.

## Relevance to Our Hackathon
- **Composable MLOps reference architecture**: mirrors our hackathon stack decision space — a Kubernetes-hosted trainer, an attack/robustness library, a fairness toolkit and a model registry/exchange map directly onto building the RTO risk service from open parts (e.g., ART-style evasion/poisoning tests before shipping the fraud model; fairness metrics on RTO outcomes across merchant categories/geographies).
- **Fairness metric vocabulary**: statistical parity difference, equal opportunity difference, average odds difference, disparate impact, Theil index give us concrete numbers to report for the DPDP/trust angle, with detect→explain→mitigate→re-verify loop reusable as a hackathon demo stage.
- **Vendor-agnosticism & on-prem option**: relevant to Razorpay-scale payment data governance — the paper legitimizes keeping model training on private infra while still using open components.
- **Architecture lessons**: stateless microservices, REST-outside/gRPC-inside, S3-object-storage data plane, manifest-driven jobs are directly transferable patterns for our inference service and retraining job design.
- **Sharing/reuse**: MAX-style packaging suggests exposing our RTO risk scoring as a well-annotated, deployable asset rather than ad-hoc scripts.

## Figures & Tables
**Zero figures, zero tables.** 5-page talk-outline with no charts, diagrams, screenshots or numeric tables — visually verified (`.cache/images/bbe9876efd9e/` empty; full-text contains only prose + 36 references). No `tables.csv` (nothing numeric to extract). See [figures.md](./figures.md).

---
*Verification: v2 full word-by-word source read completed 2026-08-26; header facts, verbatim abstract, methodology specifics (FfDL microservices/K8s/manifest/REST-gRPC/S3+NFS, ART evasion/poisoning, AIF360 5-metric loop, MAX app-store, Seldon/Horovod/H2O), related-work positioning (Kubeflow > FfDL > DLWorkspace) and zero-figure verdict confirmed; no factual corrections required.*
