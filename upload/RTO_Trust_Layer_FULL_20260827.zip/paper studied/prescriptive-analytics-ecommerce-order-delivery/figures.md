# Figures & Tables Deep Dive — prescriptive-analytics-ecommerce-order-delivery

Source: 1-s2.0-S0167923621000944-main.pdf (12 pages, 81270 chars, DSS 147:113584)
Images inspected: page_003.png .. page_010.png (8 rendered pages) + 6 embedded crops (img_p001_956, img_p001_959, img_p004_81, img_p006_126, img_p007_145, img_p010_181). All reads via vision. 14 visual objects logged.

---

## Fig 1 — Illustration of the proposed decision support framework — p.4

- **Page:** 4 (embedded crop img_p004_81.png is same figure, higher-res)
- **Type:** Flowchart / architecture diagram (system workflow)
- **Construction inference:** Vector diagram (PowerPoint/Visio style), black-and-white boxes + arrows; cylinder icons for data stores, grid icons for feature matrices, stacked-document icon for Delivery Schedules. Crisp vector lines, consistent sans-serif font. Not matplotlib. No raster blur.
- **Axes / legend / units / series:** No axes. Flow top→bottom & left→right. Left branch (training): Historical Order Delivery Data cylinder → grid Order Features → box Train Prediction Model (inside larger box Prediction Model) ; Location Data cylinder → Fetch Location Data box → grid Location Features → same Train box. Center box Prediction Model contains two sub-boxes Train Prediction Model (top) and Generate Predictions (bottom). Right branch (inference): Order Delivery Data cylinder → Order Features grid + Location path identical → Generate Predictions. Output chain: Order Success Profiles → Inferred Delivery Slots → Vehicle Routing Optimization → Delivery Schedules (stacked sheets icon). Arrows indicate data flow; two data sources (Historical vs Order Delivery) reuse same Location Data store.
- **Concrete numbers:** No numeric values; illustrates two-stage logic (Stage I prediction, Stage II optimization). Validates 9-h shift prescriptive flow described in §3.
- **Quality/editing:** Excellent vector quality, no watermark, no cropping, fonts uniform, lines sharp even at 1417×1331 crop. Looks native to document, not pasted screenshot.
- **Supports/contradicts summary:** Supports summary Methodology "Two-stage decision support framework" and Problem Statement gap. No contradiction.

## Table 1 — Comparison of data-driven decision frameworks — p.3

- **Page:** 3 (rendered page_003.png)
- **Type:** Data table (categorical + performance comparison)
- **Construction:** Typeset Elsevier vector table, header row Aspects, Approaches columns [12], [13], [14], [15], Our Approach. Sub-headers Prediction task vs Schedule generation task. Cell text 8-9pt serif.
- **Axes/legend/units/series:** Columns as above; rows: Dataset, Performance Metrics, Outputs Delivery Schedules (Yes/No), Time Required for schedule generation, Total number of customers in Simulation, Simulation Area. Units: Time Required includes "1 Minute for 15 customers (exponential)", "5 h for 100 Customers (exponential)", "18 min for 4015 and 10 min for 2136 customers (polynomial)"; Simulation Area sq. km (324, Not Specified, Not Applicable, 5, Hub A 36 & Hub B 156).
- **Concrete numbers:** Key takeaways: Prior methods exponential and small-scale (15/100/128 synthetic/real customers, 324/5 sq km), ours polynomial 18 min/10 min for 4015/2136 real-world locations, areas 36/156 sq km; only our approach reports Recall/Precision/AUC/G-mean/F1/Accuracy, others mostly Does not report.
- **Quality:** Crisp vector text, grid lines sharp, header shading subtle, no blur. Some header text "Prediction task" centered across columns. No artifact.
- **Supports summary:** Supports Key Results claim "polynomial complexity vs exponential-time prior methods (5 h for 100 customers)" and Problem Statement scalability gap. Values match summary Table 1 paraphrase exactly.

## Table 2 — List of predictor variables included from platform order delivery data — p.4

- **Page:** 4 (page_004.png lower)
- **Type:** Data table (feature definitions)
- **Construction:** Elsevier typeset, 3 columns Variable name, Type, Explanation
- **Content:** 9 rows: Category (Categorical, 14 high-level categories), Attempt_Time (Numeric, time of attempting delivery in minutes), Delay (Numeric, days delayed), Payment_Type (Categorical, 2 categories), Service_Tier (Categorical, 4 levels e.g. one-day), Weekday (Categorical, 7 days), Pretermission_1 (Numeric, Expected Delivery Date - Order Date days), Pretermission_2 (Numeric, Delivery Date - Order Date days), Value (Numeric, value of order)
- **Numbers:** 14 categories, 2 payment types, 4 service tiers, 7 weekdays
- **Quality:** Vector crisp, no issues
- **Supports:** Supports Methodology predictors bullet; summary Table 2 listing correct.

## Table 3 — Location Predictors — p.5

- **Page:** 5 (page_005.png bottom)
- **Type:** Data table (amenity definitions)
- **Construction:** Elsevier typeset, 4 columns Variable name / Explanation twice per row (12 amenities in 2-column layout)
- **Content:** Fuel: Fuel Stations; Coffee: Places where coffee/tea/drinks; Admin: named squares/road intersections/office buildings; Health: hospitals/healthcare; Restaurant: places where meals served; Shopping: shopping malls/furniture/apparel; Sights & Museums: tourist attractions/museums/monuments; Leisure: sports fields/parks/gardens/zoos; Transport: train/bus stations/bus stops/taxi stands; Out: pubs/clubs/cinema halls; Snacks: fast-food/street food; ATM: ATMs. Per amenity counts at 9 radii (100,200,300,400,500,750,1000,1500,2000 m) described in body text, 108 variables compressed via RAEs to 12 features.
- **Numbers:** 12 amenities ×9 radii =108 →12 compressed. Radii list validated.
- **Quality:** Vector, clean. Slight line spacing tightness but readable.
- **Supports:** Supports Methodology location predictors bullet.

## Fig 2 — Order success profiles (OSPs) — p.6 (also img_p006_126.png crop)

- **Page:** 6 top
- **Type:** Line chart — 3 side-by-side panels (tiled)
- **Construction:** Matplotlib-style vector (blue solid step/jagged line, orange dashed horizontal threshold, red dotted vertical line). Exported at ~1890×496, crisp. Not scanned.
- **Axes / legend / units / series exactly as shown:**
  - Each panel X: Time in Hrs, ticks 8,10,12,14,16,18 (hours). Y: P(Success) 0.0 to 1.0 ticks 0.0,0.2,0.4,0.6,0.8,1.0. No legend on chart but colors inferable from text: blue = predicted success probability vs time; orange dashed = threshold 0.5 (horizontal at y=0.5 across entire 8-18 range); red dotted vertical = time where probability drops below threshold.
  - Panel titles: AID_353 (left), AID_270 (center), AID_172 (right). No additional series.
- **Concrete takeaway numbers:**
  - AID_353: P(Success) ~0.7-0.8 at 08:00, stays ~0.55 until ~09:45 where vertical red at ~9.6h (9:50 per text), then drops sharply to ~0.4 then ~0.2-0.3 plateau after 11h, declining to ~0.15 at 18h. Threshold crossing exactly at red line.
  - AID_270: Starts 0.9 at 08:00, declines stepwise 0.85 at 10h, 0.75 at 12h, holds ~0.55 at 13.5h, crossing at ~13.7h (≈14:00 per text), then ~0.4-0.42 plateau to 18h with small dip at 18h to 0.2.
  - AID_172: Starts 0.92 at 08:00, stays 0.85-0.90 until 10h, drops to ~0.65 at 11h, 0.60-0.65 plateau 12-14h, 0.54 at 16h, crossing at ~17.7h (≈17:50 per text), then sharp drop to 0.30. Therefore visit order inferred: 353 →270→172 as text says.
  - Threshold orange at 0.50 exact. Probabilistic resolution suggests model predicted every few minutes (jagged).
- **Quality/editing observations:** High-resolution vector, no blur, no watermark, fonts consistent (Arial/Helvetica). Blue line slightly jagged due to discrete time predictions but not aliasing. Red vertical precisely aligned with crossover. Pasted-from-matplotlib look native, not screenshot.
- **Supports summary:** Directly supports Methodology OSP definition (threshold 0.5), priority sequencing, and Key Results qualitative insights bullet (AID_353 ≈9:50 h etc.). Values match summary's "≈9:50 h, ≈14:00 h, ≈17:50 h" within visual tolerance.

## Algorithm 1 — Procedure to generate schedules — p.6 bottom-right

- **Page:** 6
- **Type:** Pseudo-code / algorithm listing (not a figure but visual block)
- **Construction:** Monospace-style text block with horizontal rules, likely LaTeX algorithm environment, vector text.
- **Content:** N = list sorted priority descending; nested loops for order in N, for r in R, if same_region & capacity_exists, for (prev,next) in r, for slot in order.slot_options, if time_feasible(...) & costs<cost* then save prev*/next*/slot*/cost*/r*; after loops if slot* not set create new route with order.theta, Phidefault, add to R; insert_order.
- **Quality:** Crisp, no issues.
- **Supports:** Supports Methodology schedule generation bullet.

## Fig 3 — Spatial distribution of orders corresponding to Hub-A and Hub-B — p.7 (also img_p007_145.png crop)

- **Page:** 7 bottom
- **Type:** Scatter map (geographic point cloud) — two side-by-side panels
- **Construction:** Matplotlib scatter, vector-ish raster overlay but points rendered as semi-transparent dots, axes Longitude (x) vs Latitude (y), no tick numbers shown (relative coordinates). Export ~1890×1004, high resolution.
- **Axes / legend / units / series:**
  - X: Longitude (no numeric ticks visible in render — relative). Y: Latitude (same).
  - Points: blue dot = Successful Deliveries, orange dot = Failure Deliveries, magenta/purple square = Delivery Hub (central south for Hub-A, north-central for Hub-B). Legend bottom-left of each panel. Opacity shows density; overlap suggests clusters.
  - Panel titles: Hub-A (left), Hub-B (right).
- **Concrete takeaway numbers:** Visual not numeric but density: Hub-A service area ~36 sq km (per Table1) but plot shows more dispersed failures intermingled with successes, with voids (rivers/parks?) white holes. Hub-B shows stronger southern clustering (denser orange failures in southern tip), sparser north. Failures not uniformly random — some neighborhoods more prone. Approx counts: Hub-A test ~4015 points plotted, Hub-B ~2136.
- **Quality:** Points slightly translucent for overplotting, not blurry. Magenta hub square crisp. Some faint isolated outliers far from clusters (long tail). No watermark, no axis truncation beyond expected. Font for legend small but legible. Quality good for venue.
- **Supports summary:** Supports Methodology Data description (Hub areas 36 vs 156 sq km, failures unevenly distributed, some areas more prone) and Key Results distribution note. No contradiction.

## Table 4 — AUC scores of models trained on Hub-A's dataset — p.8 bottom

- **Page:** 8
- **Type:** Data table (performance matrix)
- **Construction:** Elsevier vector, columns RF, XGB, LB, ANN, CART, rows imbalanced methods SMOTE, SMOTE-Borderline, SMOTE+ENN, SMOTE+Tomek, ENN, RENN, Oversampling, Undersampling, Weighted Loss. Values percentages (AUC %). Bold highlights highest per row per caption but not needed.
- **Values (read exactly from page_008.png image):**
  - SMOTE: 72.42,71.51,70.78,69.54,70.00
  - SMOTE-Borderline:72.56,71.67,70.91,70.34,69.63
  - SMOTE+ENN:72.78,72.47,71.00,71.73,71.17
  - SMOTE+Tomek:72.50,72.40,70.79,70.36,70.03
  - ENN:73.36,73.47,71.09,72.93,71.80
  - RENN:73.16,73.63,71.02,72.43,71.35
  - Oversampling:73.36,73.61,70.93,73.36,71.15
  - Undersampling:72.65,72.85,71.18,72.79,71.22
  - Weighted Loss:73.20,73.65,64.83,72.06,71.56
  - Highest overall: XGB Weighted Loss 73.65 (matches text "Hub-A highest XGB AUC 73.65"). RF Weighted Loss 73.20 slightly below.
- **Quality:** Crisp, alignment clean, decimal points consistent. No blur. Header shading minimal.
- **Supports summary:** Supports Key Results AUC bullet (Hub-A highest XGB AUC 73.65 Weighted Loss). Also supports chosen model rationale (RF vs XGB not significantly different).

## Table 5 — AUC scores of models trained on Hub-B's dataset — p.9 top-left

- **Page:** 9
- **Type:** Data table (same structure as Table4 but Hub-B)
- **Construction:** Vector Elsevier, same columns.
- **Values (read from page_009.png):**
  - SMOTE:78.43,78.31,76.89,77.09,75.11
  - SMOTE-Borderline:77.7,78.76,76.98,77.17,75.24
  - SMOTE+ENN:78.57,78.28,76.63,77.32,75.4
  - SMOTE+Tomek:78.71,78.67,76.89,77.51,75.25
  - ENN:78.84,79.01,76.85,77.12,75.56
  - RENN:78.35,78.38,77.02,77.00,76.71
  - Oversampling:78.37,78.97,77.08,76.96,76.07
  - Undersampling:78.98,79.08,77.23,77.64,75.83
  - Weighted Loss:79.12,78.77,70.81,77.22,76.13
  - Highest overall: RF Weighted Loss 79.12 (matches summary "Hub-B highest RF AUC 79.12 Weighted Loss")
- **Quality:** Crisp; 78.77 for XGB weighted slightly below RF.
- **Supports:** Supports Key Results AUC bullet second part.

## Table 6 — G-mean scores of models tested on Hubs A & B — p.9 middle

- **Page:** 9 (wide table spanning full width)
- **Type:** Data table with secondary recall/precision sub-rows (complex)
- **Construction:** Elsevier wide table, header: Classifier, Metric, then columns SMOTE, SMOTE-Borderline, SMOTE+ENN, SMOTE+Tomek, ENN, RENN, O.S., U.S., Weighted Loss. Two sections Hub-A and Hub-B. Metric subrows G-mean, Recall, Precision per classifier RF/XGB.
- **Values (read precisely, page_009.png — critical for verification):**
  - *Hub-A RF:* G-mean 36.44,40.24,60.29,38.95,41.55,50.03,66.68,66.07,64.15 ; Recall 96.01,94.18,78.93,94.78,94.95,90.48,65.80,55.51,74.12 ; Precision 88.54,88.74,91.02,88.66,88.94,89.66,93.36,94.74,92.03
  - *Hub-A XGB:* G-mean 34.33,35.90,55.52,33.28,44.23,52.81,66.73,66.11,66.48 ; Recall 96.23,95.95,83.87,96.63,94.30,88.77,63.12,56.56,57.65 ; Precision 88.38,88.48,90.19,88.33,89.19,89.97,93.69,94.53,94.46
  - *Hub-B RF:* G-mean 58.15,61.94,70.16,62.1,60.13,68.54,70.35,71.02,68.79 ; Recall 92.01,88.62,65.77,90.04,91.66,80.59,71.03,68.63,78.17 ; Precision 89.26,89.93,93.73,90.00,89.64,91.70,93.05,93.67,91.88
  - *Hub-B XGB:* G-mean 51.47,50.05,69.14,48.98,62.64,68.9,69.49,71.37,73.83 ; Recall 95.14,95.36,78.82,95.85,89.47,80.22,77.60,69.61,69.69 ; Precision 88.29,88.08,91.97,87.96,90.11,91.83,92.15,93.68,94.87
  - Note bold per caption indicates highest G-mean per method per hub (e.g., Hub-A XGB weighted 66.48 not bold? Actually RF 66.68 higher, etc.)
- **Quality:** Very dense but vector crisp; column separators faint but legible; note row explains O.S.=Oversampling etc. No truncation. Requires zoom to read decimals but fully extractable.
- **Supports summary:** Supports Key Results G-mean highlights bullet; summary correctly cites Hub-A XGB Oversampling 66.73, weighted 66.48, undersampling 66.11 and Hub-B XGB weighted 73.83 etc. Note summary previously omitted SMOTE-family low G-means (e.g., 34.33) but mentions them as much worse — consistent.

## Table 7 — XGBoost confusion matrix evaluated on Hub-A's test data (in %) — p.9 right-middle

- **Page:** 9
- **Type:** Confusion matrix (2×2) data table with summary metrics
- **Construction:** Small Elsevier table 2×2 + footer line "Recall: 58%, Precision: 94%, Accuracy: 60%" and parameter note "*XGBoost Parameters..."
- **Axes/legend:** Rows Actual Values (Success, Failure), Columns Predicted Values (Success, Failure). Cells percentages that sum to 100%.
- **Values:**
  - Actual Success → Predicted Success 50.39%, Predicted Failure 37.00%
  - Actual Failure → Predicted Success 2.95%, Predicted Failure 9.66%
  - Footer: Recall 58%, Precision 94%, Accuracy 60%
  - Parameters: step size shrinkage 0.05, minimum loss reduction 0.1, maximum depth 7, subsample ratio 0.7, column sample ratio 0.675
  - Derived: failure rate in test 2.95+9.66=12.61%, detection 9.66% as stated in body text.
- **Quality:** Vector crisp, no blur, percentages aligned.
- **Supports summary:** Supports Key Results table Metric row Hub-A and text "detects 9.66 of 12.61% failures". Note recall/precision refer to SUCCESS class (see analysis in notes) not failure, but summary labeling "Recall (failure class)" is imprecise — flagged for correction.

## Table 8 — XGBoost confusion matrix evaluated on Hub-B's test data (in %) — p.9 right-bottom

- **Page:** 9
- **Type:** Confusion matrix
- **Construction:** Same layout as Table7
- **Values:**
  - Actual Success → Predicted Success 58.90%, Predicted Failure 25.61%
  - Actual Failure → Predicted Success 3.18%, Predicted Failure 12.31%
  - Footer: Recall 70%, Precision 95%, Accuracy 71%
  - Parameters: step shrinkage 0.05, min loss reduction 0.2, max depth 7, subsample 0.4, column sample 0.23
  - Derived: failure rate 15.49%, detection 12.31% (79.5% of failures detected if counting failure recall, but reported recall 70% is success recall).
- **Quality:** Crisp.
- **Supports summary:** Supports Key Results Hub-B recall/precision etc., same caveat about labeling.

## Fig 4 — Comparison of order attempts per day between baseline and data-driven policies of hubs A & B — p.10 (also img_p010_181.png crop)

- **Page:** 10 top
- **Type:** Grouped vertical bar chart — two panels (Hub-A left, Hub-B right)
- **Construction:** Matplotlib-style vector (solid fill bars, no gradient), 3 bars per day grouped. Colors: light green (#7FBF7F) New Deliveries, orange (#FF7F0E) Baseline policy, dark blue (#1F77B4) Data-driven policy. Y-axis Attempts 0-1000, ticks 0,200,400,600,800,1000. X-axis Day 1-7 integer. Export 1890×1001, crisp.
- **Legend:** Upper-right inside each panel: New Deliveries, Baseline policy, Data-driven policy.
- **Concrete numbers (estimated from bar heights; exact values not labeled numerically, but relative differences support Table9):**
  - Hub-A: Day1 all ~530 equal; Day2 New ~755, Baseline ~825, Data-driven ~790; Day3 New ~515, Baseline ~615, Data ~515; Day4 New ~635, Baseline ~715, Data ~655; Day5 New ~555, Baseline ~640, Data ~570; Day6 New ~475, Baseline ~560, Data ~505; Day7 New ~560, Baseline ~630, Data ~590. Pattern: Baseline consistently highest after Day1, Data-driven intermediate, New lowest.
  - Hub-B: Day1 ~320 equal; Day2 New ~380, Baseline ~425, Data ~385; Day3 New ~350, Baseline ~415, Data ~360; Day4 New ~420, Baseline ~485, Data ~435; Day5 New ~480, Baseline ~555, Data ~500; Day6 New ~185, Baseline ~270, Data ~220; Day7 New ~15, Baseline ~60, Data ~55. Similar pattern but scale smaller. Days 6-7 low new deliveries (end of week).
  - Interpretation: Data-driven reduces attempts close to New Deliveries, indicating fewer reattempts.
- **Quality:** Crisp vector bars, no blur, no watermark, no inconsistent fonts, axes labels clear. Day 7 Hub-B new deliveries bar very short but still visible (~15). Good production quality.
- **Supports summary:** Visual reinforcement of Table9 and text paragraph Lines 1003-1017 describing Fig4; supports Key Results simulation narrative (data-driven results in fewer deliveries). Consistent with summary description.

## Table 9 — Performance of baseline policy and data-driven policy of hubs A & B — p.10 middle

- **Page:** 10
- **Type:** Data table (simulation performance)
- **Construction:** Elsevier vector, columns: Policy, Hub, Total orders, Total attempts, Total vehicles, Total distance (km)^a, Total costs (INR)^a, Std Dev (Total costs)^a, Savings (%)^a. Two rows per hub (Baseline, Data-driven). Captions footnote a explains averages across 100 runs.
- **Values exactly as rendered (page_010.png):**
  - Baseline A: 4015 orders, 4503 attempts, 112 vehicles, 1052.23 km, 73,737 INR, Std 24.05, Savings –
  - Data-driven A: 4015, 4142, 103, 1178.55, 68,381, 19.14, 7.2
  - Baseline B: 2136, 2518, 64, 1315.28, 44,063, 40.74, –
  - Data-driven B: 2136, 2270, 57, 1280.67, 39,538, 48.03, 10.2
- **Quality:** Crisp, numbers aligned, savings column right-aligned, footnote legible. No truncation.
- **Supports summary:** Core Key Results simulation table; summary Table 9 reproduces exactly; validates savings 7.2%/10.2% and note that distance increases for Hub-A under data-driven (1178.55 vs 1052.23) while Hub-B decreases.

## Unnumbered publisher logos — p.1

- **Files:** img_p001_956.png (Decision Support Systems header with rope graphic) and img_p001_959.png (Elsevier tree logo)
- **Type:** Journal branding photo/graphics (not data)
- **Construction:** Raster illustrations (rope/twig), not data figures. Not counted in figures but noted for completeness.
- **Quality:** Slight raster but acceptable.

---

## Quality / Venue Assessment Summary

All data figures/tables are vector typeset, high-resolution, consistent Elsevier style, no blurry screenshots, no pasted-from-another-doc appearance. Matplotlib charts exported cleanly with vector edges. Table gridlines and fonts uniform. No watermarks, no cropped axes, no missing labels. Figure captions and in-text references fully match visuals. Distribution maps (Fig3) use semi-transparent overplotting appropriately. No evidence of image manipulation or low-res upscaling. Overall production quality high for Decision Support Systems.

## Link to summary.md claims

- Every methodology predictor number verified against Table2/3.
- AUC/G-mean numbers verified against Table4/5/6.
- Confusion percentages and parameters verified against Table7/8.
- Savings/attempts/vehicles/distance verified against Table9 & Fig4.
- OSP threshold and sequence verified against Fig2.
- Direction clustering heuristic verified against Algorithm1 & Fig1.

Total figures/tables logged: 14 visual objects (4 figures + 1 algorithm + 9 tables) on 8 pages. Numeric tables extracted to tables.csv: 6 (Tables 4,5,6,7,8,9).

