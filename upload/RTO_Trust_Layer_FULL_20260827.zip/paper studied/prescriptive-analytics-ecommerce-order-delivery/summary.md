# A prescriptive analytics framework for efficient E-commerce order delivery

| Field | Value |
|---|---|
| **Authors** | Shanthan Kandula, Srikumar Krishnamoorthy, Debjit Roy (Indian Institute of Management Ahmedabad; Roy also Rotterdam School of Management, Erasmus University) |
| **Venue / Year** | Decision Support Systems, Vol. 147, Article 113584, 2021 |
| **Type** | journal article |
| **DOI / URL** | https://doi.org/10.1016/j.dss.2021.113584 |
| **Processed** | 2026-08-26T05:29:19Z |
| **Source PDFs** | 1-s2.0-S0167923621000944-main.pdf (sha256 03dd1bd3…) |

> Version 2.0.0 — v2 full-read verification pass (word-by-word + figure deep-dive). Source sequentially read in 1200-line chunks; notes at .cache/notes/prescriptive-analytics-ecommerce-order-delivery.md; figures logged in figures.md; tables in tables.csv.

## Abstract

> "Achieving timely last-mile order delivery is often the most challenging part of an e-commerce order fulfillment. Effective management of last-mile operations can result in significant cost savings and lead to increased customer satisfaction. Currently, due to the lack of customer availability information, the schedules followed by delivery agents are optimized for the shortest tour distance. Therefore, orders are not delivered in customer-preferred time periods resulting in missed deliveries. Missed deliveries are undesirable since they incur additional costs. In this paper, we propose a decision support framework that is intended to improve delivery success rates while reducing delivery costs. Our framework generates delivery schedules by predicting the appropriate delivery time periods for order delivery. In particular, the proposed framework works in two stages. In the first stage, order delivery success for every order throughout the delivery shift is predicted using machine learning models. The predictions are used as an input for the optimization scheme, which generates delivery schedules in the second stage. The proposed framework is evaluated on two real-world datasets collected from a large e-commerce platform. The results indicate the effectiveness of the decision support framework in enabling savings of up to 10.2% in delivery costs when compared to the current industry practice."

## Plain-Language Restatement

When e-commerce couriers deliver to homes, customers are often not there, so the delivery "fails" and must be reattempted, costing money. This paper builds a two-step system: first a machine-learning model predicts, for every order, the probability that a delivery attempt at any given time of day will succeed (an "order success profile"); second, these profiles are turned into inferred time windows that feed a vehicle-routing optimization to produce delivery schedules. Tested on real data from two Indian delivery hubs of a large e-commerce platform, simulation shows the approach cuts total delivery costs by 7.2%–10.2% versus the industry practice of routing purely for shortest distance.

## Problem Statement

Failed last-mile deliveries (mainly customer absence) incur extra package-handling, fuel, and emissions costs, and successful deliveries increase satisfaction and decrease product returns. Prior data-driven solutions have two drawbacks the authors address: (1) they rely on sensitive customer-specific data (half-hourly electricity consumption, GPS traces, smart-home device data) that is rarely available, raises privacy/legal issues (only ~21% of customers share GPS location; 63% find smart-home devices "creepy"; global smart-meter penetration was only 14% as of Nov 2019), and (2) their schedule-generation formulations take exponential time (e.g., 5 hours for 100 customers), which does not scale to hubs delivering hundreds/thousands of orders per day. The gap: predict delivery success using readily available, less-sensitive data (historical order delivery data + aggregated area-level location data), then generate feasible schedules in polynomial time.

## Methodology

- **Two-stage decision support framework**: Stage I predicts binary delivery success (success=1/failure=0) per order per time point across the delivery shift; Stage II infers delivery time windows from "order success profiles" (OSPs) and solves a Vehicle Routing Problem with Time Windows (VRPTW).
- **Predictors from platform order-delivery data** (Table 2): Category (14 high-level categories), Attempt_Time (minutes), Delay (days delayed), Payment_Type (2 categories), Service_Tier (4 levels, e.g., one-day delivery), Weekday (7 days), Pretermission_1 (Expected Delivery Date − Order Date, days), Pretermission_2 (Delivery Date − Order Date, days), Value (order value). Attempt_Time is the key variable swept to build OSPs while all other features are held constant.
- **Location predictors** (Table 3): counts of 12 amenities (restaurants, coffee shops, fast food, cinema/out-of-home leisure, sights & museums, hotels→"Admin" named squares/intersections/office buildings, hospitals/health, fuel stations, parks/leisure, shopping, ATMs, transport stations) computed at radii 100–2000 m (9 radii) = 108 variables, compressed per amenity into one feature via robust autoencoders (RAEs) → 12 location features. Data sourced from Here Technologies' location platform.
- **Models** (Scikit-learn, XGBoost, TensorFlow): Random Forests, Gradient Tree Boosting (XGBoost), LogitBoost, Artificial Neural Networks (ReLU), CART Decision Trees (baseline).
- **Imbalanced learning**: target skewed toward successes (~11% failures Hub-A overall; ~17.9% Hub-B). Methods compared: weighted loss (cost-sensitive, weights inversely proportional to class frequencies), random oversampling, random undersampling, SMOTE, Borderline SMOTE, ENN, RENN, SMOTE+ENN, SMOTE+Tomek.
- **Metrics**: AUC and G-mean as primary (imbalanced-appropriate); recall, precision, accuracy, F1, confusion matrices reported.
- **Statistical tests**: Friedman omnibus test + Nemenyi post hoc tests at significance level 0.01 (per Japkowicz & Shah). Hyperparameters tuned by grid search with hold-out validation (last training week as validation), maximizing AUC; RF trees fixed at 3000; XGBoost tuned on step size shrinkage, min loss reduction, max depth, subsample ratio, column sample ratio.
- **Order success profiles & scheduling**: slots = time intervals where predicted success probability ≥ threshold 0.5; priority(p) = 1 − (minutes available / size of delivery period), shift typically 540 min (9 h); insertion heuristic (adapted from Campbell & Savelsbergh) with direction-clustered routes (R directions around hub with span Φ), improved by iterated local search with 2-opt* exchanges.
- **Simulation setup**: baseline policy = current practice (shortest-tour VRP, no time constraints, full-shift slot (420, 960)); test-week failure rates replayed randomly (x = 12.61% Hub-A, 15.5% Hub-B); data-driven policy narrows slot width by model precision (e.g., precision 94% ⇒ remove ~3.6 min of false-positive minutes from a 60-min slot) and treats slots <30 min as failures assigned to the full slot. Haversine distance ×1.5 rescaling; average speeds 16 kmph (Hub-A) / 20 kmph (Hub-B); vehicle capacity 50 orders; 6 initial directions θ={0,…,300}°, span 45°; vehicle daily cost 633 INR; fuel 2.7 INR/km; shift 420–960 min (7 AM–4 PM); 100 simulation runs per hub.
- **Data**: order delivery data from one of India's leading e-commerce platforms (Flipkart acknowledged in acknowledgments). Hub-A (major city, 36 sq km service area): 11 weeks of data, ~6% records removed for NULLs, 81,967 train deliveries (first 10 weeks) / 4015 test deliveries (last week). Hub-B (town, 156 sq km, 2000 km away): 13 weeks, ~9% removed; trained on whole-town first-12-weeks data (84,714 records), tested on hub's last week (2136 records).

## Key Results

**AUC (%) — selected best cells.** Hub-A: highest XGB AUC 73.65 (Weighted Loss); Hub-B: highest RF AUC 79.12 (Weighted Loss). Differences between classifiers significant except RF vs XGBoost pair.

**Chosen model: XGBoost + weighted loss** — chosen for computational efficiency: prediction 4.4 ms vs Random Forest 2.58 s on test data; model size 0.59 MB vs RF's 712.42 MB.

| Metric (success class, as reported) | Hub-A (XGBoost+weighted loss) | Hub-B (XGBoost+weighted loss) |
|---|---|---|
| Recall (success class) | 58% (57.65% in Table 6) — failure detection is 9.66 of 12.61% of test cases (76.6% of failures) | 70% (69.69% in Table 6) — failure detection is 12.31 of 15.49% (79.5% of failures) |
| Precision (success class) | 94% (94.46% in Table 6) | 95% (94.87% in Table 6) |
| Accuracy | 60% (60.05% = 50.39+9.66) | 71% (71.21% = 58.90+12.31) |
| F1-score | 72% | 80% |

XGBoost parameters: Hub-A (shrinkage 0.05, min loss reduction 0.1, max depth 7, subsample 0.7, column sample 0.675); Hub-B (shrinkage 0.05, min loss reduction 0.2, max depth 7, subsample 0.4, column sample 0.23).

Comparison vs prior art: Praet & Martens model had recall 75%, precision 41%, F1 53%; this paper's models: Hub-A 58%/94%/72%, Hub-B 70%/95%/80%.

G-mean highlights (Table 6): Hub-A XGB oversampling G-mean 66.73, weighted loss 66.48, undersampling 66.11 (SMOTE-family much worse, e.g., 34.33); Hub-B XGB weighted loss G-mean 73.83 (best), undersampling 71.37.

**Simulation results (averages over 100 runs, Table 9):**

| Policy | Hub | Orders | Attempts | Vehicles | Distance (km) | Total costs (INR) | Std Dev | Savings |
|---|---|---|---|---|---|---|---|---|
| Baseline | A | 4015 | 4503 | 112 | 1052.23 | 73,737 | 24.05 | – |
| Data-driven | A | 4015 | 4142 | 103 | 1178.55 | 68,381 | 19.14 | **7.2%** |
| Baseline | B | 2136 | 2518 | 64 | 1315.28 | 44,063 | 40.74 | – |
| Data-driven | B | 2136 | 2270 | 57 | 1280.67 | 39,538 | 48.03 | **10.2%** |

Schedule generation took 18 min (Hub-A, 4015 customers) and 10 min (Hub-B, 2136 customers) — polynomial complexity vs exponential-time prior methods (5 h for 100 customers in Florio et al.). Distance can increase under the data-driven policy (Hub-A: 1178.55 vs 1052.23 km) because of time-window constraints, but vehicle/labor cost savings dominate fuel cost. Savings were larger for Hub-B where failure rates were higher; authors note failure rates of 25% are common in the literature, implying larger headroom.

Qualitative insights: OSP examples show success probability dropping below 0.5 at different times (AID_353 ≈9:50 h, AID_270 ≈14:00 h, AID_172 ≈17:50 h), dictating visit sequence; city-level models transfer to individual hubs (train on whole town, deploy per hub).

## Figures & Tables

- **Table 1 (p3, data table):** Comparison of 4 prior data-driven delivery frameworks vs ours — highlights exponential prior (5 h for 100 cust, 1 min for 15 cust) vs ours polynomial (18 min/4015, 10 min/2136; real-world 36/156 sq km).
- **Fig 1 (p4, flowchart/architecture):** Two-stage framework diagram — Historical Order + Location Data → Train Prediction Model → Generate OSPs → Inferred Slots → VRPTW → Delivery Schedules.
- **Table 2 (p4, data table):** 9 order-level predictors from platform data (Category 14 cats, Attempt_Time minutes, Delay days, Payment_Type 2 cats, Service_Tier 4 levels, Weekday 7, Pretermission1/2 days, Value).
- **Table 3 (p5, data table):** 12 location-amenity types (Fuel, Coffee, Admin, Health, Restaurant, Shopping, Sights&Museums, Leisure, Transport, Out, Snacks, ATM) counted at 9 radii =108 → compressed to 12 via RAEs; source Here Technologies.
- **Fig 2 (p6, 3 line charts):** OSPs for AID_353/270/172 — P(Success) vs Time 08–18 h, orange threshold 0.5, red crossover at ~09:50, ~14:00, ~17:50 — defines visit order 353→270→172.
- **Algorithm 1 (p6, pseudocode):** Priority-sorted insertion heuristic with direction clustering (θ, Φ) and 2-opt* iterated local search; checks same_region, capacity, time_feasibility.
- **Fig 3 (p7, 2 scatter maps):** Spatial distribution Hub-A vs Hub-B — blue success vs orange failure vs magenta hub; shows failures unevenly clustered (shopping dense near B, parks near A), supports location signal.
- **Table 4 (p8, AUC matrix):** Hub-A AUC% (9 methods ×5 models) — best is XGB Weighted Loss 73.65 (RF 73.20 close); confirms RF≈XGB top tier.
- **Table 5 (p9, AUC matrix):** Hub-B AUC% — best is RF Weighted Loss 79.12 (XGB 78.77); again RF/XGB dominate.
- **Table 6 (p9, G-mean/Recall/Precision matrix):** G-mean for RF/XGB across 9 methods per hub — Hub-A XGB Oversampling 66.73, Weighted 66.48, Undersampling 66.11 vs SMOTE 34.33; Hub-B XGB Weighted 73.83 best, undersampling 71.37; exposes SMOTE-family weakness.
- **Table 7 (p9, confusion 2×2 %):** Hub-A XGB Weighted — Success→Success 50.39, Success→Failure 37.00, Failure→Success 2.95, Failure→Failure 9.66; Recall 58% (success), Precision 94.46% (success), Acc 60%; params 0.05/0.1/7/0.7/0.675.
- **Table 8 (p9, confusion 2×2 %):** Hub-B XGB Weighted — Success→Success 58.90, Success→Failure 25.61, Failure→Success 3.18, Failure→Failure 12.31; Recall 70% (success), Precision 94.87%, Acc 71%; params 0.05/0.2/7/0.4/0.23.
- **Fig 4 (p10, 2 grouped bar charts):** Attempts per day Day1–7 for New vs Baseline (orange) vs Data-driven (blue) — Baseline persistently highest after Day1 (e.g., Hub-A Day2 825 vs 790 data-driven vs 755 new), Data-driven tracks New closely, visualizes reattempt reduction.
- **Table 9 (p10, simulation performance):** 100-run averages — Baseline A 4503 attempts/112 veh/1052.23 km/73,737 INR vs Data-driven 4142/103/1178.55/68,381 saving 7.2%; Baseline B 2518/64/1315.28/44,063 vs 2270/57/1280.67/39,538 saving 10.2%.

Full visual log and numeric extract: `figures.md` + `tables.csv`; all visuals vector, high quality, no blur/watermark/cropped axes.

## Conclusions & Implications

Authors claim: delivery success is predictable from non-sensitive, widely available order + aggregated location features; XGBoost under a cost-sensitive scheme gives the best accuracy/compute trade-off; embedding predictions in VRPTW scheduling yields 7.2–10.2% delivery-cost savings without increasing fleet size; platforms should build one city-level model rather than per-hub models, reducing train/test/integrate/deploy/maintain effort. For practitioners building payment/fintech-adjacent commerce AI: (1) the exact template transfers to RTO risk scoring — replace "delivery failure" with "return-to-origin," keep payment type (COD vs prepaid), delivery speed tier, delay, order value, and address-level geographic features as predictors; (2) prescriptive use of probabilities (time-slot inference, priority ordering, precision-adjusted slot shrinking) is a blueprint for converting a risk score into operational interventions (e.g., nudge COD orders to prepaid when RTO risk is high, or route high-risk shipments differently); (3) imbalanced-learning practice (weighted loss competitive with resampling, G-mean/AUC evaluation, Friedman+Nemenyi testing) is directly reusable; (4) deployment economics matter — a 0.59 MB model with millisecond inference beat a 712 MB forest, a strong argument for lightweight models in production risk APIs.

## Limitations

*(Acknowledged by authors)*: heuristic scheduling may reduce solution quality vs exact methods; workload imbalance across delivery agents possible; savings depend on traffic/service-area size (though lowest observed speeds were used, so estimates are conservative); only ~3 months of data used — more data might improve generalization; extended insertion heuristic only — other heuristics unexplored. *(Inferred by me)*: single-country, single-platform data (India, one large platform) limits external validity; failure labels reflect attended home delivery attempts, not returns/RTO behavior, so transfer to RTO needs new label definitions; no interpretability analysis of feature contributions is reported; the simulation assumes recorded failures occur randomly at observed rates and that delivering inside an inferred slot guarantees success; amenity-count features require a third-party location provider (Here) whose coverage/cost may vary; payment-type has only 2 categories in text — COD-specific dynamics (customer refusal at door) are not modeled separately.

## Relevance to Our Hackathon

This is the closest architectural blueprint in the corpus for Razorpay-track RTO risk work: a binary "bad outcome" classifier over order attributes (payment type, service tier, value, delay, category, weekday, promised-vs-actual dates) fused at feature level with address/location intelligence (amenity counts compressed by autoencoders — analogous to address-quality/geocoding signals in Indian COD flows). Concrete transfers: (a) build an XGBoost + class-weighted RTO model on synthetic COD shipment data and evaluate with AUC/G-mean plus Friedman-Nemenyi comparisons against SMOTE variants, mirroring the paper's protocol; (b) convert RTO probabilities into *prescriptive interventions* — the paper's OSP→slot-inference analog is score→action mapping (prepaid-conversion nudge, partial-COD offer, delivery-slot confirmation call before first attempt); (c) adopt its precision-based slot-width adjustment idea as "intervention budgeting": act only when the model's precision at the chosen threshold justifies the intervention cost; (d) reuse its finding that a city-level model serves individual hubs to argue for one national RTO model with hub-level features rather than per-pincode models; (e) cite its privacy motivation — deliberately avoiding sensitive customer data (GPS, smart-home) in favor of transactional + aggregated area features — as precedent for DPDP-friendly feature design in India.
