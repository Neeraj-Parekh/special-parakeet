# From Recommendations to Delegation: A Systematic Review Mapping Agentic AI in E-Commerce and Its Consumer Effects

| Field | Value |
|---|---|
| **Authors** | Stefanos Balaskas (eGovernment & eCommerce Lab, Innovation & Entrepreneurship, Dept. of Business Administration, University of Patras, Greece) |
| **Venue / Year** | Information 2026, 17(3), 222 (MDPI); Received 4 Jan 2026, Accepted 24 Feb 2026, Published 25 Feb 2026 |
| **Type** | systematic review (evidence-mapping review) |
| **DOI / URL** | https://doi.org/10.3390/info17030222 |
| **Processed** | 2026-08-26T05:29:19Z |
| **Source PDFs** | information-17-00222-with-cover.pdf (sha256 prefix `4cea7277`, published, primary); From_Recommendations_to_Delegation_A_Systematic_Re.pdf (sha256 prefix `f9658222`, accepted manuscript) |

> Version 1 — generated from extracted PDF text (published version primary).

## Abstract

> "Agentic AI is increasingly framed as enabling consumers to delegate commerce decisions and actions to digital assistants, yet consumer-facing evidence still centers on assistive chatbots and recommender-like systems, with scarce evaluation of execution-level delegation. This study provides an evidence-mapping review of empirical work on agentic commerce and synthesizes determinants and outcomes of delegation across three questions: (RQ1) how systems are operationalized (autonomy, task scope, interaction mode, and transaction capability/evidence realism), (RQ2) what facilitates or inhibits delegation, and (RQ3) what downstream outcomes follow for marketing performance and consumer experience. We searched Scopus and Web of Science for English-language, peer-reviewed primary studies (2015–2026) and applied conservative coding rules that distinguish claimed capability from simulated or demonstrated execution. The mapped literature is concentrated in text-based, low-autonomy assistants focused on recommendation and post-purchase support; coverage drops sharply for workflow-level autonomy, cart building, checkout/payment execution, and negotiation. Across studies, findings cluster into two motifs: a utility/assurance pathway in which performance cues and interaction quality increase perceived usefulness, satisfaction, and trust, and a governance pathway in which autonomy cues and system-initiated control trigger reactance/powerlessness and reduce acceptance unless mitigated by safeguards; urgency can attenuate governance resistance. Because most outcomes are intention- or vignette-based, calibration, verification, and error-recovery behaviors remain under-measured. Overall, delegation appears to depend less on maximizing autonomy than on coupling capability with user governance (consent, oversight, recourse, accountability), and we outline measurement priorities for evaluating execution-capable agents."

## Plain-Language Restatement

Everyone says AI shopping agents will soon buy things for us, but when this author systematically collected every peer-reviewed consumer study (2015–2026), he found researchers have almost only tested chatbots that *recommend* — almost never agents that actually check out and pay. Of 47 mapped studies, over half measure only stated intentions, and real checkout/payment execution appears in a handful of experimental manipulations. The evidence splits into two patterns: people embrace agents that reduce friction while leaving them in charge, but system-initiated autonomy triggers reactance and powerlessness unless safeguards like approval gates, undo, and explanations exist. Urgent contexts make people tolerate more autonomy, and mid-level "co-assistant" roles beat both pure advisor and full executor designs.

## Problem Statement

Technical demos claim "end-to-end agentic commerce," yet consumer-facing empirical work tests assistive conversational systems and intention-based delegation. The literature is fragmented: technical studies improve performance without studying consumers; consumer studies study trust/control/reactance without specifying how autonomy should be designed. There was no clear link between autonomy level, task scope, interaction mode, transaction capability and actual delegation outcomes — nor clarity separating claimed capability from demonstrated execution. This matters because as systems move from advising to executing consequential transactions, adoption constructs like "trust" stop being sufficient; calibrated reliance, oversight, error recovery, and accountability become decisive for both performance and consumer protection.

## Methodology

- **Design**: PRISMA 2020-guided evidence-mapping systematic review with narrative synthesis (not pooled effects). Single reviewer screening/coding with audit safeguards: pre-specified codebook, full-text exclusion log with reasons, time-separated second-pass verification of high-leverage classifications, purposive boundary-case audits, conservative default rules (lower autonomy/evidence grade unless full text justifies more).
- **Search**: Scopus + Web of Science Core Collection; English-language peer-reviewed primary studies 2015–2026; last searched 20 December 2025. Reviews excluded at database filter (retained only for citation chasing); supplemented by backward/forward citation chasing and adjacent-term keyword checks (e.g., "automation bias" AND shopping; "decision delegation" AND e-commerce). No grey literature.
- **Boolean query** (verbatim): `(agentic OR (AI AND agent) OR (autonomous AND (agent OR assistant *)) OR "conversational AI" OR chatbot *) AND ("online shopping" OR "e-commerce" OR ecommerce OR checkout OR cart OR "purchase decision" OR "shopping assistant") AND (delegat* OR reliance OR "act on behalf" OR "acting on behalf" OR "user control" OR approval OR confirm* OR autonomy OR planning OR "tool use" OR tools OR "multi step" OR multistep OR memory OR "task completion")`.
- **Screening funnel**: 297 records (Scopus 226 + WoS 71) → 135 duplicates removed → 162 unique records all carried to full-text assessment (0 excluded at title/abstract) → final inclusion per documented criteria → **N = 47 studies**.
- **Coding scheme**: Autonomy Level 0 (reactive) / 1 (assistive) / 2 (workflow-guided) / 3 (execution-level, delegated control rights for a consequential action in a functioning system/sandbox/experiment). Transaction evidence T0 (none) / T1 (claimed) / T2 (simulated/proxied) / T3 (demonstrated). Evidence grade E0 conceptual / E1 perception-intention / E2 behavioral-simulated / E3 demonstrated execution. Task scope codes S=search, C=compare, R=recommend, B=cart build/listing, P=checkout/pay, N=negotiate, A=post-purchase support. Evidence direction coded positive/negative/null/mixed-contingent from primary reported tests.
- **Quality appraisal**: study-level checklist — evidentiary realism, autonomy instantiation, transaction capability evidence, construct measurement rigor, design transparency; separate quality tables for higher-evidence designs vs observational surveys (with N, analysis method, causal?, manipulation check?, CMB risk, effect size reporting).

## Key Results

Context profile of corpus (N=47):

| Panel | Category | N | % |
|---|---|---|---|
| Region | East Asia | 11 | 23.4 |
| Region | Southeast Asia | 9 | 19.1 |
| Region | Europe | 7 | 14.9 |
| Region | North America | 7 | 14.9 |
| Region | South Asia | 6 | 12.8 |
| Top countries | China | 9 | 19.1 |
| Top countries | USA | 7 | 14.9 |
| Top countries | India | 5 | 10.6 |
| Evidence maturity | Intention-only/cross-sectional (SEM, surveys) | 26 | 55.3 |
| Evidence maturity | Behavioral—simulated/proxied | 14 | 29.8 |
| Evidence maturity | Behavioral—realistic context | 7 | 14.9 |
| Samples | Customers/Users | 17 | 36.2 |
| Samples | Online panels | 11 | 23.4 |
| Samples | Students | 10 | 21.3 |

RQ1 mapping: dominant cluster is Text × Autonomy-1 (n=31); text at Autonomy-2 n=3 and Autonomy-3 n=3; multimodal (image+text) Autonomy-1 n=2; voice Autonomy-1 n=3; embedded/app Autonomy-2 n=2. Negotiation has zero significant empirical cases. Checkout/payment execution appears mainly in Frank et al.'s manipulated auto-purchase-vs-notify experiments ([40] multi-study N=1981; [41] N=1975 incl. field) — most systems are not transaction-capable.

RQ2 determinant frequencies: perceived usefulness (n=11), effort reduction/convenience (n=11), trust in agent (n=11), trust in platform/brand (n=3), perceived control (n=4), perceived autonomy/agency (n=5), reactance/powerlessness (n=4), privacy concern (n=4), perceived risk (n=3). Two-lane model: utility/assurance lane (performance cues → usefulness/satisfaction → trust → reliance/intention) dominates surveys; governance lane (autonomy cues → reactance/powerlessness → avoidance) dominates autonomy-manipulation experiments. Noted security context: Agent Security Bench documents prompt-injection/memory-poisoning attacks with >80% success, treated as governance-relevant risk.

RQ3 outcome regimes:
- Net-positive regime: "capable help + preserved agency" — friction reduction plus override/preview/confirmation keeps reliance within user comfort.
- Net-negative regime: autonomy cues signal control transfer → powerlessness/reactance → avoidance even when performance benefits exist (Frank et al.; Yoon et al.; Pizzi et al.).
- Contextual override regime: scarcity/urgency framing weakens autonomy→powerlessness, raising acceptance of high autonomy and CTR [41].
- Intermediate-optimum regime: mid-level "co-assistant" roles outperform both advisor and executor modes (Fan & Liu).
- Marketing outcomes: mostly positive for spend/GMV/WTP and loyalty/repurchase; mixed/context-dependent for purchase/adoption intention, observed conversion, brand choice. Field evidence includes increased option acceptance + GMV/user (conversational recommender A/B), heightened click-through under scarcity–autonomy framing, elevated repurchase after recommendation treatment in a live store.
- Consumer outcomes: satisfaction mostly positive; trust calibration rarely tested; regret/blame attribution not directly measured in any mapped study; fairness acts as conversion amplifier/boundary condition.

Governance design synthesis — six recurring building blocks: (1) autonomy defaults & escalation (advisor→co-assistant→executor), (2) override/undo/recourse, (3) confirmation gates (human-in-the-loop), (4) explanation depth, (5) data & privacy controls, (6) accountability signals (responsibility partition, audit trail). Tables 9–10 map these onto five risk zones (powerlessness/reactance; overreliance/miscalibrated trust; privacy/surveillance; fairness/price fairness; regret/blame) with concrete build-and-measure pairs (e.g., "Approve before purchase" gates measuring approval latency/drop-off; calibration curves; consent acceptance by data type; blame allocation agent/platform/user).

## Conclusions & Implications

Delegation succeeds when agents deliver felt competence under user governance and fails when autonomy cues imply displacement without safeguards; the design principle offered is: default to co-assistant autonomy for consequential steps, escalate to executor only with explicit consent, strong recourse, clear accountability. Theory should treat delegation (decision-rights transfer) as an explicit construct distinct from adoption, with autonomy as boundary condition/regime switch, and "trust" measured as calibration (appropriate reliance under uncertainty/error) rather than level. Research agenda: behavioral identification via field A/B with logistic/Poisson endpoints and 30/60/90-day retention; autonomy×task-type factorials testing the inverted-U; governance-as-design-variable experiments (override, confirmation gates, explanation depth, revocation); standardized trust-calibration metrics (calibration indices, Brier-score-style trust–accuracy alignment); accountability/fairness endpoints (regret intensity, blame allocation, switching); population-validity via multi-country harmonized designs.

For practitioners building payment/fintech AI systems: an agentic payments product should ship with staged authority (advisor → co-assistant with approval gates → conditional executor for low-stakes/repeat purchases), always-visible cancel/undo/refund paths, confidence-triggered human review, labeled provenance ("agent recommendation" vs "merchant claim"), incentive disclosure, and audit logs tying each automated payment to data used and rationale — exactly the governance toolkit this review shows determines safe delegation.

## Limitations

Acknowledged by authors:
- Single-reviewer screening/coding; time-separated second-pass verification mitigates but does not replace dual independent review; no inter-rater reliability statistics reported.
- No formal risk-of-bias instrument (heterogeneous designs, no pooling intended); conclusions framed as evidence map, not causal claims.
- Corpus limits: thin execution realism, dominance of cross-sectional single-source self-report, geographic/sample concentration (China/Asia-heavy; students/panels), delegation inferred from intentions, trust measured as level not calibration, terminology-driven omission risk outside commerce-scoped keywords.

Inferred by me:
- Conservative coding (deliberately downgrading claims) may itself bias the map toward "low maturity" conclusions; boundary-case judgment calls rest on one reviewer.
- Excluding grey literature means fast-moving industry agentic-checkout deployments (the very phenomenon of interest) are invisible to the map.
- The two-lane framework is presented as testable but was not empirically validated here; moderator reporting in primary studies was often descriptive subgroup comparisons rather than formal interaction tests (authors flag this themselves in Table 6 notes).
- Some narrative passages show repetition/editing artifacts typical of rapid publication.

## Relevance to Our Hackathon

This is the closest academic blueprint to a Razorpay-track agentic-payments build:

1. **Recommendation-to-delegation UX ladder**: implement the advisor → co-assistant → executor ladder literally — e.g., Razorpay-style rails behind "suggest split", "prepare payment, ask approval", "auto-pay verified repeat bills under ₹X". The review's central finding (execution-level delegation is empirically untested territory) is also a hackathon differentiator: build the approval-gate + undo telemetry nobody has measured.
2. **Consent & governance as first-class features**: the six building blocks (confirmation gates, override/undo/recourse, explanations, data controls, accountability signals, autonomy escalation) translate directly into DPDP-friendly consent flows for letting an agent pay — measurable via gate drop-off, opt-in-to-auto rate, undo usage.
3. **Trust calibration metrics**: adopt their proposed measures (reliance conditional on confidence, error-following rate, post-error reliance updating) as product analytics for an agent that pays — detecting both disuse (users disabling autopay after one failure) and misuse (blind approval of wrong payments).
4. **RTO/fraud tie-in**: the review's "overreliance" risk zone motivates showing "Why this could be wrong" panels — pair agent checkout with an RTO-risk score so the agent refuses/flags high-risk COD shipments before paying.
5. **Urgency asymmetry**: scarcity/time pressure increases tolerance for autonomy — useful for designing when an agent may escalate authority (flash sales, expiring bookings) without triggering reactance.
6. **Evidence-grade discipline**: reuse the T0–T3/E0–E3 grading vocabulary to honestly label what our hackathon demo actually demonstrates (sandbox proxy vs live transaction) — judges will notice the rigor.
