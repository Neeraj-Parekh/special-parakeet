# Figures & Tables — The Role of AI Agents in Autonomous Online Purchasing

**Verdict: the paper contains NO numbered figures and NO numbered data tables.** It is a purely conceptual/narrative essay. All "diagrams" are inline ASCII-style flow notations in the body text (e.g., `Goal → Planning → Information Retrieval → Decision → Action → Feedback`, `Consumer Sets Rules → AI Executes Within Rules`), which are typographic, not graphical.

## Embedded images (from PDF raster layer)

| ID | File | Page | Type | What it shows | Construction / quality | Supports |
|---|---|---|---|---|---|---|
| Unnumbered cover art | `img_p001_16.png` (144×181 px) | 1 | Journal logo/cover graphic | Scales of justice + bank/institution icon + pie-chart icon on blue diamond background — decorative branding of the journal (Cadernos de Pós-Graduação em Direito Político e Econômico), thematically law/finance | Flat vector-style clip-art; low resolution; no data content | Nothing (branding only) |

## Inline (unnumbered) text tables worth noting

1. **§6.3 Product-comparison matrix** — 3-column illustrative table (Price / Battery / Weight / Reviews × Products A/B/C with Medium/High/Low values). Purely hypothetical illustration of how an agent organizes comparisons; no real data.
2. **§24 Risk-based human-oversight matrix** — Purchase type vs AI role: Routine low-value → Autonomous; Moderate-value → Recommendation + confirmation; High-value → Decision support; Financially sensitive → Strong human control; Legally sensitive → Human oversight. This is the paper's most reusable framework artifact (conceptual, not empirical).

## Quality/editing observations
- No charts, plots, screenshots, or empirical visuals exist anywhere in the 18-page PDF — consistent with the venue-quality caveat recorded in summary.md/metadata.json (conceptual essay in a law postgraduate journal).
- Nothing to extract into `tables.csv` (no numeric data tables).
