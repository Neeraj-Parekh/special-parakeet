# Research Requests — The Role of AI Agents in Autonomous Online Purchasing

- [High] User study (n>=30) testing whether surfacing mandate rules + per-purchase "why it was bought" records increases trust/acceptance of an agent checkout vs. a plain autonomous flow; measure with a Likert trust scale and completion rates.
- [High] Prototype risk-tiered step-up authentication for agent-initiated payments: auto-approve under a configurable cap, require confirmation above it, hard-block financially sensitive categories; measure friction vs. fraud-catch trade-off on synthetic orders.
- [Med] Experiment on sponsored-ranking disclosure: A/B test agent recommendations where ranking is commission-driven with vs. without disclosure; measure user override rate and trust scores.
- [Med] Simulate compromised-agent account takeover: inject preference/address changes into an agent session and evaluate whether anomaly monitoring (the paper's "detect unusual behaviour") flags redirected-delivery COD orders before dispatch.
- [Med] Quantify impulse-buying effects: compare cart value and return/RTO rates for purchases made via rule-bound agents vs. free-form browsing on synthetic shopping logs.
- [Low] Survey willingness-to-share-data: elicit consumer comfort sharing purchase history/payment methods with shopping agents under different permission-revocation designs (DPDP-style granular consent).
- [Low] Test hallucination consequences: run a shopping agent against stale product pages (wrong specs/return policy) and measure how often confirmation gates catch financially consequential errors.
- [Low] Model agent-gateway concentration: simulate retailer traffic share when a single recommender agent controls discovery; quantify SME visibility loss/gain under neutral vs. sponsored ranking.
