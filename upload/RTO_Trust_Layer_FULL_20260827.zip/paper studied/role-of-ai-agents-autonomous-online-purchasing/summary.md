# The Role of AI Agents in Autonomous Online Purchasing

| Field | Value |
|---|---|
| **Authors** | Elena V. Marlowe (Department of Computational Science, Northbridge University, United Kingdom) |
| **Venue / Year** | Cadernos de Pos-Graduacao em Direito Politico e Economico (ISSN 1678-2127), Vol. 26, Issue 2, pp. 575-592, 2026. Submitted 24.03.2026; Accepted 12.06.2026; Published 13.08.2026 |
| **Type** | journal article (conceptual / narrative review) |
| **DOI / URL** | No DOI in text; journal website stated as https://ceapress.org |
| **Processed** | 2026-08-26T05:29:16Z |
| **Source PDFs** | 52.pdf (sha256 7503350c) |

> Version 1 — generated from extracted PDF text.

> **Venue-quality caveat (inferred by me, not from the paper):** this appears in a Brazilian law/political-economy postgraduate journal, is a single-author conceptual essay with no methodology section, no dataset, no empirical evaluation, and cites only 15 general references. Treat its claims as informed opinion/framework, not evidence.

## Abstract
> "The rapid development of artificial intelligence is transforming electronic commerce from a model in which consumers actively search, compare, and purchase products toward an emerging model of agentic commerce, in which AI agents can perform substantial portions of the purchasing process on behalf of consumers. AI agents differ from conventional recommendation systems and chatbots because they can interpret goals, plan tasks, interact with digital platforms, retrieve information, compare alternatives, and potentially execute transactions. This development has important implications for consumer behaviour, digital marketing, retail strategy, competition, transaction costs, privacy, trust, and consumer autonomy."

> "This paper examines the role of AI agents in autonomous online purchasing from a Commerce perspective. It discusses the evolution from traditional e-commerce and recommender systems toward conversational and agentic purchasing. The paper examines how AI agents can identify consumer requirements, search products, compare prices, evaluate reviews, monitor discounts, make recommendations, complete transactions, and provide post-purchase assistance. The analysis suggests that AI agents can substantially reduce information-search costs and decision complexity while increasing convenience and personalization. They may also benefit businesses by improving customer targeting, reducing transaction costs, increasing conversion opportunities, and creating new forms of digital customer relationships."

> "At the same time, autonomous purchasing introduces substantial risks. Consumers may lose direct visibility into how alternatives are selected, while AI agents may prioritize commercially sponsored products or make decisions based on incomplete or inaccurate information. Privacy concerns may intensify because agents require access to detailed consumer preferences, purchase histories, payment information, and potentially other digital services. Security risks also increase when AI agents possess the ability to perform transactions. Furthermore, autonomous purchasing raises questions regarding consumer responsibility, algorithmic accountability, competition among retailers, and the balance between convenience and consumer autonomy."

> "The paper concludes that AI agents are likely to become an important component of future digital commerce, but their development should be guided by principles of transparency, consumer control, security, fairness, explainability, and human oversight. Rather than completely replacing consumer decision-making, responsible AI agents should function as delegated decision-support systems that act according to clearly defined consumer preferences and constraints. The future of autonomous online purchasing will therefore depend not only on technological capability but also on trust, governance, market structure, and the ability of consumers to maintain meaningful control over delegated purchasing decisions."

(Keywords listed: AI Agents, Autonomous Purchasing, Agentic Commerce, E-Commerce, Artificial Intelligence, Consumer Behaviour, Online Shopping, Digital Commerce, Consumer Trust, Personalization, Algorithmic Decision-Making, Autonomous Transactions.)

## Plain-Language Restatement
Instead of shoppers searching and comparing products themselves, AI assistants will increasingly do it for them: understand the goal, search multiple stores, compare options, and even complete the purchase. This saves time and reduces information overload, but creates new problems - people may not see how choices were made, agents might favor retailers that pay them, they need lots of personal and payment data, and a hacked agent could buy things or leak information. The author argues agents should work within rules set by the consumer (spending limits, approval steps) rather than act without restriction, with more human control required as purchase value and sensitivity rise.

## Problem Statement
E-commerce still places the full decision burden (search, compare, evaluate reviews, select seller, pay) on consumers, and growing product variety makes that burden heavier; existing AI only partially reduces it. The gap addressed: what changes when AI moves from influencing decisions to executing purchases - for consumer behavior, trust, privacy, security, competition, transaction costs, and legal responsibility - and how agentic commerce should be governed. A central open question posed: "Who controls the purchasing journey-the consumer, the AI agent, or the platform through which the agent operates?"

## Methodology
Not an empirical study - no dataset, algorithms, metrics, or statistical tests (not stated in text). It is a conceptual analysis:
- Stages e-commerce evolution: Traditional (Search -> Compare -> Select -> Pay), Recommendation-based, Conversational, Generative-AI, Agentic (Consumer Goal -> AI Agent -> Search -> Evaluate -> Purchase).
- Applies three established frameworks qualitatively: Technology Acceptance Model (Davis 1989: perceived usefulness + ease of use lead to acceptance and continued use); Theory of Planned Behaviour (Ajzen 1991: delegation raises perceived behavioral control but may reduce direct control); Information-Processing Perspective (large choice set leads to overload; AI filtering reduces decision complexity, at the cost of unseen alternatives).
- Defines an agent loop distinct from chatbots/recommenders: Goal -> Planning -> Information Retrieval -> Decision -> Action -> Feedback.
- Describes an 11-step autonomous purchase workflow: understand requirements; search multiple platforms; identify suitable products; compare specifications; evaluate prices; examine reviews; apply consumer preferences; recommend an option; obtain authorization; complete purchase; monitor delivery.
- Proposes a risk-based human-oversight matrix and a multi-agent ecosystem (Shopping -> Comparison -> Price -> Transaction -> Service agents).
- Cites the OECD's 2025 definition of e-commerce, which explicitly addresses AI-assisted transactions, as evidence of policy relevance.

## Key Results
Conceptual/qualitative claims only (no quantitative metrics reported):

| Theme | Paper's key claims |
|---|---|
| Benefits | Reduced search/decision cost, browsing time, cognitive effort, decision fatigue; higher convenience and personalization; business gains via targeting, conversion, lower service costs |
| Trust prerequisites | Agent must understand preferences, search fairly, give accurate info, not favor sellers without disclosure, respect spending limits, protect data; trust strengthened by transparent reasoning, clear preferences, spending controls, purchase confirmations, audit logs, easy cancellation |
| Autonomy model | "Consumer Sets Rules -> AI Executes Within Rules" (e.g., auto-buy only below a specified price) rather than "AI Makes Unrestricted Decisions" |
| Impulse buying | Agents could reduce impulse purchases by enforcing predefined rules, but merchant-designed agents could promote add-ons; conflict of interest when one entity is consumer assistant + retailer representative + advertising intermediary |
| Sponsored ranking | Consumers should know if recommendations are preference-, price-, quality-, sponsored-, or commission-driven |
| Privacy | Agent needs purchase history, preferences, addresses, payment methods, shopping behavior, subscriptions, schedules - a high-value misuse target; mitigations: data minimization, encryption, access controls, explicit permissions, secure authentication, revocable permissions |
| Security | Compromised agent could manipulate purchases, change preferences, redirect deliveries, access personal data, make unauthorized transactions; controls: Authentication, Authorization, Transaction Limits, Confirmation for high-risk purchases, Monitoring for unusual behavior |
| Hallucination risk | Wrong beliefs about specs, return eligibility, discounts, delivery guarantees have direct financial consequences; verified/current sources plus confirmation mechanisms advised |
| Risk-based oversight | Routine low-value: Autonomous. Moderate-value: Recommendation + confirmation. High-value: Decision support. Financially sensitive: Strong human control. Legally sensitive: Human oversight |
| Competition | Dominant agents become gateways (Consumer -> AI Agent -> Selected Retailers instead of Consumer -> Open Marketplace); "AI discoverability" becomes strategically important; SMEs may gain (price/quality/delivery/information) or lose (platform data advantage) depending on market structure; welfare depends on governance |
| Responsibility | Liability ambiguous across consumer / AI developer / retailer / platform provider / payment provider; consumers should receive records showing what was purchased, why, price, seller, authorization conditions |

Ethical principles proposed: Transparency, Fairness, Consumer Control, Privacy, Accountability, Explainability. Recommendations target four audiences: businesses (10 items incl. disclose sponsored recommendations, respect consumer-defined purchasing limits, provide transaction records, avoid manipulative agent design, implement authorization controls), AI developers (factual accuracy, explainability, permission systems, secure architectures, audit trails, prevent unauthorized transactions), consumers (set spending limits, review permissions, verify high-value purchases, protect credentials, monitor histories), policymakers (clarify rights, transparency requirements, address algorithmic discrimination, protect data, monitor competition, accountability standards).

Research gaps listed: consumer acceptance; long-term delegation effects on decision-making; systematic agent bias toward sellers; platform power; willingness to share data with agents; new attack mechanisms against agentic systems; allocation of legal responsibility.

## Conclusions & Implications
Authors' claims: AI agents are likely to become a major component of future commerce, transforming the experience to "Goal -> AI Agent -> Recommendation -> Authorization -> Purchase". Value lies in converting consumer goals into coordinated digital actions, but the responsible model is bounded delegation: "Consumer Defines Goals and Limits -> AI Searches and Evaluates -> Consumer Maintains Appropriate Control -> AI Executes Authorized Actions." Well-governed agents reduce transaction costs and improve welfare; poorly governed ones create manipulation, market concentration, privacy loss, and loss of autonomy. Guiding principle: "AI should act on behalf of consumers-not against their interests and not without meaningful control."

For practitioners building payment/fintech AI systems: the authorization-before-execution workflow, spending-limit enforcement, confirmation gates for high-risk purchases, audit logs, and disclosure of commission-driven rankings are exactly the consent/mandate surfaces a payment provider must expose to shopping agents.

## Limitations
Inferred by me (the paper explicitly acknowledges none):
- Purely conceptual: no data, experiments, user studies, or formal analysis; many statements are speculative ("may", "could").
- Venue mismatch and thin referencing (15 sources, mostly classic marketing/IS literature); no engagement with technical agent-security or payment-protocol literature per its own reference list.
- The risk-based oversight tiers are asserted, not validated with users or merchants.
- No treatment of India-specific rails/regulation, COD/RTO dynamics, or fraud economics.
- Author affiliation ("Northbridge University") cannot be cross-checked from the text; single-author output warrants caution.

Acknowledged by authors: the paper itself enumerates unresolved research gaps (acceptance, autonomy, bias, competition, privacy, security, legal responsibility), implicitly conceding these questions are untested here.

## Relevance to Our Hackathon
Useful demand-side / consumer-protection framing for our Razorpay-track build:
- **Consent & mandate design**: "Consumer Sets Rules -> AI Executes Within Rules" plus the explicit "obtain authorization" step is a clean product spec for mandate artifacts: budget caps, category allow-lists, price thresholds, per-purchase confirmation gates - enforceable server-side by the payment provider, not trusted to the agent.
- **Risk-tiered authentication**: its oversight matrix (autonomous only for routine low-value; strong human control for financially sensitive) maps onto step-up authentication / dynamic risk-based challenges for agent-initiated payments - value- and risk-threshold logic we can demo.
- **Trust scores**: it enumerates what makes humans trust an agent (transparent reasoning, confirmations, audit logs, easy cancellation) - a checklist of UX signals our agentic-transaction trust score should surface to buyers, not just compute internally.
- **Fraud/RTO implications (our transfer)**: compromised-agent attacks (manipulate purchases, change preferences, redirect deliveries) are account-takeover where the session is an agent; our RTO-risk model should treat agent-initiated COD orders carrying such indicators (sudden address/preference changes) as elevated risk.
- **Explainability & records**: the requirement that consumers see why something was purchased supports our explainable-risk-decision deliverable and DPDP-style consent artifacts.

## Figures & Tables
The paper has **no numbered figures or tables** — it is a conceptual essay. The only embedded image is the journal's cover logo (scales-of-justice/institution/pie-chart icons, 144x181 px, no data content). Two inline *unnumbered* text tables exist: the illustrative product-comparison matrix (§6.3) and the risk-based human-oversight matrix (§24: routine→autonomous; moderate→recommend+confirm; high-value→decision support; financially sensitive→strong human control; legally sensitive→human oversight). All other "diagrams" are typographic flow notations (e.g., `Goal -> Agent -> ... -> Feedback`). See [figures.md](./figures.md) for the full log.

---
*Verification: v2 full word-by-word source read completed 2026-08-26; all header facts, verbatim abstract, frameworks, workflow steps, oversight matrix and recommendations confirmed against the extracted PDF text; no factual corrections required.*
