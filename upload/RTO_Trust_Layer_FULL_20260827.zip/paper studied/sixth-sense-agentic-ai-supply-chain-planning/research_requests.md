# Research Requests

- [High] Instantiate the four-layer architecture for COD RTO mitigation (Perception: payment/checkout + courier events; Cognitive: RTO model; Agentic: prepaid-nudge/partial-COD/confirmation-call actions; Human-AI: merchant approval dashboard) and demo it end-to-end on synthetic event streams.
- [High] Build the scenario-simulation component: for each high-risk shipment, compute expected savings and confidence for {nudge-to-prepaid, partial-COD, do-nothing} using our risk model's calibration, then auto-execute only above a confidence cutoff — mirroring the paper's confidence-scored mitigation selection.
- [Med] Define a baseline-vs-after KPI table in the paper's style for a simulated 90-day deployment (RTO %, COD share of GMV, first-attempt success, ops workload hours) so the hackathon demo shows business deltas, not just AUC.
- [Med] Run a small planner/merchant interview or survey (even n=5) on trust in agent-executed payment interventions, testing the paper's claim that auditability of recommendations drives adoption; report qualitative themes.
- [Med] Ablate layers to attribute gains (as the paper does not): compare Cognitive-only (risk scores shown to humans), Cognitive+Agentic (auto actions), and full stack with escalation, measuring RTO outcomes and human workload.
- [Low] Add multi-signal "demand sensing" analog: ingest external feeds (weather, festival calendars, port/courier congestion proxies) into the RTO model and measure forecast improvement, echoing the claimed >40% error reduction from real-time signals.
- [Low] Specify governance guardrails concretely: action-value thresholds, daily autonomous-action budgets, kill switch, and audit-log schema for every agent-initiated payment intervention, aligned with DPDP-style consent.
