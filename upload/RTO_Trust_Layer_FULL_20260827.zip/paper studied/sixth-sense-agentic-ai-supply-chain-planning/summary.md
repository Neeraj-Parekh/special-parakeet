# Supply Chain with Sixth Sense Agentic AI: A Proactive Intelligence Framework for Autonomous Planning

| Field | Value |
|---|---|
| **Authors** | Venkatesh Prabu Parthasarathy (Pepperdine University, Lake Forest, USA), Madhusudan Sharma Vadigicherla (Purdue University, Collierville, USA) |
| **Venue / Year** | 5th IEEE International Conference on AI in Cybersecurity (ICAIC), 18–20 February 2026, University of Houston, Houston, USA |
| **Type** | conference paper |
| **DOI / URL** | DOI: 10.1109/ICAIC67076.2026.11395643 (ISBN 978-1-6654-7761-1/26) |
| **Processed** | 2026-08-26T05:29:19Z |
| **Source PDFs** | annas-arch-96f7578c490a.pdf (sha256 64968f9d…) |

> Version 1 — generated from extracted PDF text.

## Abstract

> "The complexity and instability of today's supply chains are forces that are going to require decision-making frameworks that are proactive, adaptive, and intelligent. The paper being presented here is about the introduction of the Sixth Sense Agentic AI, a new architecture, whose purpose is to steer the traditional planning of supply chains into a nonstop loop of intelligence that is always anticipating. The system consists of four layers, namely Perception, Cognitive, Agentic, and Human–AI Collaboration, which support the ingestion of data in real-time, predictive analytics, the execution of operations by autonomous entities, and supervision by the responsible party. Uses of the system are among others: demand sensing, multi-echelon inventory optimization, scenario planning, and collaborative Sales & Operations Planning (S&OP). The trial of the framework was done on 24 months of mixed data: historical and real-time data was used together with POS, weather, and supplier performance data, plus social sentiment information. The operational results of this study were refreshing: accuracy of forecasts went up by 35%, cost incurred from inventory outweighed by 18%, time for planning cycles cut by 50%, time to respond to scenarios made better by 89%, stock-outs down by 61% and 13% more deliveries being on-time than in the past. Feedback from users confirms the quality of decision making has improved, that collaboration across different functions has increased, and that planners are more confident, but they also have stressed the importance of having governance and supervisions in place. The study says that Sixth Sense Agentic AI can bring about a supply chain ecosystem that is proactive, autonomous, and resilient, thus making it possible to gain both operational and strategic advantages."

## Plain-Language Restatement

The authors propose an "agentic AI" architecture for supply chain planning in which software agents don't just analyze data but continuously perceive signals (point-of-sale, weather, supplier performance, social sentiment), predict problems, and execute actions like replenishment and shipment re-routing — with humans supervising through a dedicated collaboration layer. In their deployment study over 24 months of data they report large gains: forecast accuracy up from 62% to 84%, planning cycle time halved, disruption-response time cut by ~89%, stock-outs down 61%, and on-time delivery up from 82% to 93%. Planners interviewed said confidence and cross-functional collaboration improved, provided governance limits on agent autonomy exist.

## Problem Statement

Contemporary supply chains face unprecedented demand/supply variability (globalization, shifting consumer behavior, digital commerce, climate change, geopolitics) that deterministic, historical-data-driven planning cannot accommodate — producing long planning cycles, stock-outs, excess inventory cost, and poor risk management. The "Planning Paradox": organizations are data-rich but information-poor; more data means more noise and less clarity, so traditional forecast-and-lagging-indicator planning reacts instead of anticipates. Agentic AI is proposed as the missing layer that perceives, reasons, acts autonomously, and learns continuously ("Sixth Sense" = a system's human-like gut feel for early risk signals).

## Methodology

- **Architecture (four layers)**: Perception Layer (real-time ingestion from ERP platforms, POS systems, weather forecast services, social trend analytics, IoT sensors, port congestion dashboards, freight index feeds) → Cognitive Layer (predictive models/ML finding patterns and insights) → Agentic Layer (decides and executes operational tasks: replenishment planning, multi-scenario evaluation, supplier-risk mitigation, dynamic shipment re-routing) → Human–AI Collaboration Layer (responsible governance; planners observe processes, approve/modify AI actions, add domain knowledge).
- **Applications described**: demand sensing & forecasting (real-time signals boost predictions; claims >40% reduction of forecast errors; real-time control towers with predictive alerts); inventory optimization (dynamic safety-stock adjustments on supplier delays, transit volatility, lead-time variation; multi-echelon visibility suppliers→plants→DCs→retailers; tracking Inventory Turns and Stock-out Probability); scenario planning (simulation of geopolitical risk, supplier outages, port congestion, logistics failures with mitigation options, confidence scores, cost-impact analysis); collaborative S&OP (AI agents generate consensus plans; continuous transparency with suppliers/customers).
- **Study design**: mixed-methodology over 24 months of data combining shipment records, real-time demand signals, POS and weather data, procurement and supplier performance records, freight rate indices, market and social sentiment data. Evaluation metrics: forecast accuracy, inventory carrying cost, planning cycle time, scenario response time; supplemented by additional KPIs tracked for one year post-implementation and qualitative structured interviews/surveys with planners and managers.
- Specific algorithms, model names, hyperparameters, and statistical tests are not reported ("not stated in text").

## Key Results

**Headline metrics (Table I / Table II):**

| Metric | Baseline | After AI | Improvement |
|---|---|---|---|
| Forecast Accuracy (MAPE-based) | 62% | 84% | +35% |
| Inventory Carrying Cost (% of total inventory) | 15% | 12.3% | −18% |
| Planning Cycle Time (days) | 5 | 2.5 | −50% |
| Scenario Response Time (hours) | 6 | 0.67 (40 min) | −89% |
| Stock-out Incidents (per quarter) | 18 | 7 | −61% |
| On-Time Delivery (%) | 82% | 93% | +13% |
| Planner Workload (manual hours/week) | 40 | 18 | −55% |

Additional claim in applications section: >40% reduction in forecast error via multi-signal demand sensing; agents spot potential disruptions ~6× faster than human planners.

**Qualitative findings:** improved strategic decision quality and planner confidence (attributed to AI-assisted scenario evaluations and predictive alerts); better cross-functional/regional collaboration via shared real-time visibility; appreciated transparency/auditability of AI recommendations; initial adoption friction (trust issues, unfamiliarity with autonomous agents) overcome via training programs and explicit limits on AI decision-support scope; interviewees stressed governance protocols keeping automated actions aligned with organizational policy for accountability and compliance.

## Conclusions & Implications

Authors claim agentic AI shifts planning from reactive, calendar-based cycles to a continuous anticipate–simulate–act loop, delivering measurable operational returns plus resilience, transparency, and faster decisions; human-AI collaboration with governance is presented as essential rather than optional. For practitioners building payment/fintech AI: this is the corpus's concrete template for *agentic* operational loops with human escalation — directly analogous to an RTO-mitigation agent that senses delivery signals, simulates interventions (nudge-to-prepaid vs partial-COD vs confirmation call), executes low-risk actions autonomously, and escalates high-stakes ones to humans; its KPI table is a model for defining before/after success metrics in our demo; its qualitative finding that auditability builds planner trust supports exposing intervention logs in any payments-adjacent agent product.

## Limitations

*(Acknowledged by authors)*: initial adoption faced trust issues and lack of knowledge about autonomous agents (mitigated by training and bounded decision-support); governance protocols are stated as necessary; no formal limitations section beyond this. *(Inferred by me)*: no description of the underlying models, baselines' construction, dataset scale, industry context, or statistical significance — results cannot be independently verified or reproduced; improvement percentages relative to unspecified baselines risk overstating effects; single-deployment case evidence; possible reporting inconsistencies (e.g., abstract says forecast accuracy rose "by 35%" while narrative elsewhere garbles "62 to 84 35 percent"; scenario response 89% corresponds to 6h→40min); venue framing (cybersecurity conference) unrelated to methods; no ablation isolating which layer drives which gain; qualitative feedback sample size and protocol unreported.

## Relevance to Our Hackathon

Strong design analogy for an agentic payments/commerce entry: (1) copy the four-layer pattern — Perception (order/delivery/payment-status event streams), Cognitive (RTO-risk model à la Hu/Kandula), Agentic (executes nudges: prepaid conversion offers, partial-COD prompts, confirmation calls), Human-AI Collaboration (merchant dashboard with approve/modify/escalate) — as our reference architecture diagram; (2) reuse its evaluation style: report baseline-vs-after deltas on business KPIs (RTO rate, COD share, delivery success, planner/call-center workload) not just AUC; (3) its scenario-planning-with-confidence-scores maps onto simulating intervention policies before deployment (expected savings per policy, confidence bands); (4) its emphasis on auditable recommendations and tiered autonomy prefigures consent/governance requirements under DPDP-style regimes for payment-touching agents; (5) cite cautiously — numbers are self-reported without reproducible methodology, so present as illustrative targets rather than validated benchmarks.
