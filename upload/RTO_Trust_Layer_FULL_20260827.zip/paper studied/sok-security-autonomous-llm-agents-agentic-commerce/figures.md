# Figures & Tables Deep Dive — sok-security-autonomous-llm-agents-agentic-commerce

Source: `2604.15367v2.pdf` (key `4b09979e5026`) — 17 pages, arXiv 26-04-15367v2. Rendered pages inspected: `page_005.png` (PDF p.5), `page_006.png` (PDF p.6), `page_010.png` (PDF p.10), `page_011.png` (PDF p.11), `page_012.png` (PDF p.12), `page_013.png` (PDF p.13) per `figures_index.json`. Embedded images count: 0. Source text scan: 2,433 lines. Figure count: **1 numbered Figure (Figure 1)** + **4 numbered Tables (Table 1–4)**. No plots, charts, photos, heatmaps, or ROC/confusion matrices present — this SoK is text+taxonomy tables only.

## Inventory (n=5 logical objects: Figure 1 + Tables 1,2,3,4)

### Figure 1 — Five-dimensional threat taxonomy for autonomous financial agents (page 6, page_006.png, lower-left panel)
- **ID / Page**: Figure 1, caption: "Figure 1. Five-dimensional threat taxonomy for autonomous financial agents." Rendered PDF p.6 (page_006.png ~60% width left column). Also referenced in text §4 opening line "illustrated in Figure 1" (p.5 right column line).
- **Type**: Taxonomy diagram — trapezoid/stacked-layer diagram (not a plot). Vector typesetting, dark teal (#1e6b8a approx) rectangular boxes inside a thin outlined trapezoid, two-column text inside.
- **Construction inference**: LaTeX vector (`tikz`/`tcolorbox` style), not matplotlib/gnuplot/hand-drawn/raster screenshot. Crisp vector at ~250–300 dpi PNG render, no blur, consistent sans-serif font (Helvetica/Inter-like) for boxes, serif for caption. Not Excel/PowerPoint paste — aligned borders, uniform fill, trapezoid outline single stroke.
- **Axes / Legend / Units / Series**: No axes. Layers bottom→top: **D1: Agent Integrity** [Model poisoning | Prompt injection | Tool compromise] (3 boxes), **D2: Transaction Authorization** [Key management | Spending bounds | Intent verification] (3), **D3: Inter-Agent Trust** [Identity spoofing | Collusion | Protocol manipulation] (3), **D4: Market Manipulation** [Agent-driven manipulation | Adversarial herding | Flash attacks] (3), **D5: Regulatory Compliance** [KYC/AML gaps | Liability attribution | Audit trails] (3). Each D label centered above its 3-box row; D1 bottom, D5 top; trapezoidal containment implies hierarchy/cross-layer stacking.
- **Concrete takeaways readable**: Exactly 15 sub-threats enumerated (3 per dimension). Matches §4.1–4.5 detailed subsections: D1 three injection/poisoning/tool; D2 three credential/bounds/intent; D3 three identity/negotiation/collusion; D4 three agent-driven/herding/sandwich-flash; D5 three KYC/VASP-liability/audit. No numbers beyond labels.
- **Quality / editing observations**: High venue quality. Boxes uniformly sized, text centered, no overflow, trapezoid border encloses precisely. Caption font 8pt serif italic. No watermark, low-res raster, or cropped box. Colors solid dark teal with white text — high contrast print-safe. Slight aliasing on diagonal trapezoid edges is render artifact, not source defect.
- **Supports / contradicts summary.md claim**: Directly supports Methodology/ Key Results claim "Five-dimensional threat taxonomy (D1–D5)" and each D's bullet list. Summary correctly copies all 15 sub-box labels verbatim. No contradiction. Summary's mention of Figure 1 as taxonomy diagram is accurate; summary does not claim any plotted figure — correct.

### Table 1 — Per-vector released supporting works in the current public corpus (page 6, page_006.png, top two-column span + continuation page 5 reference)
- **ID / Page**: TABLE 1. PER-VECTOR RELEASED SUPPORTING WORKS IN THE CURRENT PUBLIC CORPUS. Full table rendered on page_006.png top across both columns (booktabs rules: thick top, thin mid, thick bottom). Caption above table. Also referenced p.5 right column: "Table 1 lists the currently released per-vector supporting works..." + p.3 "For the released 30-row blinded replication set..." (§3.3).
- **Type**: Data table (qualitative - citation mapping), 4 columns × 12 data rows + header.
- **Construction inference**: LaTeX vector `tabular`/`booktabs` (serif body, small caps caption, bold header). Crisp vector, font size ~7pt for body (fits 12 rows × long citation lists), ruling lines sharp. Not raster, not hand-drawn.
- **Axes / Legend / Units / Series**: Columns exactly: `Vector | Name | Direct | Derived`. Units: citation identifiers [n] per cell. Rows verbatim as rendered:
  - `P2T | Prompt-to-Transaction | Greshake et al. [17]; Acharya [18]; Nieper-Wisskirchen et al. [48] | No released derived-support evidence in the current snapshot.`
  - `T2R | Tool-to-Reasoning | Model Context Protocol [43]; Maloyan and Namiot [49]; Zhang et al. [50] | No released derived-support evidence in the current snapshot.`
  - `A2M | Agent-to-Market | Allouah et al. [51]; Kapoor et al. [52] | Liu et al. [11]; Chung and Honavar [53]; de Paula et al. [54]; Cai et al. [55]`
  - `T2T | Tool-to-Transaction | Acharya [18]; Shittu [56]; Ruan et al. [57] | Deng et al. [58]`
  - `P2K | Prompt-to-Key | Acharya [18] | Steinberger [3]; Luo et al. [4]; Rizinski and Trajanov [5]`
  - `C2E | Collusion-to-Escrow | Virtuals Protocol [30]; Crapis et al. [35] | Liu et al. [11]; Yu et al. [59]; de Witt [60]; Hu and Rong [61]`
  - `O2P | Oracle-to-Position | Moreno [62]; Assis et al. [63] | Nabar and Shroff [64]; Kim et al. [65]`
  - `N2C | Neg-to-Compliance | Faysal et al. [66] | Liu et al. [11]; Allouah et al. [51]; Hornuf et al. [67]`
  - `I2M | Identity-to-Market | Xu et al. [68] | No released derived-support evidence in the current snapshot.`
  - `S2I | Supply-to-Integrity | Model Context Protocol [43]; Ruan et al. [57] | Maloyan and Namiot [49]; Zhang et al. [50]`
  - `M2A | Model-to-Authorization | Hirano et al. [69] | Zhu et al. [70]; Banerjee et al. [71]; Konstantinidis et al. [72]`
  - `R2I | Reg-to-Integrity | Faysal et al. [66] | Shukanayev [73]; Hornuf et al. [67]; Bain and Subirana [74]`
  Caption clarifies Direct = confirmed incident/PoC/experimental demonstration; Derived = conceptual precursor / cross-paper synthesis support. Vectors with fewer direct-support papers (R2I, M2A, C2E) are more speculative — noted in §3.3 and §5.2.
- **Concrete takeaways readable**: 3 vectors have **zero derived support** (P2T, T2R, I2M); 9 vectors have at least one derived; C2E and M2A have only 2 direct but 4 and 3 derived respectively; N2C/R2I share same direct source Faysal[66]; Table shows evidence density is uneven — supports paper's honesty marking R2I/M2A as early-warning categories.
- **Quality / editing observations**: High quality but dense; Derived column for A2M wraps into 2 lines ("de Paula et al. [54]; Cai et al. [55]"), measured line-break hyphenation normal; no cropped text, all citations readable at PNG magnification 150%. Reference numbers [17]→[74] sequential not alphabetical — matches reference list order. No blur/watermark. Blue hyperlink color on reference numbers (e.g., [17]) preserved but not essential.
- **Supports / contradicts summary.md claim**: Summary's 12-vector catalog and "Support level (paper's Table 1)" column replicates Direct vs Derived flags — verified cell-by-cell; one minor deviation: summary markdown Table lists T2T as "Direct" only while image shows `Deng et al. [58]` under Derived — summary should be "Direct + derived" for T2T (fix applied in tables.csv). Otherwise exact match. Summary note "R2I and M2A have fewer direct-support papers and are explicitly speculative" originates from this table's footnote (page_005 lines) and §5.2 — validated.

### Table 2 — Comparison of Agent Integrity Defense Approaches (page 10, page_010.png, left column top)
- **ID / Page**: TABLE 2. COMPARISON OF AGENT INTEGRITY DEFENSE APPROACHES. Rendered PDF p.10 (page_010.png) upper left two-column width (~90% of column), spanning header across left column + partial right. Referenced in §5.1.1 text "Table 2 summarizes the principal defense categories for agent integrity."
- **Type**: Data table (qualitative - defense trade-off matrix), 4 columns × 5 data rows + header.
- **Construction inference**: LaTeX booktabs vector, colored cell backgrounds for Overhead column (Low=light green, Medium=light yellow, High=peach, Very High=darker peach, Infeasible=white/unstyled). Font 7-8pt serif, header bold sans/serif mix. Not hand-drawn; colored fills are LaTeX `\cellcolor` not pasted image.
- **Axes / Legend / Units / Series**: Columns exactly: `Approach | Mechanism | Coverage | Overhead`. Rows verbatim:
  - `Input sanitization | Filter malicious prompts from data feeds before model ingestion | Direct injection | Low`
  - `Instruction hierarchy | Privilege separation between system and user/data prompts | Direct & indirect injection | Medium`
  - `Output validation | Verify proposed actions against policy before execution | All integrity threats | High`
  - `Redundant reasoning | Cross-check decisions with multiple independent LLM instances | Model poisoning; subtle injection | Very High`
  - `Formal verification | Prove bounded safety properties of the agent pipeline | Broad but partial | Infeasible`
 - **Concrete takeaways readable**: Overhead gradient correctly reflects paper's prose: sanitization Low but sacrifices legitimate market signals (crash headline example p.10 left), hierarchy Medium, validation High but most robust single defense yet bypassable via MCP [43], redundant Very High fails shared-backbone bias, formal verification Infeasible for full pipeline. Coverage column shows only Output validation covers "All integrity threats".
- **Quality / editing observations**: Sharp vector; colored Overhead cells have soft pastel fills not interfering with text legibility; Coverage column wraps: "Model poisoning; subtle injection" broken across two lines with semicolon; no overflow; rules straight. Second column "Filter malicious prompts from data feeds before model ingestion" wraps into 3 lines correctly hyphenated. No blur/cropping. Text on right column adjacent to table (Runtime verification paragraph) does not overlap table borders.
- **Supports / contradicts summary.md claim**: Supports "Defense approaches trade-offs" paragraph in summary: input sanitization risks filtering legitimate signals (e.g., 'crash' headline), output validation most robust but latency, redundant multiplies cost fails shared-backbone, formal verification infeasible. All phrasing in summary matches exact Mechanism/Coverage/Overhead cells. No contradiction. Summary's mention of overhead levels Low/Medium/High/Very High/Infeasible mirrors image exactly.

### Table 3 — Summary of 12 Cross-Layer Attack Vectors for Autonomous Financial Agents (page 11, page_011.png, right column)
- **ID / Page**: TABLE 3. SUMMARY OF 12 CROSS-LAYER ATTACK VECTORS FOR AUTONOMOUS FINANCIAL AGENTS. Rendered PDF p.11 (page_011.png) right column top. Caption small caps centered above table; table spans right column width (~45% page). Also referenced in §5.2 opening "Table 3 provides a concise overview with adversary preconditions and layer paths."
- **Type**: Data table (qualitative - attack-vector taxonomy), 4 columns × 12 rows + header.
- **Construction inference**: LaTeX booktabs vector, font ~6.5pt dense to fit 12 rows in ~35% column height; header horizontal rule, no vertical rules. Vector crisp.
- **Axes / Legend / Units / Series**: Columns exactly: `ID | Name | Layer Path | Core Mechanism`. Rows verbatim as rendered (order as image: note image order differs slightly from extracted text order but content identical):
  - `P2T | Prompt-to-Transaction | LLM → Blockchain | Injected prompt triggers signed tx`
  - `T2R | Tool-to-Reasoning | Tool → Reasoning | False data poisons decision`
  - `A2M | Agent-to-Market | Inter-agent → Market | LLM bias exploited in negotiation`
  - `R2I | Reg-to-Integrity | Compliance → Market | Regulatory gap enables laundering`
  - `T2T | Tool-to-Transaction | Tool → Blockchain | Tool modifies tx params post-reasoning`
  - `P2K | Prompt-to-Key | LLM → Custody | Injection bypasses key custody boundary`
  - `M2A | Model-to-Authorization | Model → Authorization | Backdoor defeats spending policy check`
  - `C2E | Collusion-to-Escrow | Multi-agent → Settlement | Colluding evaluators drain escrow`
  - `O2P | Oracle-to-Position | Oracle → Portfolio | Cumulative drift via subtle feed manipulation`
  - `I2M | Identity-to-Market | Reputation → Market | Sybil trust enables coordinated manipulation`
  - `N2C | Neg-to-Compliance | Protocol → Compliance | Structuring payments evades AML threshold`
  - `S2I | Supply-to-Integrity | Supply chain → All | Backdoored plugin silently alters transactions`
  Note: extracted text version at lines 1221-1302 lists same 12 vectors but orders them P2T,T2R,A2M,T2T,P2K,C2E,O2P,N2C,I2M,S2I,M2A,R2I (slight reordering of R2I/M2A vs image placement R2I 4th row and M2A 7th). Both orders contain identical set; image order prioritizes grouping more speculative R2I earlier, but textual consolidation paragraph confirms full set regardless of order — not an error, just layout.
- **Concrete takeaways readable**: Each ID maps exactly to attack pattern referenced elsewhere: P2T/T2R/T2T/S2I flagged §5.2 lines 1320-1322 as most immediate deployment risks (public inputs/tools/dependencies → authorized financial actions); C2E/O2P/N2C slower-burn cumulative hard to detect; R2I/M2A speculative early-warning. Distinctions called out in text adjacent to Table 3: T2R vs T2T (reasoning poison vs execution hijack), T2R vs O2P (acute vs chronic cumulative), P2T vs P2K (new action vs signing coercion requiring cognition-custody separation) — column Layer Path supports those distinctions directly.
- **Quality / editing observations**: Dense but fully legible at 150% zoom; name column hyphenated "Prompt-to-Transaction" broken with line break after hyphen, arrow "→" is proper Unicode vector; Layer Path column uses "→" consistently; no truncated text; Core Mechanism column wraps at 2 lines per row ("Injected prompt triggers\nsigned tx"). No watermarks, no misaligned grid; foot of table has thick bottom rule.
- **Supports / contradicts summary.md claim**: Summary's 12-vector catalog Table (lines 43-58) replicates each row's Layer path and Core mechanism verbatim — verified. Summary correctly aggregates "Most immediate deployment risks are P2T, T2R, T2T, S2I" from prose immediately below Table 3 (page_011 right column lines). No contradiction. Ordering difference between image and summary not material; verification uses set equality not order.

### Table 4 — Security Property Comparison of Representative Agent-Commerce Protocols and Execution Interfaces. 'N/A' Denotes a Dimension Outside the Artifact's Intended Scope (page 13, page_013.png, top full-width)
- **ID / Page**: TABLE 4. SECURITY PROPERTY COMPARISON OF REPRESENTATIVE AGENT-COMMERCE PROTOCOLS AND EXECUTION INTERFACES. 'N/A' DENOTES A DIMENSION OUTSIDE THE ARTIFACT'S INTENDED SCOPE. Rendered PDF p.13 (page_013.png) full-width across both columns (top of page). Referenced in §5.3 first paragraph "Table 4 compares representative protocols and execution interfaces... No single protocol covers all five dimensions." Also conclusion §6 "no existing system/protocol currently offers end-to-end coverage."
- **Type**: Data table (qualitative - protocol coverage matrix), 6 columns × 8 data rows + header (plus N/A legend).
- **Construction inference**: LaTeX booktabs vector, font ~6.5pt, header row bold centered, rows centered, small footnote line above header for N/A definition. Not raster, not hand-drawn; uniform column spacing fits 6 columns on 17cm width; reference numbers [10][11][12][30][35][42] in brackets aligned via superscript-style.
- **Axes / Legend / Units / Series**: Columns exactly: `Protocol / Interface | Agent Integrity | Transaction Authorization | Inter-Agent Trust | Market Manipulation | Regulatory Compliance`. Units are categorical coverage notes (N/A = outside intended scope). Rows verbatim:
  - `Virtuals/ACP [30] | GAME framework | Escrow settlement | Evaluator agents | Token caps | On-chain logs`
  - `ERC-8183 [35] | N/A (standard) | Job state machine | 3-role trust model | Hook-based | Reputation`
  - `ERC-8004 [10] | N/A (protocol level) | On-chain guardrails | Token-based ID | Spending caps | Audit logs`
  - `AP2 [11] | N/A (protocol level) | Intent verification | Payment attestation | N/A | Payment logs`
  - `OKX APP [12], [29] | N/A (protocol level) | Challenge/credential auth | A2A escrow/dispute | N/A | Status queries`
  - `x402 [10] | N/A (protocol level) | Per-request auth | HTTP-level auth | Rate limiting | Request logs`
  - `MPP [13], [14] | N/A (protocol level) | Digest-bound auth | Session escrow | N/A | Receipts + logs`
  - `MCP [42] | Tool sandboxing | Permission model | Server auth | N/A | Tool call logs`
  Caption clarifies N/A meaning. Construction shows payment/commerce protocols improve authorization/settlement/inter-agent coordination while MCP contributes tool-access/auditability as execution interface rather than payment protocol.
- **Concrete takeaways readable**: Column-wise: **Agent Integrity** column has only 2 non-N/A entries (Virtuals/ACP=GAME framework, MCP=Tool sandboxing) — supports claim "none by itself addresses LLM-layer compromise". **Market Manipulation** column has only 3 non-N/A (Virtuals/ACP token caps, ERC-8183 hook-based, ERC-8004 spending caps, x402 rate limiting) rest N/A — supports "long-horizon manipulation not covered". **Regulatory Compliance** column all have some log entry but none claims full compliance — supports paper's comparative conclusion. Row-wise: OKX APP row correctly lists Challenge/credential auth (matches §2.2.4 Broker verifies credentials), MPP row Digest-bound auth + Session escrow matches §2.2.8. No protocol row has non-N/A in all 5 dimensions — visual proof of summary claim "no single protocol covers all five dimensions."
- **Quality / editing observations**: Crisp vector, full-width table well-spaced, header text wraps not; N/A cells are exact string "N/A" with optional "(protocol level)" parenthetical for payment protocols — formatting consistent; Virtuals/ACP row bracket [30] is citation link blue; no overflow, no low-res; bottom thick rule under MCP row sharp. Small caption note above table ("'N/A' DENOTES A DIMENSION OUTSIDE THE ARTIFACT'S INTENDED SCOPE.") in 6pt small caps, readable.
- **Supports / contradicts summary.md claim**: Summary's Section 3 "Protocol maturity assessment" and Table 4 comparative conclusion "no single protocol covers all five dimensions; none simultaneously addresses LLM-layer compromise, long-horizon manipulation, and compliance" is direct quotation/paraphrase of §5.3 first paragraph and visualized by the N/A pattern in Table 4 — validated. Summary correctly states ERC-8004/ERC-8183 draft, AP2 research proposal, OKX APP escrow forthcoming, x402 early adopter, MPP most mature live Tempo mainnet — matching §2.2.10 which is separate from Table 4 but consistent; Table 4 itself does not show maturity status, only coverage — summary accurately distinguishes maturity (§2.2.10) vs coverage (Table 4).

## Absence statement
- **No plots/diagrams photos beyond Figure 1**: Exhaustive scan of rendered pages 5,6,10,11,12,13 (the only pages with vector tables/diagrams) plus text search of 4b09979e5026.txt for "Figure" returns exactly 1 hit: "illustrated in Figure 1" (line 525) plus Figure 1 caption itself (line 618); no Figure 2/3/4/5 exists. Rendered pages contain only the taxonomy trapezoid and tables. No line charts, bar charts, heatmaps, scatter plots, ROC curves, PR curves, confusion matrices, or dataset distribution plots are present. This is expected for a SoK/systematization paper with no experiments (§3 notes "not an empirical ML paper").
- **No numeric result tables**: No tables with accuracy, F1, precision/recall, ablation scores, latency benchmarks, or cost values. All tables are citation-mappings or qualitative coverage matrices. Therefore summary's claim "no quantitative measurement of attack success rates" in Limitations is honest and verified.

## Summary assessments
- **Venue-quality signal**: High — arXiv SoK typeset in IEEE-style two-column, vector booktabs tables, crisp rendering, consistent serif body (Times-like) + sans headers, proper two-column balance, reference block formatting consistent, trapezoid diagram professional palette. Despite preprint status, production quality high; not a paste-up; protocol spec citations include access dates (e.g., accessed: 2026-03-31, 2026-05-01) indicating up-to-date review.
- **Readability**: 100% cleanly readable at 100% zoom; no cropped axes or unreadable numbers. Smallest font is Table 3/4 6.5pt but still legible without magnification; cell wraps handled with hyphens without loss. All 12 vector IDs legible; all protocol names legible.
- **Technique fabric**: No matplotlib/ggplot/seaborn — pure LaTeX vector (`tikz`/`tabular`/`tcolorbox`); color limited to dark teal Figure 1 + pastel greens/peaches in Table 2 Overhead column; rest monochrome.
- **Editing flags**: Minor ordering variance between text-extracted Table 3 order vs image order (R2I row position) is layout choice, not error, noted above but flagged honestly. No watermarks, no inconsistent paste, no low-resolution screenshots. Reference bracket numbering continuous, but paper's claim of >$3M unprotected A2A volume explicitly marked unaudited in both §2.2.6 and §5 — editorial honesty preserved.

## Cross-check to summary.md
- Methodology PRISMA numbers (1373 → 1237 → 37+105, 1192 screened out) validated via page_005 left column text and §3.3 extraction.
- Topical buckets C0–C5 and synthesis D1–D5 validated via Figure 1 labels and §3.5.
- Kappa agreement 0.850/0.833/0.871 validated via page_005 left column paragraph.
- Five taxonomy dimensions D1–D5 enumerated exactly as Figure 1 boxes and §§4.1–4.5 headings.
- Twelve vectors and support levels validated Table 1 + Table 3 — one deviation noted: summary's T2T row should include Derived `Deng et al. [58]` (fix applied in tables.csv).
- Defense approach overhead levels Low/Medium/High/Very High/Infeasible validated Table 2; prose about crash headline sanitization risk, instruction hierarchy example ("never transfer more than 1 ETH"), runtime verification ZTRV/Agent-Sentry validated §5.1.1 text adjacent to Table 2.
- Protocol coverage gaps ("no single protocol covers all five dimensions") validated Table 4 N/A pattern and §5.3 first paragraph lines on page_012 left column.
- Layered defense 5 layers validated §5.4 text on page_012 left column — matches summary bullet list.

## Cross-check to tables.csv
- Extracted: Table 1 (12 rows with Direct/Derived citations), Table 2 (5 rows with Overhead colors), Table 3 (12 rows with Layer Path / Core Mechanism), Table 4 (8 rows × 6 cols). Qualitative tables fully transcribed verbatim including citation numbers and N/A annotations; not forced into numeric aggregates because source has no numbers. CSV preserves original cell content including bracket citations and "No released derived-support evidence" sentinel.

tables_csv: true (Tables 1–4 extracted verbatim).

