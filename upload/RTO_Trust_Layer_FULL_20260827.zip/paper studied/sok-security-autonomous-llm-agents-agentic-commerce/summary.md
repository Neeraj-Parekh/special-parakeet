# SoK: Security of Autonomous LLM Agents in Agentic Commerce

| Field | Value |
|---|---|
| **Authors** | Qian'ang Mao, Jiaxin Wang, Ya Liu, Li Zhu, Cong Ma, Jiaqi Yan |
| **Venue / Year** | arXiv preprint (arXiv:2604.15367v2), 2026. Affiliations: Nanjing University; Southern University of Science and Technology; City University of Hong Kong |
| **Type** | preprint (Systematization of Knowledge / survey) |
| **DOI / URL** | arXiv:2604.15367v2 (no DOI stated in text) |
| **Processed** | 2026-08-26T05:29:16Z |
| **Source PDFs** | 2604.15367v2.pdf (sha256 71057522) |

> Version 1 — generated from extracted PDF text.

## Abstract
> "Autonomous large language model (LLM) agents such as OpenClaw are pushing agentic commerce from human-supervised assistance toward machine actors that can negotiate, purchase services, manage digital assets, and execute transactions across on-chain and off-chain environments. Protocols such as the Trustless Agents standard (ERC-8004), Agent Payments Protocol (AP2), OKX Agent Payments Protocol (APP), the HTTP 402-based payment protocol (x402), Agent Commerce Protocol (ACP), the Agentic Commerce standard (ERC-8183), and Machine Payments Protocol (MPP) enable this transition, but they also create an attack surface that existing security frameworks do not capture well. This Systematization of Knowledge (SoK) develops a unified security framework for autonomous LLM agents in commerce and finance. We organize threats along five dimensions: agent integrity, transaction authorization, inter-agent trust, market manipulation, and regulatory compliance. From a systematically curated public corpus of academic papers, protocol documents, industry reports, and incident evidence, we derive 12 cross-layer attack vectors and show how failures propagate from reasoning and tooling layers into custody, settlement, market harm, and compliance exposure. We then propose a layered defense architecture addressing authorization gaps left by current agent-payment protocols. Overall, our analysis shows that securing agentic commerce is inherently a cross-layer problem that requires coordinated controls across LLM safety, protocol design, identity, market structure, and regulation. We conclude with a research roadmap and a benchmark agenda for secure autonomous commerce."

## Plain-Language Restatement
AI assistants are starting to shop, pay, and trade on their own, holding real wallets and payment credentials with no human approving each purchase. This paper collects everything known about how such autonomous agents can be attacked in commerce and finance, and organizes the threats into five buckets: corrupted agent reasoning, unauthorized transactions, trust between agents, market manipulation, and regulatory gaps. It identifies 12 concrete attack patterns where a weakness at one layer (e.g., a prompt injection) turns into harm at another (e.g., money leaving a wallet). Finally it proposes a five-layer "defense in depth" architecture and argues that no single payment protocol currently covers all the risks.

## Problem Statement
Security research on agentic commerce is fragmented across disconnected communities: LLM security (prompt injection/jailbreaks) treats finance as just another use case; blockchain security ignores LLM-controlled wallets; fintech/algorithmic-trading work assumes human oversight; multi-agent systems frameworks predate LLM agents. An autonomous financial agent is simultaneously an LLM, a payment-network actor, a regulated financial intermediary, and a multi-agent participant — no existing framework covers this full stack. The gap matters because billions of dollars may flow through agent-mediated channels with minimal human oversight, and a compromise at any layer can cascade across layers.

## Methodology
- **Approach**: Systematization of Knowledge (literature synthesis + threat taxonomy derivation + protocol comparison). Not an empirical ML paper.
- **Literature collection**: Searched Google Scholar and Web of Science using 23 phrases spanning agentic-commerce core terms, autonomous payments/protocols, delegation and authorization, MCP security, prompt injection and agent security, Web3 custody, financial LLMs, autonomous trading, historical agent-mediated e-commerce. Supplemented by backward snowballing plus targeted inclusion of protocol documents, regulatory texts, industry reports, implementation notes.
- **Selection criteria**: Include works directly addressing autonomous financial agents, agent-payment/settlement protocols, attacks/defenses relevant to autonomous execution, empirical evidence of agent behavior in financial settings, or theoretical foundations of trust/identity/authorization. Exclude generic LLM capability without financial-security relevance, traditional algorithmic trading without autonomy, non-technical policy discussion.
- **PRISMA-style flow numbers (as reported)**: database stage yielded 1,373 records → 1,237 candidates after DOI/title dedup → 37 works retained from databases + 105 additional via snowballing/targeted inclusion; 1,192 screened out. Public corpus spans 1994–2026.
- **Coding/reliability**: On a released 30-row blinded replication set, two independent coders assigned source/target layers; where both provided labels (17 rows), agreement was κ = 0.850 (source layer), κ = 0.833 (target layer), κ = 0.871 (joint ordered pair).
- **Taxonomy coding**: topical buckets C0–C5 (background/legal; LLM security & alignment; autonomous agent architectures; blockchain & DeFi security; fintech & algorithmic trading; multi-agent systems & mechanism design) and synthesis dimensions D1–D5.
- **Vector derivation**: three steps — (1) enumerate system layers (reasoning, tools, custody, inter-agent protocols, settlement, oracles, identity, compliance); (2) pairwise analysis of whether compromise at Li induces harm at Lj bypassing Lj's defenses; (3) consolidation into 12 named vectors, retaining paths with direct evidence.
- **Scope**: focuses on blockchain-based and API-based agentic commerce (MCP, x402, MPP, ACP); defines autonomy levels L0 advisory → L3 fully autonomous, focusing on L2 (delegated) and L3 (fully autonomous).

## Key Results
The paper's contributions are conceptual/framework-level:

**1. Five-dimensional threat taxonomy (D1–D5):**
- D1 Agent Integrity: prompt injection (direct data-feed, smart-contract metadata e.g. ENS/token fields/memos, inter-agent messages), model poisoning/backdoors, tool/plugin compromise, memory injection (write-path poisoning, retrieval manipulation, staleness exploitation).
- D2 Transaction Authorization: credential/key management for agents, spending policies/bounds, intent verification.
- D3 Inter-Agent Trust: agent identity/authentication (Sybil risk), negotiation integrity (LLM persuasion/anchoring exploits), collusion, cascading compromise via self-replicating "Prompt Infection".
- D4 Market Manipulation: agent-driven manipulation at machine speed (even emergent under profit-maximization alone), adversarial herding from correlated foundation models, sandwich/MEV attacks.
- D5 Regulatory Compliance: KYC/AML for non-human actors (US FinCEN BSA: CTRs > $10,000 cash, SARs ≥ $5,000; EU MiCA Regulation 2023/1114; FATF 2021/2023 VASP guidance), VASP classification (three-tier principal model: deployer KYC at deployment binding legal identity to agent DID; infrastructure operator runs AML monitoring; agent instance = automated execution process, not itself regulated), liability attribution, audit trails (must log the LLM reasoning behind transactions).

**2. Twelve cross-layer attack vectors:**

| ID | Name | Layer path | Core mechanism | Support level (paper's Table 1) |
|---|---|---|---|---|
| P2T | Prompt-to-Transaction | LLM → Blockchain | Injected prompt triggers signed tx | Direct |
| T2R | Tool-to-Reasoning | Tool → Reasoning | False data poisons decision | Direct |
| A2M | Agent-to-Market | Inter-agent → Market | LLM bias exploited in negotiation | Direct + derived |
| T2T | Tool-to-Transaction | Tool → Blockchain | Tool modifies tx params post-reasoning | Direct |
| P2K | Prompt-to-Key | LLM → Custody | Injection bypasses key custody boundary | Direct + derived |
| C2E | Collusion-to-Escrow | Multi-agent → Settlement | Colluding evaluators drain escrow | Direct + derived |
| O2P | Oracle-to-Position | Oracle → Portfolio | Cumulative drift via subtle feed manipulation | Direct + derived |
| N2C | Neg-to-Compliance | Protocol → Compliance | Structuring payments evades AML threshold | Direct + derived |
| I2M | Identity-to-Market | Reputation → Market | Sybil trust enables coordinated manipulation | Direct |
| S2I | Supply-to-Integrity | Supply chain → All | Backdoored plugin silently alters transactions | Direct + derived |
| M2A | Model-to-Authorization | Model → Authorization | Backdoor defeats spending policy check | Direct + derived |
| R2I | Reg-to-Integrity | Compliance → Market | Regulatory gap enables laundering | Direct + derived |

Paper flags P2T, T2R, T2T, S2I as most immediate deployment risks; C2E/O2P/N2C as slow-burn but hard to detect; R2I/M2A as more speculative early-warning categories.

**3. Protocol maturity assessment (as of early 2026):**
- ERC-8004, ERC-8183: Ethereum EIPs in draft/community review, limited on-chain deployment.
- AP2: research proposal, no widely adopted reference implementation.
- OKX APP: newly announced open standard/SDK; escrow and dispute resolution described as forthcoming; four payment intents defined (charge, escrow, session, upto) plus a Broker role.
- x402 (Coinbase-initiated): early adopter deployment, growing middleware ecosystem, not standardized.
- MPP (Stripe + Tempo): live Tempo mainnet deployment — judged the most operationally mature; challenge–credential–receipt flow over HTTP 402, charge and session intents, escrow-backed channels with off-chain signed vouchers.
- ACP (Virtuals): deployed but Virtuals-specific; four phases (negotiation with signed Proof of Agreement → escrowed transaction → evaluator-agent assessment → settlement). ERC-8183 generalizes it with Client/Provider/Evaluator roles and Job state machine Open→Funded→Submitted→Terminal; motivated by what its authors describe as over $3M of agent-to-agent transactions observed on Virtuals/ACP with no escrow/verification (figure noted as unaudited).
- Key comparative conclusion (Table 4): no single protocol covers all five dimensions; none simultaneously addresses LLM-layer compromise, long-horizon manipulation, and compliance.

**4. Defense approaches trade-offs:** input sanitization risks filtering legitimate market signals (e.g., a headline about a "crash"); output validation is called the most robust single defense but adds latency and must be secured against bypass; redundant reasoning multiplies cost and fails against shared-backbone vulnerabilities; formal verification deemed infeasible for full pipelines. MEV mitigation guidance: private RPC endpoints (Flashbots Protect / MEV Blocker) add zero submission latency but ~50–200 ms routing delay to next-block inclusion (acceptable for DCA/rebalancing); OFAs add a 300–800 ms auction window (unsuitable for latency-sensitive strategies).

**5. Layered defense architecture (§5.4):**
1. Prompt and Tool Hygiene (sanitize inputs, tag agent-originated content, verify tool provenance pre-invocation)
2. Verified Execution Context (output validation, runtime context binding, capability graphs)
3. Payment Authorization and Custody (**separate cognition from custody**, scoped spending policies at signing/credential layer, end-to-end parameter binding — ERC-8004 limits, AP2-style intents, OKX APP session keys, x402/MPP request binding/digests)
4. Inter-Agent Trust Controls (authenticated identity, stake-/reputation-backed evaluator selection, collusion/Sybil anomaly monitoring; evaluator mitigations: bonded evaluators with slashing, VRF-based Byzantine committee sizing, TEE attestation, approval-pattern anomaly monitoring)
5. Market and Compliance Monitoring (circuit breakers, cumulative position-drift detection, exposure aggregation, tamper-evident audit trails)

## Conclusions & Implications
Authors' claims:
- Autonomous financial-agent security is fundamentally a cross-layer problem: threats originate in reasoning/tools/identity/inter-agent interaction, but harm appears in custody, settlement, markets, or compliance.
- Agentic-finance risk is not the sum of traditional financial security plus generic LLM security; it arises from their interaction under irreversibility and low oversight.
- Assumptions like "a human can intervene," "prompt injection is a localized bug," and "on-chain finality implies correctness" do not hold for autonomous agents.
- Systemic risk from model/protocol homogeneity is underappreciated: shared foundation models mean one exploit can propagate market-wide.
- Research agenda: finance-specific benchmarks (AgentDojo/ASB omit finance attack classes; TraderBench/CAIA improve adversarial realism but don't integrate inter-agent trust and compliance), long-horizon monitoring metrics over days/weeks, mature inter-agent governance (evaluator selection, cryptographic identity, anti-collusion), and study of traditional payment rails/cross-chain settings.

For practitioners building payment/fintech AI systems: design mandates as scoped, task-bound, attenuating credentials rather than standing broad authority; keep an independent policy engine between model output and money movement; log reasoning provenance alongside transactions; treat agent reputation/trust scores as adversarial surfaces (Sybil, wash trading, cold-start); assume evaluator/third-party trust anchors will be attacked.

## Limitations
Acknowledged by authors:
- R2I and M2A vectors have fewer direct-support papers and are explicitly speculative/early-warning categories.
- Claims about proposed (not yet deployed) protocol features are explicitly speculative; some figures (e.g., the $3M unprotected A2A volume) are unaudited.
- Traditional payment rails and cross-chain operations are out-of-scope extensions, summarized only briefly.
- Independent reproduction of runtime-verifier controls in financial agentic settings remains an open experimental challenge; finance-specific benchmark harnesses don't yet exist.

Inferred by me:
- As a SoK, it contributes no original experiments; vector severity rankings rest partly on the authors' judgment over an uneven corpus (protocol marketing documents vs peer-reviewed work).
- Coverage is crypto/API-commerce centric; card rails, UPI-like systems, COD/e-commerce logistics, and consumer-protection angles get minimal treatment.
- Rapidly evolving protocol landscape means maturity assessments (early 2026) will date quickly.
- No quantitative measurement of attack success rates or defense efficacy in financial settings.

## Relevance to Our Hackathon
Highly relevant to the Razorpay track as the security blueprint for agent-initiated payments:
- **Machine-authentication of buyers**: the paper catalogs exactly which mechanisms exist to authenticate machine actors — challenge–credential–receipt flows (MPP), digest-bound request bodies preventing credential replay against modified API calls (MPP/x402), AP2 payment intents, OKX APP Broker verifying buyer credentials against stored challenges. A hackathon prototype for "prove this purchase was authorized by a real mandate" can borrow the challenge→credential→receipt pattern directly.
- **Consent & mandate design**: the core design rule — permissions must be attenuated, contextual, task-scoped (macaroons/object-capabilities lineage), with cognition separated from custody — maps to per-mandate spending caps, per-session limits, and revocable delegated payment credentials for shopping agents. This is a concrete spec for a consent-artifact/mandate engine.
- **Trust scores for agentic transactions**: D3 gives the failure modes any agent trust-score feature must resist (Sybil identities, reputation farming/wash trading, cold start, evaluator bribery/collusion) plus mitigations (bonded/staked evaluators with slashing, VRF committee selection, anomaly monitoring of approval patterns) — i.e., a checklist for making our trust score adversarially robust.
- **Fraud detection**: N2C (structuring payments under AML thresholds) and cumulative/slow-burn fraud (O2P oracle drift analog) motivate velocity/structuring detectors and longitudinal monitoring over days-weeks rather than single-transaction rules — directly applicable to imbalanced-data fraud models on agent-initiated payments.
- **RTO/COD angle (our transfer, not in paper)**: the paper doesn't discuss COD/RTO, but its insight that each individual action may be within policy while the aggregate is harmful ("adversarial herding" → portfolio-level circuit breakers) transfers to fleets of shopping agents placing many small COD orders — aggregate-level exposure caps and device/agent-fleet anomaly detection become the analogous control.
- **Explainability/audit**: D5's requirement to log the LLM reasoning behind each transaction supports our audit-trail/explainable-risk-story deliverables (tamper-evident logs linking intent artifact → model decision → payment).
