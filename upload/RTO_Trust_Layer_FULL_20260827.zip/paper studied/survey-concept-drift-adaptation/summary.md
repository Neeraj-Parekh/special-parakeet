# A Survey on Concept Drift Adaptation

| Field | Value |
|---|---|
| **Authors** | João Gama, Indrė Žliobaitė, Albert Bifet, Mykola Pechenizkiy, Abdelhamid Bouchachia |
| **Venue / Year** | ACM Computing Surveys (ACM CSUR), Vol. 46, No. 4, Article 44, March 2014 |
| **Type** | survey |
| **DOI / URL** | http://dx.doi.org/10.1145/2523813 |
| **Processed** | 2026-08-26T05:29:31Z |
| **Source PDFs** | 2523813.pdf — ACM published version, primary (sha256 prefix 120978bc); surv.pdf — earlier 2013 draft, secondary (sha256 prefix 82c1fd95) |

> Version 1 — generated from extracted PDF text.

## Abstract

"Concept drift primarily refers to an online supervised learning scenario when the relation between the input data and the target variable changes over time. Assuming a general knowledge of supervised learning in this article, we characterize adaptive learning processes; categorize existing strategies for handling concept drift; overview the most representative, distinct, and popular techniques and algorithms; discuss evaluation methodology of adaptive algorithms; and present a set of illustrative applications. The survey covers the different facets of concept drift in an integrated way to reflect on the existing scattered state of the art. Thus, it aims at providing a comprehensive introduction to the concept drift adaptation for researchers, industry analysts, and practitioners."

## Plain-Language Restatement

Machine-learning models trained on historical data slowly stop working when the world changes — customer behavior shifts, fraudsters adapt, markets move. This phenomenon is called concept drift. The paper is a comprehensive survey that organizes all known ways to detect such change and make models adapt online: how to manage memory (what old data to keep or forget), how to explicitly detect that a change happened, how to update or replace models, and how to fairly evaluate adaptive systems. It is written as a unified reference because prior literature on drift was scattered across fields with inconsistent terminology.

## Problem Statement

In nonstationary environments the joint distribution between input X and target y at time t, P_t(X, y), changes over time — priors p(y), class conditionals p(X|y), and posteriors p(y|X) may all shift — yet most learning research assumes stationarity and offline batch training. Prior to this survey no comprehensive drift survey existed (the most-cited predecessor dated from 2004 [Tsymbal]), terminology was not established, and similar adaptive strategies were developed under different names in different communities. The gap: a unified conceptual framework plus practical guidance on algorithms and, critically, on *evaluation methodology* for adaptive algorithms operating on streams where cross-validation breaks temporal order.

## Methodology

Survey methodology — integrated taxonomy organized around **four modules of any adaptive learning system** (memory, change detection, learning, loss estimation), designed as combinable components rather than a single method tree:

1. **Setting**: formalizes online adaptive loop = Predict → Diagnose (receive true label y_t, compute loss f(ŷ_t, y_t)) → Update model L_(t+1). Distinguishes offline / incremental / online / streaming modes.
   - **Drift types**: *real concept drift* = change in p(y|X); *virtual drift* = change in p(X) without affecting p(y|X). Only real drift requires adaptation via prediction feedback; virtual-drift/novelty/prior-shift techniques are noted but out of scope.
   - **Drift forms**: sudden/abrupt vs incremental vs gradual (with intermediate concepts), plus outliers/noise (once-off deviations that must NOT trigger adaptation), recurring concepts, and new concepts; characterized additionally by severity, predictability, frequency.
2. **Memory module**:
   - Data management: single-example (WINNOW multiplicative updates, VFDT/Hoeffding trees, STAGGER, DWM, SVM incremental, IFCS, GT2FC) vs multiple examples (FLORA family FIFO sliding windows; fixed-size windows; variable-size windows shrunk on detected change — FLORA2, Klinkenberg & Joachims SVM window sized by leave-one-out ςα-estimate).
   - Forgetting mechanisms: abrupt forgetting (sequence-based sliding windows, timestamp windows, landmark windows; reservoir sampling p = k/i as windowing alternative) vs gradual forgetting via fading factors S_i = G(X_i, α·S_(i−1)), exponential age weighting w_λ(X) = exp(−λ·j). Trade-off stated: more abrupt forgetting → faster reactivity → higher noise risk.
3. **Change-detection module** (four families):
   - *Sequential analysis*: SPRT log-likelihood ratio T^n_w > L; CUSUM g_t = max(0, g_(t−1) + (x_t − δ)) alarm if > λ; Page–Hinkley test PHT = m_T − M_T on cumulative deviation m_T = Σ(x_t − x̄_T − δ); Shiryaev's Bayesian thresholding. Memory O(1)/time O(1).
   - *Statistical process control (SPC/DDM-style)*: treat error as Bernoulli; monitor p_i + σ_i with σ_i = √(p_i(1−p_i)/i); Warning state at 95% level (p_i + σ_i ≥ p_min + 2σ_min), Out-of-Control/drift at 99% (≥ p_min + 3σ_min); distance Warning→Out-of-Control estimates rate of change. EWMA variant Z_t = (1−λ)Z_(t−1) + λe_t alarms when Z_t > μ0 + Lσ_Zt.
   - *Monitoring two distributions* (reference + detection window): Chernoff-bound tests (Kifer et al.), VFDTc leaf-vs-split-node distribution monitoring, entropy-based inequality metric (equal→1, different→0), KL divergence, paired stable/reactive learners (Bach & Maloof), short-window vs overall accuracy comparison (Nishida & Yamauchi), and **ADWIN** which keeps variable window W, splits into subwindows and drops older ones when means differ beyond Hoeffding bound ε_cut = √((1/2m)·ln(4|W|/δ)) using O(log W) memory via exponential histograms.
   - *Contextual approaches*: Splice system (timestamp as feature, decision-tree splits reveal contexts, per-context C4.5), IFCS prototype staleness w(i) = ζ^(t−a_t) with penalization and SPC criteria.
4. **Learning module**: retraining (periodic full rebuild on buffer) vs incremental adaptation vs streaming one-pass (VFDT, VFDTc, FIMT-DD freeze leaves under memory pressure); adaptation methods blind (fixed windows, weighting — proactive but slow reaction) vs informed/reactive (triggered global replacement, local replacement e.g. CVFDT alternate subtrees, sequential regularization pushing recent leaf statistics up to prune stale nodes); model management ensembles: dynamic combination (weighted majority/WINNOW), continuous update (Oza online bagging), structural update (add/remove experts); representative algorithms SEA (batch classifiers, worst discarded, majority vote), DWM (decrease weight β of wrong experts, add expert on ensemble error, remove below-threshold weights; AddExp pruning variant), Wang et al.'s weighted ensemble with w_i = MSE_r − MSE_i (MSE_r of random classifier = Σ_c p(c)(1−p(c))²), Learn++.NSE, boosting-like lift-controlled weights (Scholz & Klinkenberg), DDD low/high-diversity dual ensembles switched by internal drift detection, reoccurring-concept frameworks storing sleeping models selected by meta-learning (Gama & Kosina).
5. **Loss-estimation module**: model-dependent (SVM ςα leave-one-out estimates computed free after training; analytical loss for linear discriminants) vs model-independent (two sliding windows — short reactive vs long conservative; PH test applied to ratio of fading-factor error estimates, found somewhat faster than sliding windows in authors' experiments).

**Evaluation methodology** (a core contribution):
- Metrics: task-standard measures plus RAM-hours (computational cost; 1 GB × 1 h = 1 RAM-hour) and kappa statistic κ = (a − ar)/(1 − ar) convenient to compute online under class imbalance.
- Change-detector-specific metrics: probability of true change detection, probability of false alarms (better expressed as average run length / inverse time-to-detection), delay of detection (average number of instances after true change).
- Designs: holdout (unbiased when context known), interleaved test-then-train / prequential (S = Σ f(ŷ_t, y_t)) with landmark window, sliding window, or fading factors; controlled permutations (randomized stream copies preserving temporal locality to avoid overfitting data order); cross-validation over aligned series of related streams (one adaptive model per object).
- Significance: McNemar test on stream (M = sign(a−b)·(a−b)²/(a+b), χ² distributed); Nemenyi test after Friedman rejection for multiple learners (CD = q_α√(k(k+1)/6N)); Dunnett for control comparisons.
- Benchmarking: artificial datasets give ground truth drift points; warns against calling forced-drift real-world sets "real-world"; MOA (Java, WEKA-derived) demonstrated in Online Appendix C; datasets listed in Online Appendix B.

## Key Results

Conceptual/synthesis survey — key claims and frameworks rather than benchmark numbers:

| Framework | Content |
|---|---|
| Drift typology | Real (p(y\|X)) vs virtual (p(X)) drift; sudden/incremental/gradual forms; outliers must not be confused with drift; recurrence possible |
| Complexity table (Table II) | Sequential analysis & SPC: O(1) memory, O(1) processing (CUSUM, PH, SPC); two-window methods: O(log W)–O(W) memory/processing (ADWIN O(log W)) — more precise change localization but costlier |
| Detection thresholds | DDM/SPC warning at p+σ ≥ p_min + 2σ_min (95%), drift at +3σ_min (99%); ADWIN ε_cut = √((1/2m)ln(4\|W\|/δ)) |
| Diversity finding (citing Minku et al.) | Before drift, low-diversity ensembles have lower error; shortly after drift high-diversity ensembles win regardless of drift type; long after, diversity matters less |
| Detection-speed experiment note | Ratio-of-fading-factors PH detection "somewhat faster than sliding windows"; choice of α and window size critical |

Qualitative insights: (i) only drifts affecting predictions require adaptation; techniques handling real drift also cover virtual drift, not vice versa; (ii) blind adaptation forgets at constant speed regardless of whether change occurs — informed strategies react faster but depend on detector quality; (iii) granular models (trees/rules) allow local adaptation, cheaper than global replacement; (iv) Netflix winning team's lesson — temporal dynamics modeling was decisive; windowing alone is not best for every kind of changing behavior in collaborative filtering.

## Conclusions & Implications

Authors' claims: adaptive learning should be seen as modular composition of memory/change-detection/learning/loss components; evaluation must respect temporal order (prequential, controlled permutations) and report detector quality (false-alarm run length, detection delay), not just accuracy averages. Future directions named: exploiting recurring contexts and external context information (proactive rather than purely reactive detection), transfer learning between contexts, temporal relationship mining across distributed peers, representation-bias awareness in closed-loop/reinforcement settings, unsupervised and delayed/on-demand labeling regimes, scalability/robustness/reliability, interpretable ("non-black-box") adaptation to earn domain-expert trust, and moving from adaptive algorithms to fully automated adaptive knowledge-discovery systems.

For practitioners building payment/fintech AI systems: production fraud/RTO models are exactly the "monitoring and control" application category the survey names (anomalous/adversarial behavior in financial transactions). Concretely: wrap every production scorer in a loss-monitoring detector (DDM 2σ-warning/3σ-drift or ADWIN for memory-efficient localization); treat chargeback labels as delayed feedback (like credit scoring's fixed 1-year horizon — use fading factors/prequential sliding-window accuracy rather than holdout); prefer prequential test-then-train dashboards so accuracy-over-time plots reveal degradation that averages would mask; use McNemar/Nemenyi tests when A/B-ing retrained vs incumbent models; and remember the stability-plasticity trade-off when setting retraining aggressiveness (too reactive = chasing fraudster noise).

## Limitations

Acknowledged by authors:
- Focus restricted to real concept drift in supervised settings with feedback; does not cover virtual-drift/prior-shift/novelty handling except by pointer.
- Most surveyed work assumes hidden, unpredictable context → detection/handling mostly reactive; proactive exploitation of recurrent patterns still emerging.
- Representation bias unaddressed: in closed-loop/reinforcement settings historical replay cannot validate drift handling.
- Unsupervised learning over evolving data, and delayed/on-demand labeling validation, "only start to be investigated".
- Detector parameters (δ, λ for CUSUM/PH; α fading factor; window sizes) are user-defined and critical, controlling false-alarm vs missed-change trade-offs without universal defaults.

Inferred by me:
- Published 2014: predates deep-learning-era drift tooling (domain-adversarial networks, embedding-based drift detectors like MMD/KS on model features) and modern ML observability stacks; its detectors monitor scalar error streams, not multivariate representation shifts.
- No head-to-head quantitative comparison of detectors is performed inside the paper itself (the only experimental note concerns fading-ratio vs sliding-window speed).
- Examples are drawn from other domains (boilers, wind power, spam, news, NetFlix, DARPA Stanley); payment/fraud specifics (extreme imbalance interacting with drift) are not treated, though kappa is recommended for imbalance.
- The two source versions differ: surv.pdf is a January 2013 draft (placeholder DOI, 35 pages); the ACM March 2014 version (37 pages, Article 44) is authoritative and was used as primary here.

## Figures & Tables

All 9 figures + 5 tables verified visually from the primary ACM version (all vector, clean ACM typesetting; full log in figures.md):
- **Fig. 1** (p5, scatter panels): Original vs Real concept drift (p(y|X) changes — boundary moves) vs Virtual drift (p(X) changes, boundary fixed) — only real drift obsoletes the model.
- **Fig. 2** (p6, dot time series, y=data mean vs x=time): sudden/abrupt, incremental, gradual, reoccurring concepts, outlier (not drift) — defines the drift-form vocabulary.
- **Fig. 3** (p7, architecture diagram): Memory/Learning/Loss estimation/Change Detection modules wired as Predict(1)→Diagnose(2)→Update(3) loop with mandatory vs optional edges, outputs prediction + alarm.
- **Fig. 4** (p11, taxonomy overview): four color-coded modules and their sub-dimensions — combinable components, not a method tree.
- **Fig. 5** (p11, taxonomy tree): MEMORY = data management (single/multiple, fixed/variable window) × forgetting (abrupt: temporal sequence/sampling; gradual).
- **Fig. 6** (p14, taxonomy tree): CHANGE DETECTION = sequential analysis / control charts / monitoring two distributions / contextual.
- **Fig. 7** (p19, taxonomy tree): LEARNING = learning mode (retraining; incremental→online/streaming), adaptation (blind vs informed→local vs global replacement), model management (single/ensemble, recurrence, pool management).
- **Fig. 8** (p24, taxonomy tree): LOSS ESTIMATION = model dependent vs model independent (sliding window, fading factor).
- **Fig. 9** (p28, evaluation schematic): cross-validation across related data streams — series 1…N split training/testing per fold, training-validation series vs final test series.
- **Tables I–V** (pp14/19/20/24/25, citation-categorization tables): memory techniques, detector complexity (Table II: sequential/SPC O(1)/O(1); two-window O(log W)−O(W), ADWIN), change-detection techniques, learning techniques, loss-estimation techniques. Table II extracted to tables.csv.



Razorpay-track relevance:
- **Drift monitoring of production payment models** (our explicit angle): this is THE canonical blueprint. Implement DDM (95%/99% error-rate bands) and/or ADWIN wrappers around the RTO-risk and fraud scorers; emit Warning vs Drift alerts to trigger shadow-retraining pipelines; log average run length between false alarms and detection delay as MLOps SLOs.
- **Delayed ground truth = chargeback/RTO reality**: the survey's treatment of fixed-horizon label delays (credit scoring example) maps directly onto RTO outcomes arriving days/weeks after shipment; prequential sliding-window/fading-factor accuracy gives honest live performance without waiting for full label maturity.
- **Fraud as adversarial nonstationarity**: spammers adapting filters is the paper's own analogy for fraudsters probing rules; local replacement (CVFDT-style subtree swaps, sequential regularization) suggests surgically updating only affected model regions instead of full retrains during incident response.
- **Agentic payments reliability**: adaptive-model ensembles with weighted voting (w_i = MSE_r − MSE_i) and DDD-style diversity switching offer resilient backends for autonomous commerce agents whose risk scores gate transactions; interpretable adaptation (authors' trust discussion) supports merchant/consumer-facing explanations of why a block rule changed.
- **Evaluation rigor for demos**: adopt interleaved test-then-train + controlled permutations on replayed payment streams to prove our adaptive pipeline actually adapts (not just memorizes order), and report RAM-hours to argue deployment cost — judges see both correctness and ops realism.
