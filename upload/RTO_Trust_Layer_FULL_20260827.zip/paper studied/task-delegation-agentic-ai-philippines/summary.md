# AI agent, take over?! Task delegation to agentic AI systems in the Philippines

| Field | Value |
|---|---|
| **Authors** | Marc Hasselwander (Technical University of Berlin) |
| **Venue / Year** | AI & Society (Springer), 2026 — Received 3 Dec 2025 / Accepted 13 Apr 2026; © The Author(s) 2026, Open Access CC BY 4.0 |
| **Type** | journal article (empirical survey study / review-classified article) |
| **DOI / URL** | https://doi.org/10.1007/s00146-026-03060-3 |
| **Processed** | 2026-08-26T05:29:27Z |
| **Source PDFs** | s00146-026-03060-3-1.pdf (primary) — sha256 fb9aa56b; s00146-026-03060-3.pdf (identical duplicate, same sha256) |

> Version 1 — generated from extracted PDF text.

## Abstract

> "Agentic AI represents a fundamental shift from reactive AI systems (such as LLM-based chatbots) toward autonomous, goal-directed agents capable of decision-making, coordination, and task execution. This technological evolution is expected to reshape how individuals organize daily life, work, and information practices. At the same time, the rise of agentic AI raises important cultural, political, and ethical questions regarding human oversight and the redistribution of agency. This study provides early insights on how consumers anticipate delegating tasks to agentic AI and identifies heterogeneity in these expectations across user segments. Survey data from 407 experienced AI users in the Philippines were analyzed using latent class analysis (LCA) across 12 everyday and work-related activities. A four-class solution emerged, revealing segments of Creative Task Delegators (36.4%), Everyday Convenience Seekers (6.6%), Socially Oriented AI Agent Users (19.2%), and Web-Browsing Automators (37.9%). These distinct profiles illustrate differing orientations toward autonomy, trust, and cognitive offloading. The membership model highlights that age, socioeconomic status, social influence, and hedonic motivation are key factors shaping class membership, indicating that both socio-demographic characteristics and motivational orientations influence how individuals envision delegating tasks to autonomous AI agents. Overall, the findings of this study contribute to ongoing debates about responsible system design, governance, and the societal implications of increasing AI autonomy."

Keywords: Agentic AI · AI Super Assistant (AISA) · Consumer behavior · Technology adoption · Human–AI interactions · Latent class analysis (LCA) · AIDUA model.

## Plain-Language Restatement

Who would let an AI agent do what for them? The author surveyed 407 Filipinos who already use generative-AI tools and asked which of 12 tasks they'd hand to a fully autonomous agent. People split into four distinct groups: creative delegators (documents/presentations), everyday convenience seekers (commutes, reorders, smart home — but also most open to investment management), socially oriented users (translation, messaging, scheduling), and web-browsing automators (replacing Google). Notably, people are cautious about delegating money decisions, communication, and scheduling — tasks where trust, privacy, and responsibility feel risky. Age, socioeconomic status, social influence, and hedonic motivation predict which group you fall into.

## Problem Statement

Gap addressed: empirical evidence on consumer task-delegation preferences toward autonomous agentic AI is scarce — prior AI segmentation research examined only generative/domain-specific AI, and Southeast Asian markets are underrepresented despite strong Filipino interest in AI super assistants. Delegation entails varying levels of control transfer, trust, and perceived risk that are unlikely to be uniform across users, so population-level and segment-level evidence is needed for responsible design and governance.

## Methodology

- **Design**: cross-sectional online survey via professional panel provider, quota sampling against latest Philippine census distributions on age and gender; fielded July 2025; targeted experienced GenAI users (screening question + free-text experience description for ChatGPT/Gemini/DeepSeek use). None reported active use of autonomous agents — respondents were pre-adoption.
- **Sample**: N=407 valid after attention checks/quality screening. Table 3: Female 196 (48.1%) / Male 211 (51.8%); age 18–24 23.3%, 25–34 26.8%, 35–44 21.9%, 45–54 18.4%, 55–65 9.6%; SES: lower 12.8%, lower-middle 38.5%, middle 44.0%, upper-middle 3.9%, upper 0.5%; bachelor's degree 73.5%, master's/PhD 4.7%; employment: full-time 50.9%, part-time 8.6%, self-employed 16.5%, student 12.3%. High education share attributed to experienced-AI-user profile (PSA: 68.2% of laptop users hold university degrees).
- **Measures**: delegation = choose up to 3 of 12 literature-derived tasks (randomized order; "other" chosen by 3 respondents, recoded into predefined categories); adoption stage (Bamberg 2013 self-regulated stage model); latent constructs from Gursoy et al. (2019)/Ma & Huo (2023): social influence (4 items, α=0.886), hedonic motivation (3 items, α=0.949), novelty value (4 items, α=0.881), perceived humanness (4 items, α=0.911), performance expectancy (4 items, α=0.909), effort expectancy (4 items, α=0.862).
- **Analysis**: latent class analysis in R (poLCA package), one-step joint estimation of measurement + membership models; binary delegation indicators; covariates — age continuous, SES numeric (highest category had n=1), gender/education/employment binary; perception constructs as composite mean scores. CMB checks: procedural remedies (anonymity, separated sections, concise instrument); Harman's single-factor test first unrotated factor = 49% (<50% threshold); single-factor fit poor (RMSEA=0.39; TLI=0.18).
- **Class enumeration**: 2/3/4/5-class solutions compared on log-likelihood, AIC/AIC3, BIC, entropy, smallest-class size (see Results).

## Key Results

### Model fit (Table 4)

| Classes | Log-likelihood | AIC(AIC3) | BIC | Entropy | Smallest class % |
|---|---|---|---|---|---|
| 2 | −2167.447 | 4406.895 | 4551.212 | 1 | 36.36 |
| 3 | −2124.921 | 4369.842 | 4610.37 | 0.9663291 | 5.40 |
| 4 | −2093.935 | 4355.869 (AIC3) | 4692.61 | 0.967139 | 6.14 |
| 5 | −2185.064 | 4626.128 | 5139.256 | 1 | 2.21 |

Four-class retained (lowest AIC3, meaningful profiles, entropy 0.97 > 0.80 threshold; 5-class showed overfitting/deterministic classification).

### Segments and delegation probabilities (Table 5)

| Segment | Share | Signature probabilities |
|---|---|---|
| Class 1 — Creative Task Delegators | 36.36% (36.4% in abstract) | documents/presentations 1.000; research info 0.601; school/work help 0.405; commute planning 0.000 |
| Class 2 — Everyday Convenience Seekers | 6.55% (6.6%) | commute planning 0.658; online purchases/reorders 0.356; smart home 0.317; investments 0.304 |
| Class 3 — Socially Oriented AI Agent Users | 19.17% (19.2%) | school/work support 0.652; translation 0.562; scheduling 0.324; emails/messages 0.279; content creation 0.000 |
| Class 4 — Web-Browsing Automators | 37.92% (37.9%) | research information online 1.000; translation 0.516; school/work help 0.420; calendar 0.239 |

### Membership predictors (Table 6, reference = Class 1; ORs)
- Age → Class 3: OR=0.63, p<0.001 (younger respondents more likely).
- Social influence → Class 3: OR=1.65, p<0.01.
- Employment status (active employment) → Class 4: OR=0.46, p<0.01 (employed less likely).
- Socioeconomic status → Class 4: OR=1.43, p<0.01 (higher SES more likely).
- Hedonic motivation → Class 2: OR=0.11, p<0.01 (lower enjoyment-driven motivation more likely — pragmatic utility orientation).
- Gender, education, novelty value, perceived humanness, performance/effort expectancy: not statistically significant for any class.

Overall delegation pattern: highest willingness for cognitively oriented tasks (research, translation, study/work support, content creation); lowest for financial decision-making (investments 0.068–0.304 range across classes), personal communication, and scheduling — interpreted as reluctance where trust, privacy, or responsibility are sensitive. Both hypotheses supported (H1: latent technology perceptions shape segments; H2: socio-demographics shape segments).

## Conclusions & Implications

Authors' implications:
1. Consumers actively select which agency to transfer; expectations around productivity/human capability may shift as delegation normalizes.
2. Inequality risk: Web-Browsing Automators and Creative Task Delegators gain cognitive augmentation while others get only routine convenience; non-users face larger divides; AI trained on unequal data can amplify gaps → need for AI literacy and inclusive adoption strategies.
3. Governance: consent mechanisms, explainability features, and clear human-oversight boundaries are essential to preserve user agency and prevent overreliance; acting through AI reduces users' sense of responsibility (Gratch & Fast 2022), and anthropomorphism blurs accountability — governance must reinforce human responsibility and transparency.

For practitioners building payment/fintech AI systems: even among enthusiastic early adopters, money-task delegation is the least trusted category — so agentic payments products must be segment-aware: pitch automation to Everyday Convenience Seeker profiles, lead with control/explainability for everyone else; expect adoption heterogeneity by age, SES, employment, and social context (relevant to India's market analogous to the paper's emerging-economy framing).

## Limitations

Acknowledged by authors:
- Data collected July 2025, before ChatGPT "agent mode" (Aug 2025) and Claude browser extension (Dec 2025) — hypothetical scenarios with intention–behavior gap; stated optimism/uncertainty may not predict real usage.
- Predefined 12-task list may not capture full delegation diversity (though no new tasks emerged from "other").
- Cross-sectional design cannot capture evolution of delegation behavior over time.
- Binary delegate/not operationalization oversimplifies inherently partial, conditional, supervised, reversible autonomy transfer.
- Sample limited to existing GenAI users; excludes non-adopters and vulnerable groups (exclusion risks unmeasured).

Inferred (by me):
- Quota representativeness holds only for age/gender; education skew (73.5% degreed) limits generalization to the broader Philippine (or Indian) population.
- Choice-based up-to-3-of-12 task selection constrains covariance structure and forces relative trade-offs that may not reflect unconstrained preferences.
- Single-country sample; authors themselves call for replication in India, Brazil, Indonesia.
- Minor internal inconsistencies between abstract ("48.2% female; 49.5% aged 18–34") and Table 3 values (48.1% female; 50.1% aged 18–34).

## Relevance to Our Hackathon

Grounds our product/UX assumptions in data:

1. **Consent UX & trust segmentation**: The finding that financial decision-making is the least delegable task category quantifies the trust barrier our agentic-payments demo must overcome — design tiered consent with visible caps, undo/rollback, and human escalation rather than blanket authorization; target the Convenience-Seeker profile (low hedonic motivation, high utility orientation ≈ 6–7% of experienced users) as beachhead adopters.

2. **Explainability demand**: Authors explicitly list "consent mechanisms, explainability features, and clear boundaries of human oversight" as design essentials — direct citation support for our explainable RTO-blocking panel and mandate dashboards.

3. **Emerging-market analogy**: Philippines ↔ India parallels (mobile-first, socially endorsed adoption, young digitally engaged population; World Bank framing cited in paper) let us argue transferability of segment structure when sizing Indian merchant/consumer personas for agentic commerce.

4. **Feature prioritization for agent assistants**: Highest-demand tasks (information search/synthesis, document creation, translation) suggest our merchant-facing agent should start as research/report copilots before touching money movement — matching observed risk tolerance gradients.

5. **Method transfer**: The LCA one-step pipeline is reusable: run the same 12-item (payment-augmented) survey on Indian merchants to segment agentic-product go-to-market empirically during/after the hackathon.
