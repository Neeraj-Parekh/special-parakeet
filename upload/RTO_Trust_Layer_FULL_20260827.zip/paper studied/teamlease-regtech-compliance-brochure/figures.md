# Figures & Tables Log — teamlease-regtech-compliance-brochure

Source key: `89701fba56d2` (2-page "File Viewer.pdf"). Visual read of `page_001.png`, `page_002.png`, `img_p001_135.png`, `img_p001_136.png`.

## Figures
**None.** No charts, diagrams, or data figures anywhere in the artifact. Non-content graphic elements:

| ID | Page | Type | Construction inference | Content as shown | Takeaway | Quality observations | Supports |
|---|---|---|---|---|---|---|---|
| viewer-toolbar | p.1 (capture) | UI chrome | rasterized web UI | pager "1 of 2 pages" with first/prev/next/last arrows | hosted document has 2 pages | crisp | Artifact characterization (viewer capture, not brochure) |
| enquire-rail | p.1 | UI chrome | rasterized web UI | "Enquire Now" vertical tab; phone and bookmark buttons | vendor lead-gen rails | crisp | Vendor-context characterization |
| ria-assistant | p.1–2 | UI chrome | rasterized web UI | avatar + input "Ask Ria anything..." labeled "✦NEW · AI ASSISTANT" | vendor ships an AI assistant for compliance Q&A | crisp | RegTech productization observation in summary |
| teamlease-footer | p.1–2 | text block/UI | rasterized web UI | CIN U74999PN2018PTC179553; "Formerly - Avantis RegTech Pvt. Ltd."; Kakade Bizz Icon, Shivajinagar, Pune 411005; 9899245318; sales@tlregtech.com; city list; social icons f/in/YouTube; Terms/Privacy; © TeamLease Regtech Pvt Ltd | vendor identity | crisp | Header-table author/venue fields |
| npci-letterhead | hosted scan p.1 | logo/wordmark | raster scan | NPCI logo + Devanagari line, top-right of circular | authenticates hosted circular | slightly soft (reduced-res scan) but legible | Hosted-document provenance |

## Hosted document pages (the substantive images)
| File | Page | Content | Quality |
|---|---|---|---|
| img_p001_135.png | hosted 1/2 | NPCI/UPI/OC No.201/2024-25, 13 Aug 2024; subject "Introduction of 'UPI Circle' – Delegated Payments for secondary users"; motivation paragraph; UPI Steering Committee 3 Aug 2023 endorsement; Full/Partial Delegation definitions; guidelines 1–4 (+3a); BKC address footer | reduced-resolution scan; text legible, slightly soft; decorative diagonal lines |
| img_p001_136.png | hosted 2/2 | guidelines 5–13; "UPI Circle Procedural Guidelines" referral; signature SD/- Kunal Kalawatia, Chief of Products | legible; guideline 13 has unexplained asterisk after "remitter bank*" with no visible footnote |

Key numbers readable from the hosted scans: ₹15,000/- max monthly per delegation (full delegation, item 7); ₹5000 max per transaction (item 7); ₹5000 daily limit during first-24-hours cooling after linking (item 9, both modes); up to 5 secondary users per primary (item 4); one primary per secondary (item 4).

## Tables
**None.** All guidelines are numbered prose; no numeric tables exist, so no tables.csv was produced.

## Cross-checks
- Hosted circular's caps/cooling match the OC 201-B addendum (sibling folder): ₹15,000 monthly, ₹5,000 per transaction, 24h ₹5,000 — carried forward.
- OC 201-B adds: IoT/software eligibility, explicit-user-action debit trigger, proximity at linking, issuer-side per-transaction device/user-ID validation, purpose code named 'BH', 6-month inactivity auto-revoke, 5 IoT devices limit.
- Capture print stamp: 8/26/26, 12:03 (both pages); source URL truncated at `?f=https%3A%2F%2Ftrplprodcompliance.bl...` — provenance gap recorded.
