# Research Requests — teamlease-regtech-compliance-brochure

- [High] Obtain the canonical NPCI PDF of OC 201/2024-25 and the "UPI Circle Procedural Guidelines" it references; verify the scan recovered from this capture word-for-word (especially guideline 13's unexplained asterisk after "remitter bank*") before any compliance reliance.
- [High] Build the OC 201 → OC 201-B diff view as a hackathon artifact: side-by-side guideline cards highlighting the genuinely new IoT addendum elements (device validation, proximity, explicit action, 'BH' code) vs carried-forward rules (₹15,000/₹5,000 caps, 24h cooling, ODR).
- [Med] Prototype the Full-vs-Partial delegation mode picker for an agent checkout: autonomous completion (Full, ₹5,000/txn cap) vs agent-initiates/human-PIN (Partial, existing UPI limits); measure completion-rate and trust-survey differences.
- [Med] Implement the primary-user visibility duty (guideline 10) as a feature: a delegated-spending timeline in the merchant dashboard and a bank-statement-style export for principals; usability-test with 5 mock principals.
- [Med] Evaluate vendor-hosted regulatory copies as a data source: scrape 5 RegTech sites hosting NPCI circulars, compare against originals, and quantify text drift/scan-quality risk; propose a provenance-scoring rubric.
- [Med] Model the contact-list-only linking restriction (guideline 3/3a): simulate fraud-agent onboarding with and without manual mobile entry to estimate how much the restriction reduces delegated-account takeover.
- [Low] Reproduce the biometrics mandate (guideline 2) in a mock secondary-user app and measure added authentication latency and failure rates across face/fingerprint/passcode paths.
- [Low] Survey RegTech vendor AI assistants (e.g., TeamLease's "Ask Ria") on regulatory Q&A accuracy about UPI Circle; benchmark answers against this knowledge base's primary-source transcriptions.
- [Low] Track the Net Settlement Report line item and additional raw file introduced by guideline 13: design a reconciliation dashboard mock for UPI Circle flows that a PSP ops team could actually use.
