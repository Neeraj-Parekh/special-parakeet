# File Viewer.pdf — TeamLease Regtech File Viewer capture hosting NPCI/UPI/OC No.201/2024-25 ("UPI Circle" circular)

| Field | Value |
|---|---|
| **Authors** | None (non-research collateral). Viewer page by TeamLease Regtech Pvt. Ltd. (formerly Avantis RegTech Pvt. Ltd.); substantive content is a scanned NPCI circular signed Kunal Kalawatia, Chief of Products, NPCI |
| **Venue / Year** | teamleaseregtech.com File Viewer web capture; hosted circular dated 13 August 2024; capture printed 26 August 2026 |
| **Type** | whitepaper — honestly documented as **non-research collateral**: a print capture of a vendor's document-viewer web page; its substantive payload is a scanned regulatory circular (NPCI OC 201), not vendor research |
| **DOI / URL** | https://teamleaseregtech.com/fileviewer/?f=https%3A%2F%2Ftrplprodcompliance.bl… (URL truncated in capture) |
| **Processed** | 2026-08-26T09:51:41Z |
| **Source PDFs** | File Viewer.pdf (sha256 374e5dca…); text layer is website chrome only — substantive content recovered visually from embedded page scans |

> Version 1 — generated from extracted PDF text + visual transcription of page renders and embedded scan images.

## Abstract

*(No abstract — this is not a research document. What the artifact is, stated plainly:)* A 2-page print-to-PDF of TeamLease Regtech's "File Viewer" web tool. Page 1 shows the viewer UI (page pager "1 of 2", "Enquire Now" rail, "Ask Ria anything… ✦NEW · AI ASSISTANT" chat widget, TeamLease contact footer: CIN U74999PN2018PTC179553, Pune address, sales@tlregtech.com) around the first page of the scanned circular **NPCI/UPI/OC No.201/2024-25 dated 13th August 2024 — "Introduction of 'UPI Circle' – Delegated Payments for secondary users"**. Page 2 is the TeamLease site footer (city list, newsletter, legal links). The complete hosted circular is legible in the PDF's two embedded scan images and is transcribed below under Key Results because it is the parent instrument of NPCI OC 201-B (processed separately in this knowledge base).

## Plain-Language Restatement

This file looks like a vendor brochure but is actually a screenshot-like capture of an Indian RegTech company's online document viewer, which the team used to host a scan of the 2024 UPI circular that invented "UPI Circle" — the feature letting a UPI user authorize family members (and, from 2025, devices and AI software) to pay on their behalf. The research value here is the recovered full text of that parent circular plus evidence of how RegTech vendors distribute regulatory documents.

## Problem Statement

*(Not applicable — non-research collateral.)* The artifact documents no research problem. Its practical role in our corpus: it is the only source in the knowledge base containing the **full text of the parent circular OC 201 (Aug 2024)**, which OC 201-B (Oct 2025) amends, and the Lexology analysis interprets. It also incidentally demonstrates RegTech vendor practice: regulatory documents surfaced through a web viewer with an AI assistant ("Ask Ria") and lead-generation ("Enquire Now") rails.

## Methodology

*(Not applicable — no research method.)* Document structure instead:
- Page 1: viewer chrome + NPCI circular scan page 1 (ref NPCI/UPI/OC No.201/2024-25, 13 Aug 2024; subject; motivation — cash-dependent users who "do not manage their own money through their own account"; UPI Steering Committee endorsement of 3 August 2023; Full vs Partial Delegation definitions; guidelines 1–4).
- Page 2: TeamLease footer only (locations Bangalore, Mumbai, Kolkata, Hyderabad, Delhi, Chennai, Ahmedabad; Terms of Service / Privacy Policy; © TeamLease Regtech Pvt Ltd).
- Embedded images `img_p001_135.png` / `img_p001_136.png`: the complete two-page circular scan (guidelines 1–13, signature block).

## Key Results

*(Recovered normative content of NPCI OC 201/2024-25 from the embedded scans — the artifact's substantive payload:)*
- **Definitions**: Full Delegation — primary authorizes a secondary user to initiate *and complete* UPI transactions within defined spend limits. Partial Delegation — secondary initiates payment requests; primary completes with UPI PIN.
- **Guidelines (13)**: (1) independent user journeys for primary/secondary; own choice of UPI app. (2) App passcode/biometrics (finger/face) mandatory for all secondary users. (3) Linking via QR scan or UPI-ID entry plus contact-list selection; later phase: contact-list selection only; manual mobile-number entry restricted (3a). (4) Primary may delegate to up to **5 secondary users**; a secondary accepts delegation from only **one primary**. (5) Authorization on either full or partial delegation. (6) Primary gets limit controls over secondaries. (7) Full delegation caps: **₹15,000/- monthly per delegation; ₹5,000 per transaction**. (8) Partial delegation: existing UPI limits apply. (9) Cooling period: first **24 hours** after linking, daily limit **₹5,000** (both modes). (10) Primary visibility of secondary transactions in UPI App and bank statement. (11) RBI TAT/customer-compensation guidelines (20 Sep 2019) apply. (12) ODR functionality available. (13) Reconciliation per existing UPI guidelines; **new purpose code** in UPI raw file and new line item in the Net Settlement Report identify UPI Circle transactions; additional raw file with secondary-user details shared with primary PSP, secondary PSP and remitter bank.
- Referral: "Members are advised to refer to UPI Circle Procedural Guidelines for detailed information." Signed SD/- **Kunal Kalawatia, Chief of Products**.
- Continuity check vs OC 201-B (Oct 2025): monetary limits (₹15,000/₹5,000), 24-hour ₹5,000 cooling, one-primary rule, RBI TAT + ODR + raw-file machinery all carried forward; OC 201-B names the purpose code 'BH', adds device/issuer validation duties, and extends eligibility from human secondaries to IoT devices and software profiles.

## Conclusions & Implications

No author conclusions (collateral). Working implications for our corpus: (1) OC 201 is the baseline against which every OC 201-B change should be diffed — the addendum's genuinely new elements are IoT/software eligibility, explicit-action debit trigger, device-proximity linking, issuer-side per-transaction device validation, and the named 'BH' purpose code; (2) the Full-vs-Partial delegation taxonomy originates here and is the correct vocabulary for agent-payment designs (an autonomous agent maps to Full Delegation with its caps; a human-confirming flow maps to Partial Delegation semantics); (3) TeamLease Regtech's viewer (AI assistant "Ria", compliance solution categories: Tracking/Automating/Auditing Compliance) is evidence that RegTech distribution of regulatory circulars is itself productized — relevant background for any compliance-tooling pitch.

## Limitations

*(Acknowledged by authors)*: none stated — non-research collateral; the circular itself defers detail to the separate "UPI Circle Procedural Guidelines" (not in our corpus).
*(Inferred by me)*: the capture is a print of a viewer page, so the hosted scan is reduced-resolution (page-1 text slightly soft but legible; page-2 scan legible); the source URL is truncated, breaking provenance back to the exact hosted file; the capture is undated except for the print stamp (8/26/26, 12:03); no TeamLease-authored substantive claims exist to evaluate, so nothing here should be cited as vendor research; the circular scan's guideline 13 carries an unexplained asterisk after "remitter bank*" with no visible footnote.

## Relevance to Our Hackathon

(1) Supplies the **parent-rule baseline** for any OC 201-B compliance feature: build the OC 201 vs OC 201-B diff view so judges can see exactly what the IoT addendum changes; (2) the Full/Partial Delegation definitions are the correct design vocabulary for agentic checkout — pitch an agent flow as "Full Delegation within ₹15,000/₹5,000 caps" or a human-in-the-loop flow as Partial-Delegation-like (agent initiates, human completes with PIN); (3) the 13 original guidelines (biometrics for secondaries, contact-list-only linking, primary visibility, statement transparency) are a ready-made trust/consent feature checklist for family-account or agent-account products on Razorpay-style stacks; (4) methodological caution worth stating in any writeup: this folder documents a **non-research source** — a reminder to verify vendor-hosted regulatory copies against NPCI originals before relying on them.

## Figures & Tables

- No figures or tables in either the viewer capture or the hosted circular. Non-content graphics: NPCI logo (scan pages), TeamLease viewer UI icons (pager arrows, phone/bookmark buttons), "Ask Ria" AI-assistant avatar/chat bar, social icons (Facebook/LinkedIn/YouTube), footer navigation. Numeric limits exist only in prose guidelines (₹15,000, ₹5,000, 24h, 5 users) — no numeric tables, so no tables.csv.
