# Research Requests — tfx-production-scale-ml-platform

- [High] Build the six-stage TFX-style CI/CD pipeline for the hackathon RTO model (profile → schema-validate → transform-in-artifact → train → canary-gate → serve) using lightweight OSS equivalents; measure end-to-end run time and demonstrate blocking one deliberately corrupted batch and one deliberately regressed model.
- [High] Inject a synthetic training-serving skew (drop two features from the scoring request log that exist at training time), then reproduce the paper's detection method by diffing same-day training vs serving feature-presence statistics; quantify offline-vs-online score degradation before fixing.
- [Med] Implement canary promotion comparing each daily retrain against the incumbent RTO model head-to-head plus fixed AUC/cost-weighted-error thresholds; log how many candidate models were blocked over N simulated days and estimate incident-prevention value.
- [Med] Add slice metrics by merchant category, COD-vs-prepaid, and pin-code tier; find at least one slice where aggregate AUC improves but slice performance degrades, mirroring the paper's small-slice warning.
- [Med] Test warm-starting for weekly fraud-model refreshes: compare convergence time and final AUC versus cold training on a rolling 90-day window; report compute cost saved.
- [Med] Reproduce the load-isolation result qualitatively: serve the RTO model behind an API while reloading a new artifact mid-traffic; measure p99.9 latency during reloads with shared vs dedicated loading workers.
- [Low] Auto-generate the first data schema from a sample of historical orders and track its version history over simulated data evolution; evaluate false-alert rate when distribution constraints use loose vs tight thresholds (paper's alert-fatigue tension).
- [Low] Prototype config-free default-on validation (paper's stated plan): enable schema+canary gates by default for every team notebook push in the demo repo and record adoption friction.
- [Low] File data anomalies as real tracked issues (paper's treat-data-errors-as-bugs principle) in the hackathon repo and measure mean time-to-resolution versus ad-hoc Slack reporting.
