# TFX: A TensorFlow-Based Production-Scale Machine Learning Platform

| Field | Value |
|---|---|
| **Authors** | Denis Baylor, Eric Breck, Heng-Tze Cheng, Noah Fiedel, Chuan Yu Foo, Zakaria Haque, Salem Haykal, Mustafa Ispir, Vihan Jain, Levent Koc, Chiu Yuen Koo, Lukasz Lew, Clemens Mewald, Akshay Naresh Modi, Neoklis Polyzotis, Sukriti Ramesh, Sudip Roy, Steven Euijong Whang, Martin Wicke, Jarek Wilkiewicz, Xin Zhang, Martin Zinkevich (Google Inc.) |
| **Venue / Year** | KDD '17 (Applied Data Science track), August 13–17, 2017, Halifax, NS, Canada |
| **Type** | conference paper |
| **DOI / URL** | http://dx.doi.org/10.1145/3097983.3098021 |
| **Processed** | 2026-08-26T05:29:23Z |
| **Source PDFs** | TFX_A_TensorFlow-Based_Production-Scale_Machine_Le.pdf + sha256 0b130052 |

> Version 2 — v2 full-read verification pass (2026-08-26): full sequential read of cached .txt (1097 lines) + visual inspection of 3 rendered pages (2 figures); all header/abstract/numeric claims re-verified verbatim.

## Abstract
"Creating and maintaining a platform for reliably producing and deploying machine learning models requires careful orchestration of many components—a learner for generating models based on training data, modules for analyzing and validating both data as well as models, and finally infrastructure for serving models in production. This becomes particularly challenging when data changes over time and fresh models need to be produced continuously. Unfortunately, such orchestration is often done ad hoc using glue code and custom scripts developed by individual teams for specific use cases, leading to duplicated effort and fragile systems with high technical debt. We present TensorFlow Extended (TFX), a TensorFlow-based general-purpose machine learning platform implemented at Google. By integrating the aforementioned components into one platform, we were able to standardize the components, simplify the platform configuration, and reduce the time to production from the order of months to weeks, while providing platform stability that minimizes disruptions. We present the case study of one deployment of TFX in the Google Play app store, where the machine learning models are refreshed continuously as new data arrive. Deploying TFX led to reduced custom code, faster experiment cycles, and a 2% increase in app installs resulting from improved data and model analysis."

## Plain-Language Restatement
Google built an assembly line called TFX that takes raw data and turns it into a live, automatically-refreshed prediction service without hand-written glue scripts. The pipeline analyzes data statistics, validates incoming data against a schema, transforms features consistently for training and serving, trains models (reusing previous model parameters to save time), blocks bad models before they go live, and serves predictions at low latency. On Google Play's app recommender this cut deployment time from months to weeks and raised app installs by 2% just by finding and fixing a data skew bug.

## Problem Statement
Production ML requires orchestrating learners plus data/model analysis, validation, and serving infrastructure — yet teams typically do this ad hoc with glue code and per-team scripts, causing duplicated effort and fragile systems with high technical debt (citing Sculley et al.'s hidden technical debt). Four complications must be handled: one platform serving many different learning tasks; continuous training/serving over evolving data (e.g., moving window over latest n days of logs); human-in-the-loop usability across expertise levels; and production-level reliability/scalability against inconsistent data, software, configurations and failures.

## Methodology
System/architecture paper describing TFX's component anatomy, design principles, and a production case study (no controlled experiments or statistical tests; empirical numbers come from operations):
**Design principles**: (1) one platform for many tasks (TensorFlow trainer supports linear/deep/wide-and-deep/tree-based/sequential/multi-tower/multi-head architectures; all other tools support sparse, dense, sequence data and regression/classification/sequence inference); (2) continuous training via data-visitation strategies (static vs dynamic rolling range of directories) × warm-starting options; (3) unified single configuration passed to all components, shared utilities (global garbage-collection policies, unified debugging/status signals); (4) production reliability — model validation coupled with data validation; Apache Beam's distributed processing model for training-scale data, evaluation and batch inference.

**Component pipeline (the TFX stack)**:
1. **Data Analysis**: generates descriptive statistics per dataset — feature presence (distribution of number of values per example; counts with/without feature), continuous-feature stats (quantiles, equi-width histograms, mean, standard deviation), discrete-feature stats (top-K values by frequency), configurable slices (e.g., negative vs positive class), cross-feature statistics (correlation, covariance); uses distributed streaming approximation algorithms (HyperLogLog cited) at scale since exact computation is infeasible.
2. **Data Transformation**: feature wrangling incl. vocabulary generation (feature-to-integer mappings; ~1–100B unique values per sparse feature, so IDs assigned only to most frequent/relevant values; others dropped or mapped to fixed out-of-vocab IDs). Crucially, transformations are **exported as part of the trained model**, guaranteeing identical train/serve transformation logic (prevents training-serving skew).
3. **Data Validation**: versioned schema encoding — expected features present, expected type, expected presence (minimum count & fraction of examples), expected valency (min/max values per example), expected domain (value universe for strings / range for integers), optionally distribution constraints and value interpretations. Anomalies flagged with simple actionable descriptions (deliberately avoiding opaque alerts like KL-divergence thresholds), each anomaly paired with either a suggested fix or an auto-generated schema update when change reflects legitimate data evolution; problematic features can be marked "deprecated"; anomalies filed/tracked like software bugs; first schema auto-generated from a data sample; teams own schema maintenance.
4. **Trainer**: minimal-effort integration of TensorFlow modeling code; warm-starting selectively initializes chosen parameters (e.g., sparse-feature embeddings) from the previous model version — inspired by transfer learning — enabling quick convergence over O(100B)-example datasets; high-level API (FeatureColumns declarative input layers; Estimator handling local/distributed train+eval; example config: `DNNRegressor(hidden_units=[256,128,64], embedding_column(zip_code, 8), activation_fn=relu, dropout=0.1)`; categorical hashing with hash_bucket_size=1K); guidance to establish a simple baseline first (Rule #4); integrated tuner for hyper-parameter optimization.
5. **Model Evaluation & Validation**: defines "good" = safe-to-serve (loads without crashing, handles bad/unexpected inputs, bounded CPU/RAM, compatible library versions) + desired quality; offline evaluation via proxy metrics (AUC, cost-weighted error) approximating business metrics to gate A/B experiments; automated canary-based validation comparing each candidate against fixed thresholds AND the current production baseline; failing models are not pushed and teams alerted; **slicing** computes metrics on data subsets (e.g., Country=US), protecting small-slice performance that aggregate metrics hide.
6. **Serving (TensorFlow Serving)**: multitenancy with soft model isolation; dedicated threadpool (size 1–2 optimal) separating model-load processing from request processing; tensorflow.Example protobuf as common data format with a specialized lazy parser that skips unneeded proto parts and minimizes copying, guided by real-data-distribution profiles plus a regression benchmarking suite.

**Case study setup (Google Play)**: homepage app recommendation; corpus >1 million apps, >1 billion active users; two-stage retrieve→rank; ranking model trained continuously on batches of hundreds of billions of examples (query + impression features); deployed globally through TensorFlow Serving, collectively thousands of queries/second under strict tens-of-milliseconds latency; multiple models reloaded daily.

## Key Results

**Platform-level outcomes (Google Play case study):**

| Outcome | Reported result |
|---|---|
| Time to production | Reduced from order of months to weeks |
| Custom code | Reduced |
| Experiment cycles | Faster |
| App install rate (main landing page) | **+2%** from removing a discovered training-serving feature skew (confirmed by online A/B experiment) |
| Serving scale | Thousands of QPS globally, strict latency of tens of milliseconds, multiple model reloads/day with no latency degradation |

**Serving optimizations:**

| Optimization | Before | After |
|---|---|---|
| Dedicated model-load threadpool: p99.9 inference latency during model loads | ~500 to ~1500 msec | ~75 to ~150 msec |
| Specialized lazy protobuf parser speedup (benchmarked datasets) | baseline | **2–5× faster** |

**Qualitative findings:**
- Data Analysis+Validation uncovered a harmful training-serving skew: several features always missing from serving logs but always present in training data (same-day comparison of log vs training statistics).
- Warm-starting resolved the quality-vs-freshness trade-off (training from scratch takes days over hundreds of billions of examples); enabled frequent pushes of high-quality fresh models.
- Model validation prevented accidental pushes of partially trained models after system failures and helped troubleshoot old-vs-new performance differences.
- User-attitude discovery: no product team requested validation initially and few enabled it; adoption only followed a real production incident it would have prevented — motivating plans for configuration-free, default-on validation.
- Validation-threshold tension: loose thresholds catch most dramatic bugs but subtle issues may go unnoticed (authors acknowledge selection bias in this observation).

## Conclusions & Implications
Authors claim that integrating data analysis/transformation/validation, training, evaluation/validation and serving into one standardized platform reduces glue-code debt, shortens time-to-production and improves product metrics; remaining challenges are extensibility to new model families (e.g., sequence-to-sequence affecting data format, serving and validation) and model understandability/explainability. For practitioners building payment/fintech AI systems: adopt the same component checklist rather than ad-hoc scripts — schema-validate every retraining batch, export preprocessing inside the model artifact to eliminate train/serve skew, gate promotion with canary comparisons against the incumbent model plus slice-level metrics (critical where small customer segments matter), use warm-starting for fast fraud-model refreshes, and isolate model-loading from request-serving threads/processes to protect tail latency.

## Limitations
*(Acknowledged)*: canary checks cannot catch all errors; distinguishing expected vs unexpected behavior change in continuously-trained models is hard (alert fatigue vs missed subtle regressions; possible selection bias toward dramatic bugs); complex schema properties involve hard-to-tune thresholds; TensorFlow-centricity acknowledged ("platform design is not limited to this specific library" is aspiration). *(Inferred)*: results reported from one flagship deployment (Google Play) — no multi-team quantitative rollout data; the 2% install-rate lift is confounded with other concurrent improvements (not isolated beyond its A/B); infrastructure costs of the platform are not quantified; 2017-era stack predates modern open-source TFX/Kubeflow Pipelines evolution; explainability explicitly deferred as future work.

## Figures & Tables
- **Figure 1** (p1389) — architecture diagram: high-level ML platform overview spanning Data Ingestion → Logging with shared frontend/config/utilities/storage layers; bracket marks Focus of this paper (Data Analysis through Serving); no numbers, illustrates six core pipeline stages + Tuner.
- **Figure 2** (p1390) — schema-validation schematic: example with category='EDUCATION' and num_impressions='NULL' validated against schema (category STRING REQUIRED domain {GAMES,BUSINESS}, num_impressions INT) → 2 anomalies: evolution fix (add EDUCATION to domain) vs bug fix (deprecate num_impressions); takeaway is actionable vs evolution dichotomy.
- No data tables (2 figures only); numeric results are in-text (p99.9 latency 500–1500→75–150 ms, parser 2–5× speedup, +2% installs). Full log: figures.md; extracted metrics: tables.csv.

## Relevance to Our Hackathon
The canonical blueprint for **reproducible CI/CD pipelines for the RTO/fraud risk model**:
- **Component checklist → hackathon pipeline stages**: mirror TFX's six components with lightweight equivalents: pandas-profiler/whylogs-style statistics → Great Expectations/Pandera schema validation (presence, type, valency, domain of order/courier/customer features) → sklearn/xgboost trainer → offline AUC + cost-weighted-error gates + slice metrics (by merchant category, pin-code, COD/prepaid) → FastAPI/TFServing endpoint.
- **Train/serve skew prevention**: ship preprocessing inside the model artifact exactly as TFX exports transformations with the model — directly addresses the classic fraud-model failure where training features differ from request-time features; the paper's +2% install-rate win came purely from fixing such a skew, a persuasive story for our demo.
- **Promotion gates**: implement canary validation — new RTO model must beat the incumbent on fixed thresholds and head-to-head comparison before deployment; block partially-trained artifacts.
- **Warm-starting**: reuse previous model's parameters/embeddings for daily refreshes instead of cold training — cuts compute cost (ties into cost-aware infra track).
- **Slice monitoring**: aggregate AUC hides small-segment failures; slice-wise metrics prevent shipping models that sacrifice e.g. small-town COD shipments.
- **Tail-latency engineering**: separate model-loading from request-handling resources (paper cut p99.9 during loads from ~500–1500 ms to ~75–150 ms) — applicable whenever we hot-reload retrained fraud models without dropping payment-path latency.
