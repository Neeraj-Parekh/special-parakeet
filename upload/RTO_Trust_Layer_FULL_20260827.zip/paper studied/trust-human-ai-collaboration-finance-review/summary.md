# Trust in human–AI collaboration in finance: a bibliometric–systematic literature review

| Field | Value |
|---|---|
| **Authors** | Mario Mirabile (CiTIUS, Universidade de Santiago de Compostela, Spain; Univ. of Bologna, Italy), Giovanni Emanuele Corazza (Univ. of Bologna), Jose María Alonso-Moral (CiTIUS, Universidade de Santiago de Compostela) |
| **Venue / Year** | AI & Society (2026) 41:7625–7654; received 14 Dec 2025, accepted 8 Apr 2026, published online 8 May 2026 |
| **Type** | journal article (bibliometric–systematic literature review) |
| **DOI / URL** | https://doi.org/10.1007/s00146-026-03049-y |
| **Processed** | 2026-08-26T05:29:16Z |
| **Source PDFs** | s00146-026-03049-y.pdf (sha256 prefix 82bd85e4) |

> Version 1 — generated from extracted PDF text.

## Abstract

"Artificial intelligence (AI) is becoming deeply embedded in financial services, including credit scoring, robo-advisory, trading, compliance, and reporting. In these contexts, failures of trust in human–AI collaboration do not merely affect technology adoption but raise fiduciary, reputational, and systemic concerns. Yet, despite its centrality, trust remains conceptually fragmented and inconsistently operationalized across the literature. To address this fragmentation, this study presents a Bibliometric–Systematic Literature Review of trust in human–AI collaboration in finance. Accordingly, we first stabilize trust in the financial context as a latent evaluative belief under uncertainty by specifying the trustor, trustee, and object of trust, and by distinguishing trust from other constructs. Then following a PRISMA-guided Scopus retrieval (June 9, 2025), 430 records were screened, yielding a final corpus of 114 finance-specific publications published between 2018 and 2025. Using bibliographic coupling, weighted Leiden clustering, and centrality metrics, the review maps the intellectual structure of the field and identifies six research clusters: (i) AI governance in finance, (ii) eXplainable AI for finance, (iii) anthropomorphism in financial AI agents, (iv) user-interface design for human–AI interaction in finance, (v) robo-advisors for financial decision-making, and (vi) infrastructural trust technologies. Across these clusters, trust is variously framed as cognitive, affective, procedural, or infrastructural, with limited integration between analytical levels. Building on the bibliometric mapping and qualitative synthesis, the study develops a multi-level socio-technical framework that organizes how trust is discussed in the literature at the micro-level (user perceptions and calibration), meso-level (organizational design and corporate AI governance), and macro-level (regulatory and infrastructural). The micro–meso–macro framework is operationalized through eight analytically distinct propositions that synthesize recurrent patterns regarding trust calibration, overreliance, transparency-as-assurance, accountability, and systemic trust vulnerability. Four finance-oriented use cases illustrate how trust is treated as a distributed property of individuals, organizations, and institutions rather than as a feature of AI systems alone. By consolidating a fragmented body of work and clarifying its conceptual structure, this review provides a bounded, governance-oriented foundation for future empirical, experimental, and longitudinal research on trust in human–AI collaboration in finance."

## Plain-Language Restatement

Banks, insurers, and fintechs increasingly let AI help make decisions about credit, investments, compliance, and payments — but whether people actually rely on that AI wisely depends on trust, a concept researchers define inconsistently. This study systematically collected 114 academic papers (2018–2025) on trust in human–AI collaboration in finance, mapped them into six research communities using network analysis, and examined how each defines and measures trust. It then merges the findings into one framework with three levels — the individual user calibrating reliance, the organization designing governance around AI, and the regulator/infrastructure providing assurance — captured in eight concrete, testable propositions. The core message: good outcomes require calibrated trust (neither blind acceptance nor refusal), and trust is produced jointly by users, organizations, and institutions rather than by clever AI alone.

## Problem Statement

Trust failures in financial human–AI collaboration raise fiduciary, reputational, and systemic risks — weakened accountability, obscured decision rationales, amplified model-driven bias and correlated behavior, fraud/disinformation exposure, and threats to financial stability. Yet trust remains conceptually fragmented and inconsistently operationalized across the literature: no cohesive narrative existed explaining how trust in finance's human–AI collaboration is conceptualized, measured, and fostered. The review addresses five RQs: distinctive research themes (RQ1), how influential studies conceptualize trust (RQ2), which methods/tools investigate trust dimensions (RQ3), emerging themes/gaps (RQ4), and integratively, which governance/design levers are associated with justified trust understood as calibrated reliance (RQ5).

## Methodology

Bibliometric–Systematic Literature Review (B-SLR) following Marzi et al.'s 10-step guidelines, integrating PRISMA 2020 retrieval, bibliographic coupling, centrality mapping, and manual full-text review:
- **Search**: Scopus query on June 9, 2025 combining trust*/distrust*/mistrust* × AI × coworker/partner/collaborat*/team* × "human–AI"/"human-agent"/"human-machine"/"human-bot"/"human-autonomy" × hybrid/collect/augment/extend × financ*, restricted to English articles/conference papers/reviews. Alternative terms (acceptance, adoption, assurance, automation bias/complacency, confidence, reliance, safety) were deliberately excluded to preserve construct precision (rationales in Supplementary Materials).
- **Screening (PRISMA)**: 430 records identified → 426 after cleaning/deduplication → 114 included requiring trust in human–AI collaboration as primary construct AND explicit financial application; corpus spans 2018–2025.
- **Network analysis**: bibliographic coupling linking documents by shared references (minimum threshold: 1 shared reference) → connected network of 105 nodes and 610 links (9 documents isolated/excluded). Weighted Leiden community detection (Python v3.12.9, NetworkX) yielded six clusters of 13–21 nodes with overall modularity 0.38 (Newman).
- **Metrics**: Global Weight Distinctiveness (GWD, Fronzetti Colladon & Naldi) to identify unique cluster keywords; eigenvector centrality as primary structural-influence metric (plus degree, betweenness, closeness — definitions tabulated); country affiliations analyzed via full/fractional counting (China and India largest fractionalized shares).
- **Qualitative synthesis**: manual full-text review of the five most structurally influential papers per cluster (ranked by raw and locally normalized eigenvector centrality) extracting trust conceptualizations, methods/tools, and dimensions; interpretive synthesis per Marzi et al.; Sankey diagram (SankeyMATIC) mapping cluster→theme→gap flows; colorblind-safe Tol palette.
- Construct stabilization upfront (Table 1): trust = latent evaluative belief held by a trustor toward a trustee (AI system/model/interface/institution/vendor/socio-technical arrangement) under uncertainty, analytically distinct from reliance (observable behavioral dependence), calibration (alignment of subjective trust with actual capability), and legitimacy (perceived normative appropriateness).

## Key Results

**Six clusters (RQ1)** with top distinctiveness (GWD) keywords:

| Cluster | Theme | Top distinctive keywords (GWD) |
|---|---|---|
| 1 | AI Governance in Finance | AI (74.07), AI governance (48.10), Trust (39.97), XAI (31.60) |
| 2 | XAI for Finance | XAI (96.26), AI (58.72), Finance (54.88), Ethics (35.38) |
| 3 | Anthropomorphism in Financial AI Agents | Finance (76.21), Anthropomorphism (71.64), AI agents (41.44), Trust repair (17.88) |
| 4 | User Interface Design | Chatbot design (97.15), Fintech (74.32), Chatbot (63.22), Privacy (27.69) |
| 5 | Robo-Advisors for Financial Decision-Making | Finance (68.38), AI (68.13), Robo-advisor (66.46), Overreliance (29.21) |
| 6 | Infrastructural Trust Technologies | Blockchain (120.19), Supply chain (93.92), Agrifood traceability (88.18), Transparency (25.48) |

Clusters 5 and 1 are most cohesive and form the network core; publication output rises steadily 2018–2025.

**Trust conceptualizations (RQ2)**: governance/XAI clusters frame trust cognitively/procedurally (transparency, accountability, explainability, auditability — e.g., Khushk et al. 2024 competence+transparency; Khan et al. 2025 compliance/auditing; Owens et al. 2022 transparent fair auditable insurance AI); anthropomorphism/UI clusters frame it socio-affectively (apologies repair trust after breaches — Kim & Song 2021; warmth–competence impressions — Yan et al. 2025; ability/benevolence/integrity in service recovery — Agnihotri & Bhattacharya 2024); robo-advisor work treats trust as a behavioral mediator balancing confidence vs. overreliance (Riedel et al. 2022; Chen et al. 2025 congruence/clarity/commitment + self-efficacy); infrastructural cluster reframes trust as "trustless trust" via blockchain transparency/traceability/distributed verification (Yavaprabhas et al. 2023; Duong et al. 2025; Majeed Parry et al. 2024).

**Methods (RQ3)**: survey-based SEM dominates (Warp PLS, PLS-SEM, CB-SEM/AMOS with Harman's test, Mplus bootstrapping); scenario experiments with ANOVA/ANCOVA and mediation (PROCESS); qualitative expert interviews and NVivo-coded focus groups (Bhatia et al.); within-subject eye-tracking with repeated-measures ANOVA (Chen et al. 2024); technical studies using LIME with an H2O deep classifier and precision-recall evaluation (Chowdhury et al. 2023) and SHAP-based Action Design Research across classic ML techniques (Sabharwal et al. 2025); PRISMA SLRs recur throughout; science mapping (SciMAT, main-path analysis; Bibliometrix/Louvain/RPYS).

**MMM framework with eight propositions (RQ5)**:
| Level | Proposition | Statement (condensed) |
|---|---|---|
| Micro | P1 Trust-reliance calibration | Higher subjective trust does not predict better decision outcomes unless calibrated to actual competence, uncertainty, and decision authority |
| Micro | P2 Anthropomorphism & overreliance risk | Human-like cues increase initial trust AND overreliance when interfaces fail to surface model uncertainty, scope limits, or escalation paths |
| Meso | P3 Governance-moderated transparency | Transparency/explainability increase trust only when embedded in governance ensuring auditability, accountability, enforceable oversight |
| Meso | P4 Corporate governance maturity | Mature AI-governance organizations show lower variance in human reliance behavior than technically equal but weakly governed ones |
| Macro | P5 Institutional embedding of trust | In regulated finance, trust is primarily shaped by confidence in audits, assurance regimes, and regulatory oversight |
| Macro | P6 Standardization condition | Regulatory trust requires standardized benchmarks for explainability/validation/compliance, not firm-specific claims |
| Cross | P7 Trust repair via responsibility attribution | Post-failure recovery is faster/durable when attribution across humans/AI/institutions is explicit and contestable, not diffuse |
| Cross | P8 Systemic fragility under correlated adoption | Convergence on similar models/vendors/templates makes trust systemically fragile — localized failures can propagate sector-wide |

Four use cases illustrate level interplay: Verification of Payee (payers verify beneficiary-name match; providers run real-time verification; European Payments Council sets common rules), financial education, stock-market participation, financial reporting. Appendix Table 13 operationalizes levels with boundary conditions, mechanisms, and indicators (e.g., trust-reliance mismatch rates, override frequency; audit trails, SHAP/LIME documentation, escalation logs; regulatory approval outcomes, benchmark adoption).

Governance discussion: AI framed as non-moral yet governance-relevant ("functional agency"); Véliz's "moral zombies" position strengthens the case for grounding trust in institutions rather than in AI itself; Moro-Visconti casts AI as a high-centrality interlayer accelerating governance; agentic AI diffuses accountability, endogenizes systemic risk, shifting governance toward behavioral constraints and oversight design. Three recurring linkages: L1 accountability/auditability as board-level obligation; L2 overreliance tied to weak safeguards (missing human agency, escalation protocols); L3 transparency meaningful only via assurance artifacts (model documentation, validation reports, audit trails).

## Conclusions & Implications

The authors claim this is the first B-SLR of trust in human–AI collaboration in finance; the field is rapidly growing but fragmented, with limited cross-cluster integration. Their contribution: reproducible mapping, clarified constructs (trust ≠ reliance ≠ capability), and the MMM framework with testable propositions. Practitioner implications: pursue calibrated reliance rather than trust maximization; embed transparency in governance artifacts; build explicit responsibility attribution and escalation paths for post-failure repair; beware correlated adoption creating sector-wide fragility; standardize explainability/validation benchmarks. Five prioritized future directions: longitudinal trust-calibration studies; field experiments on real platforms (robo-advisory, payment systems, reporting tools, compliance analytics); measurable governance/accountability indicators; standardized finance-specific XAI benchmarks; cross-cultural advice-taking comparisons. Dataset publicly available on Zenodo (doi 10.5281/zenodo.17922549).

## Limitations

**Acknowledged by authors:** Scopus-only, time-bounded retrieval (excludes arXiv/SSRN preprints, legal/policy documents, industry reports); no backward/forward snowballing; possible conceptual/cultural/linguistic biases from query strategy; bibliometric structures sensitive to database scope, citation density, thresholds (they used minimum 1 shared reference to preserve connectivity); citation metrics favor well-cited older works (mitigated by eigenvector centrality choice); cluster boundaries reflect both algorithmic parameters and human coding judgment — indicative, not taxonomic; results temporally bound given fast-moving AI/regulation.

**Inferred by me:** the framework is descriptive/integrative — propositions are grounded in literature patterns, not yet empirically tested by this paper, so they should be treated as hypotheses; the manual deep-read covers only the top-5 most central papers per cluster (~30 of 114 documents), so long-tail literature may be underrepresented; "finance" breadth means India-specific payment contexts (UPI, DPDP) are not directly analyzed — the Verification-of-Payee example is European; quantitative effect sizes are absent because the synthesis is qualitative above the bibliometric layer; the exclusion of adjacent constructs (acceptance, confidence) improves precision but may omit relevant adoption-focused evidence.

## Relevance to Our Hackathon

This review is the theoretical backbone for any hackathon feature touching human trust in fintech AI:

- **Human-AI trust calibration in fintech decisioning**: Propositions P1/P2 give the design spec — don't maximize user trust in your agent checkout assistant; surface model uncertainty, scope limits, and escalation paths so reliance stays calibrated. Build a demo where the shopping agent displays confidence + uncertainty on each recommendation and offers a one-tap human handoff; measure trust-reliance mismatch (subjective trust vs. actual accuracy) as the evaluation metric, exactly per Table 13's micro-level indicators.
- **Trust scoring layers for agent-mediated payments**: P5/P8 warn that trust must live in institutions and infrastructure, not just UX — pair your agent-reputation score with auditable logs, certification badges, and scheme-level rules (the VoP use case is a template: name-match verification at payer/provider/scheme layers maps neatly onto buyer-agent/merchant/network checks at Razorpay-style checkout).
- **Explainability of risk models**: Cluster 2's consensus (transparency only builds justified trust when embedded in assurance artifacts) supports shipping SHAP-based reason codes for RTO/fraud declines to merchants alongside an audit trail — satisfying both the customer-facing explanation need and the meso-level governance artifact requirement.
- **Overreliance & anthropomorphism guardrails**: P2 directly cautions against making payment chatbots too human-like without uncertainty disclosure — a concrete, judge-friendly design principle for conversational commerce UIs.
- **Fraud/systemic angle**: P8 (correlated adoption fragility) motivates stress-testing your fraud model ensemble against correlated-failure scenarios (all merchants sharing one vendor model) — a distinctive robustness experiment for imbalanced-data demos.
- **Post-failure repair**: P7 suggests implementing explicit, contestable responsibility attribution after a wrong block/charge (who: agent, merchant, bank, model?) with apology-and-remedy flows — Kim & Song's trust-repair findings suggest interaction design matters as much as the fix.
