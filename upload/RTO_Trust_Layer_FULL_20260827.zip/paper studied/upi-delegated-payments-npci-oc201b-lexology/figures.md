# Figures & Tables Log — upi-delegated-payments-npci-oc201b-lexology

Source key: `6c8114d1297c` (5-page Lexology print capture).

## Figures
**None.** The document contains no charts, diagrams, photographs, or embedded figures. `.cache/images/6c8114d1297c/` contains only `figures_index.json`, which lists `"rendered_pages": []` and `"embedded_images": []` — the PDF is pure text (web-page print-to-PDF).

## Tables
**None.** The OC 201-B obligations are presented as numbered prose lists (1. General Obligations a–g; 2. Primary UPI Apps (a)–(c); 3. Secondary Apps/PSP Banks a–h; 4. Issuer Banks), not tables. Numeric values appear inline (INR 15,000 monthly per Device; INR 5,000 per transaction; 24-hour cooling with INR 5,000 cumulative; 5-Device limit). No tables.csv produced (no numeric tables exist to extract).

## Page-by-page content map (from full text read)
| Page | Content | Notes |
|---|---|---|
| 1 | Title fragment "Enabling Delegated Payments on UPI Rails: Implications on ...", date "November 21 2025", Introduction, Key Guidelines §1a (RBI TAT guidelines); Lexology "Register" promo box | header logo text truncated to "MEMBER FIRM OF" (firm network name not extractable); URL lexology.com/library/detail.aspx?g=c1688ffb-56… truncated; print stamp 8/26/26 12:01 |
| 2 | §1b–g (ODR, reconciliation, device linking controls, P2M scope, proximity, limits/cooling), §2 Primary UPI Apps | limits: INR 15,000/month per Device; INR 5,000/txn; 24h cooling INR 5,000 |
| 3 | §3 Secondary Apps/PSP obligations a–h, §4 Issuer Banks, Comments (agentic-payments outlook), disclaimer + author byline | "NCPI" typo for NPCI; byline "Harsh Walia, Rupendra Gautam and Sanskriti Shrivastava"; disclaimer re Khaitan & Co views |
| 4 | Lexology product/navigation listing (Daily newsfeed, Panoramic, Lexy Find, Scanner, Lexy AI, Client Choice 2025, etc.) | boilerplate |
| 5 | Lexology footer nav, © Copyright 2026 LBR trading as Centellic | boilerplate |

## Quality observations
- Text extraction shows ligature/ordinal artifacts ("8  October", "th" orphaned on p.1, "ﬀ" ligatures), truncated URL, and a cut-off masthead — typical print-to-PDF capture, not source corruption.
- No watermarks or image degradation possible (no images).
- Supports: summary.md's characterization as a 5-page legal-analysis web capture with no empirical content; the article's numeric control surface matches pages 2–3 as listed above.
