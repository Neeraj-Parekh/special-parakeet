# Research Requests — upi-delegated-payments-npci-oc201b-lexology

- [High] Diff the Lexology restatement against the primary circular (npci-oc201b-upi-circle-iot-circular folder) clause-by-clause; document every divergence (e.g., "per Device" vs the circular's "per delegation" monthly limit) and classify which reading is textually supported.
- [High] Build the four-actor compliance matrix as an interactive checklist web component (general / Primary App / Secondary PSP / Issuer) and pilot it on three mock agentic-checkout designs; record which obligations most commonly fail.
- [Med] Prototype the issuer-side per-debit validation service (device ID + user ID lookup with sub-100ms p99) that OC 201-B effectively mandates; benchmark against a mock UPI switch load profile.
- [Med] Design a consent-evidence store that satisfies 2FA-at-linking plus per-debit device validation audit trails, aligned with DPDP data-minimization; demonstrate a regulator-view replay of one delegated payment end-to-end.
- [Med] Track the pending NPCI permitted-devices list: draft the application dossier a device maker would submit (due diligence, app security evaluation, data-flow documentation, localization proof) so a hackathon prototype can show launch-readiness.
- [Med] Analyze the P2M-only scope: enumerate agent-commerce use cases that remain legal (merchant checkout, bill pay) vs excluded (P2P, cross-border), and propose feature flags enforcing scope at the SDK level.
- [Low] Compare the 24-hour/₹5,000 cooling-period design against fraud-loss curves from synthetic new-device abuse data; recommend whether the cooling window is over- or under-provisioned.
- [Low] Write a liability-gap memo: the article does not analyze who bears loss when issuer validation fails or explicit action is spoofed; propose allocations grounded in the circular's validation duties.
- [Low] Monitor for the limited-user-group → general-availability transition the article flags; design an entitlement service that can gate the feature per NPCI's staged rollout communications.
