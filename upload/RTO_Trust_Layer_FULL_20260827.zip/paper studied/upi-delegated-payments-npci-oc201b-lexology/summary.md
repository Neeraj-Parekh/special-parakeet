# Enabling Delegated Payments on UPI Rails: Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B

| Field | Value |
|---|---|
| **Authors** | Harsh Walia, Rupendra Gautam and Sanskriti Shrivastava (Khaitan & Co; disclaimer notes content is solely the author(s)' view) |
| **Venue / Year** | Lexology (legal newsfeed/analysis), November 21 2025 |
| **Type** | whitepaper (law-firm client alert / legal analysis of a regulatory circular; 5-page print-to-PDF of web article) |
| **DOI / URL** | https://www.lexology.com/library/detail.aspx?g=c1688ffb-56… (URL truncated in extracted text) |
| **Processed** | 2026-08-26T09:28:05Z |
| **Source PDFs** | Enabling Delegated Payments on UPI Rails_ Implications on IoT and Software Integration for UPI Payments NPCI OC 201-B - Lexology.pdf (sha256 4393d900…) |

> Version 1 — generated from extracted PDF text.

## Abstract

*(No formal abstract; opening passage, quoted verbatim:)* "On 8th October 2025, the National Payment Corporation of India (NPCI) issued an Operating Circular 201-B (OC), authorising the use of Internet of Things (IoT) devices and software (together, Devices) within the Unified Payments Interface (UPI) Circle framework. This OC builds on NPCI's 2024 circular that introduced delegated payments called UPI Circle - a feature that enables a bank account holder (Primary User) to securely share controlled payment access with trusted individuals or devices (Secondary User). … By enabling this integration, the NPCI has, inter alia, established a foundational framework for 'agentic payments' within the UPI ecosystem, i.e., payments executed by AI agents (such as chatbots like ChatGPT) that can initiate, authenticate and complete transactions on a user's behalf, while fully preserving user control, security and consent."

## Plain-Language Restatement

An Indian law firm explains a new central-bank-adjacent rule that lets gadgets and software — smartwatches, AI chatbots — pay through India's UPI system on a person's behalf. The rule caps spending (₹5,000 per payment, ₹15,000 a month), forces apps to get explicit two-factor consent before linking any device, and makes banks re-check the device's identity on every single payment. The authors read it as India laying the legal tracks for "agentic payments" — AI agents transacting for users under tight control.

## Problem Statement

The analysis addresses the interpretive gap between NPCI's terse operating circular OC 201-B (8 Oct 2025) and the ecosystem actors who must implement it (Primary UPI Apps, Secondary Apps, PSP Banks, Issuer Banks). It matters because OC 201-B is characterized as the foundational framework for agentic payments on UPI; without a structured restatement, regulated entities cannot map their obligations (consent, validation, limits, data localization) onto product decisions. The article also flags an open compliance dependency: "NPCI is yet to provide a list of the permitted devices."

## Methodology

*(Legal commentary, not empirical research — approach summarized.)*
- **Doctrinal summarization**: article walks through OC 201-B's four obligation clusters: (1) General Obligations; (2) Obligations for Primary UPI Apps; (3) Obligations for Secondary Apps and PSP Banks (Certified on UPI Circle); (4) Obligations on Issuer Banks.
- **General obligations** as restated: RBI Harmonisation of TAT/Customer Compensation guidelines (20 Sep 2019); ODR mechanism; reconciliation/settlement per existing UPI processes; only NPCI-authorized Devices linkable as secondary (list pending); domestic Person-to-Merchant (P2M) only — cross-border and P2P out of scope; proximity requirement between primary and secondary devices at linking; limits — max INR 15,000 monthly per Device and INR 5,000 per transaction, plus a mandatory 24-hour cooling period on new delegations with cumulative cap INR 5,000.
- **Primary UPI Apps**: clearly display secondary device/software and obtain explicit consent via 2FA before authorization; lifecycle management (limit management, delinking); cap of five Devices per Primary User.
- **Secondary Apps/PSP Banks**: onboarding only after due diligence and app security evaluation; registration with explicit consent and OTP-based mobile validation; capture Device ID/user details at registration and validate on each payment request; record user profile ID for software (limited user group initially, broader rollout communicated by NPCI post-validation — text spells it "NCPI"); same mobile number for profile and UPI Circle registration; delegation acceptance from only one Primary UPI app; data protection per NPCI processes (data-flow documentation, data localization, regular security reporting); non-exclusive integrations for devices without dedicated apps.
- **Issuer Banks**: validate Device ID and user ID before debiting the customer's account for every payment instruction.
- No datasets, models, or statistics are used; the method is close reading and restatement, ending with forward-looking "Comments."

## Key Results

*(Qualitative legal analysis — key claims/interpretations instead of numbers.)*
- OC 201-B "established a foundational framework for 'agentic payments'" — defined here as payments executed by AI agents (e.g., chatbots like ChatGPT) that initiate, authenticate and complete transactions on a user's behalf while preserving user control, security and consent.
- The framework "introduces a secure and interoperable delegation layer that fundamentally transforms the UPI from a system reliant on human-initiated actions to one that is inherently AI-native."
- Numeric control surface (consistent with the circular): INR 15,000 monthly cap per Device; INR 5,000 per-transaction cap; 24-hour cooling period with INR 5,000 cumulative cap; 5-device authorization limit; domestic P2M only.
- Open item: the list of NPCI-permitted devices had not yet been published at writing.
- Outlook: rapid expansion expected across India's UPI user base; "India's leadership in real-time, AI-augmented payments."

## Conclusions & Implications

Authors conclude the OC is a significant enabler for automated, intelligent, AI-driven payment solutions and sets "the operational stage for agentic payments." For practitioners: (1) the four-cluster obligation map (general / primary app / secondary PSP / issuer) is effectively a product-compliance checklist for any device- or agent-initiated UPI flow; (2) consent + 2FA + per-transaction device/user-ID validation means agent payment products must engineer verifiable human intent at two points (linking and each debit); (3) data-flow documentation, localization, and security reporting are standing RegTech obligations, not one-time certifications; (4) the pending permitted-devices list is a regulatory dependency to monitor before launch. Caveat: this is law-firm commentary — the circular itself (processed separately in this knowledge base) remains the primary source.

## Limitations

*(Acknowledged by authors)*: disclaimer that content "does not necessarily reflect the views / position of Khaitan & Co"; notes NPCI's permitted-devices list is not yet available; notes initial access restricted to a limited user group pending validation.
*(Inferred by me)*: no independent legal analysis of liability allocation, dispute outcomes, or DPDP interaction beyond mentioning data-localization/reporting; the piece is a summary rather than critique — no discussion of the "explicit user action" debit trigger (prominent in the circular) or of enforcement mechanics; contains minor typographical errors ("NCPI", "th" ordinal artifact, truncated URL), consistent with print-to-PDF capture; undated capture (printed 8/26/26) means the pending-devices-list statement may be stale.

## Relevance to Our Hackathon

Sharpens the regulatory framing for agentic-payment hacks on Razorpay-style rails: (1) the article's four-cluster obligation map converts directly into a compliance-matrix slide/feature — judges can check a demo against general, primary-app, secondary-PSP, and issuer duties; (2) its explicit "agentic payments" definition (AI agents initiate, authenticate, complete, user keeps control) is quotable language for problem statements and pitch decks; (3) the flagged open item (pending NPCI permitted-devices list) is a realistic product-risk callout for any IoT-payment prototype; (4) pairing this interpretation with the primary circular (sibling folder) demonstrates secondary-vs-primary source verification — a good governance story; (5) the P2M-only scope suggests focusing hackathon agent-commerce demos on merchant checkout rather than P2P transfers.

## Figures & Tables

- No figures or tables. The PDF is a 5-page Lexology print capture (header "Enabling Delegated Payments on UPI Rails: Implications on …", URL lexology.com/library/detail.aspx?g=c1688ffb-56…, print timestamp 8/26/26 12:01, "1 of 5"–"5 of 5" page markers). Pages 4–5 are Lexology site navigation/product listings (Daily newsfeed, Panoramic, Lexy AI, etc.) and copyright line "© Copyright 2026 LBR trading as Centellic". No images directory exists for this key (figures_index.json lists no rendered pages or embedded images).
