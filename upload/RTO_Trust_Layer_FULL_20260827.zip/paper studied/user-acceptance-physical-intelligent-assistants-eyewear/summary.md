# Exploring User Acceptance of Physical Intelligent Assistants: A Study on AI-Powered Eyewear

| Field | Value |
|---|---|
| **Authors** | (not stated in text — extracted manuscript does not include author names) |
| **Venue / Year** | (not stated in text); data collected May 2025; references through June 2025 |
| **Type** | preprint / journal-style manuscript (venue not stated in text) |
| **DOI / URL** | (not stated in text) |
| **Processed** | 2026-08-26T05:29:19Z |
| **Source PDFs** | FinalPIAs.pdf (sha256 prefix `9e3c1525`) |

> Version 1 — generated from extracted PDF text.

## Abstract

> "As AI becomes increasingly integrated into everyday life, driven by the ongoing AI hardware revolution, physical intelligent assistants (PIAs), such as AI-powered eyewear, are emerging as transformative technologies that enable natural language interaction and autonomous task execution. While prior research has largely focused on digital assistants and traditional smart glasses, limited scholarly attention has been given to the factors influencing user adoption of AI-powered eyewear. This study extends the technology acceptance model (TAM) with perceived intelligence factors (conversational intelligence, task intelligence, and perceived naturalness), interface design aesthetics, and privacy concerns. Data were collected from 629 US users and analyzed using PLS-SEM and fsQCA. The results show that perceived intelligence factors and perceived ease of use positively affect perceived usefulness and user acceptance, while interface design aesthetics, although not affecting perceived usefulness, directly enhances acceptance. In contrast, privacy concerns negatively impact acceptance. The fsQCA analysis further reveals both function-driven and style-conscious configurations associated with high acceptance, emphasizing that adoption depends on thoughtfully tailored feature bundles rather than a one-size-fits-all design. Across all pathways, privacy concerns consistently emerge as a fundamental barrier. This study advances the literature and provides actionable insights for designers and marketers seeking to foster adoption of AI-powered eyewear."

## Plain-Language Restatement

This study asks why people accept (or reject) AI-powered smart glasses — a new class of "physical intelligent assistants" that combine LLM-based conversation, task execution, cameras and sensors on your face. Surveying 629 US users of devices like Meta Ray-Ban glasses, the authors find that how intelligent the device seems (conversation quality, autonomous task execution, human-like voice) and how easy/useful it is drive acceptance, while looks matter independently of usefulness. Crucially, privacy concerns are the single consistent barrier across every pathway to adoption: people only embrace these always-sensing devices when they trust data handling. There is no single recipe — some buyers want function, others want style — but nobody adopts without privacy reassurance.

## Problem Statement

Prior work covered purely digital intelligent personal assistants (Siri, Alexa, ChatGPT) and traditional heads-up-display smart glasses, but neither stream addresses the convergence of cognitive AI with physical embodiment (continuous sensing, hands-free multimodal interaction). Specific gaps the authors list: (1) PIAs like AI eyewear are unstudied as a category; (2) perceived intelligence has been treated as unidimensional rather than decomposed into dimensions that differentially drive adoption; (3) interface design aesthetics had not been examined for smart glasses/IPAs; (4) earlier smart-glasses studies found privacy concerns did NOT deter adoption, so it was unknown whether this holds for AI-powered eyewear with continuous environmental sensing; (5) most studies used only SEM, missing configurational interdependencies ("one-size-fits-all" promotion is likely ineffective). This matters because AI hardware vendors are shipping such devices now, and designers/marketers lack evidence on what drives acceptance.

## Methodology

- **Theory/model**: Extended TAM (Davis 1989) adding three perceived-intelligence dimensions — conversational intelligence (CI), task intelligence (TI), perceived naturalness (PN) — plus interface design aesthetics (IDA) and privacy concerns (PC), predicting perceived usefulness (PU) and user acceptance (ACC). Hypotheses H1, H2a-b, H3a-b, H4a-b, H5a-b, H6a-b, H7a-b.
- **Construct measurement** (Table 2): PU 3 items (Davis 1989), PEOU 4 items (Davis 1989), CI 4 items (Ling et al. 2025), PN 3 items (Guha et al. 2023; Hu et al. 2021b), TI 3 items (Moussawi & Koufaris 2019; Hu et al. 2021a), Design aesthetics 3 items (Cyr et al. 2006), Privacy concerns 4 items (De Cosmo et al. 2021; Dhagarra et al. 2020), Acceptance 3 items (Gursoy et al. 2019). 7-point Likert scales; reversed items included.
- **Data**: US residents, May 2025, purposive sampling on MTurk (USD 1 incentive). Quality controls per Aguinis et al. (2021): short questionnaire without labeled endpoints, US-only English speakers, open-ended attention check, retention only if completed within 4–10 minutes. Result: **629 valid responses** (abstract says 629; introduction once says 627 — internal inconsistency). Demographics: 380 males (60.4%), 249 females (39.6%); 44% White, 27% Black or African American; majority aged 18–40; 31.5% bachelor's degree; students 35%, employees 31.5%, businesspeople 23.8%. Device used: Meta Ray-Ban 83.9%, Brilliant Labs Frame 16.1%.
- **Analysis**: Two-stage synergy — PLS-SEM (SmartPLS v4.1) for linear hypothesis testing (bootstrapping with 5,000 samples) plus fsQCA (fsQCA v4.1) for configurational pathways. Four analysis stages: reliability/validity, hypothesis tests, model fit (GoF), fsQCA (calibration with full membership at 7, non-membership at 1, crossover at each construct's mean per Fiss 2011; necessity analysis at consistency >0.9 threshold; sufficiency with frequency cut-off 35 and consistency cut-off 0.85).
- **Common method bias**: Harman's single-factor test (single factor = 43.708% of variance < 50%) and full collinearity/VIF assessment (all VIFs < 3.3, Kock 2015).

## Key Results

Measurement model: loadings 0.720–0.860; Cronbach's alpha 0.831–0.898; CR > 0.7; AVE > 0.5; Fornell–Larcker satisfied; HTMT < 0.85; VIF < 5.

Structural model explains **57.3% of variance in acceptance (R² = 0.573)**; PU R² = 0.551; GoF = 0.600 ("GoF large", thresholds 0.1/0.25/0.36).

Direct effects (PLS-SEM, bootstrap n=5,000):

| Hypothesis | Path | β | Std. Error | T | p | Supported |
|---|---|---|---|---|---|---|
| H1 | PU ➔ ACC | 0.198 | 0.076 | 2.616 | 0.009 | Yes |
| H2a | PEOU ➔ PU | 0.121 | 0.046 | 2.614 | 0.009 | Yes |
| H2b | PEOU ➔ ACC | 0.122 | 0.046 | 2.647 | 0.008 | Yes |
| H3a | CI ➔ PU | 0.183* | 0.056 | 3.241 | 0.001 | Yes |
| H3b | CI ➔ ACC | 0.142 | 0.061 | 2.343 | 0.019 | Yes |
| H4a | TI ➔ PU | 0.142 | 0.055 | 2.581 | 0.010 | Yes |
| H4b | TI ➔ ACC | 0.117 | 0.056 | 2.083 | 0.037 | Yes |
| H5a | PN ➔ PU | 0.141 | 0.054 | 2.605 | 0.009 | Yes |
| H5b | PN ➔ ACC | 0.107 | 0.051 | 2.117 | 0.034 | Yes |
| H6a | IDA ➔ PU | 0.092 | 0.054 | 1.706 | 0.088 | **No (ns)** |
| H6b | IDA ➔ ACC | 0.133 | 0.057 | 2.312 | 0.021 | Yes |
| H7a | PC ➔ PU | -0.221 | 0.051 | 4.322 | 0.000 | Yes |
| H7b | PC ➔ ACC | -0.111 | 0.053 | 2.080 | 0.038 | Yes |

*Narrative text reports CI ➔ PU β = 0.188 while Table 5 reports 0.183; Table 5 value shown above.*

Privacy concerns have the largest single effect on PU (-0.221, strongest path in the model).

fsQCA (calibration crossovers e.g., PU 4.910, PEOU 4.981, CI 4.942, TI 4.943, PN 4.932, IDA 4.895, PC 3.223, ACC 4.965): no single condition met necessity consistency > 0.9 for ACC or ~ACC (highest: ~PC consistency 0.842 for ACC; CI 0.847). Sufficiency solutions:

| Configuration | High-ACC #1 (function-driven) | High-ACC #2 (style-conscious) | Low-ACC (~ACC) |
|---|---|---|---|
| PU | ● | ● | ⊗ |
| PEOU | ● | ● | ⊗ |
| CI | ● | ● | ⊗ |
| TI | ● | ● | ⊗ |
| PN | ● |   | ⊗ |
| IDA |   | ● | ⊗ |
| PC | ⊗ | ⊗ | ● |
| Raw coverage | 0.544 | 0.544 | 0.544 |
| Unique coverage | 0.037 | 0.038 | 0.544 |
| Consistency | 0.936 | 0.938* | 0.965 |

(● = presence, ⊗ = absence, blank = "do not care". *Narrative cites 0.940 for Config 2 vs. 0.938 in Table 9.) Overall solution: coverage 0.582, consistency 0.935 for high acceptance; 0.544/0.965 for low acceptance. All high-acceptance pathways require the ABSENCE of privacy concerns (PC ⊗) — equifinality: function-driven (intelligence core + naturalness) or style-conscious (intelligence core + design aesthetics) bundles both work.

Qualitative insight: adoption depends on tailored feature bundles, not one-size-fits-all; privacy trust is a prerequisite across segments (illustrated via personas Alex — visually impaired student valuing scene narration — and Mina — marketing executive valuing minimalist style).

## Conclusions & Implications

- Perceived intelligence is multidimensional; each dimension (conversation, tasks, natural voice) uniquely contributes to PU and acceptance — designers should invest in all three interaction qualities.
- Aesthetics is a standalone driver of acceptance even though it does not change perceived usefulness — visual/social desirability matters for wearables independent of function.
- Privacy is central, contradicting earlier smart-glasses findings (Rauschnabel & Ro 2016; Rauschnabel et al. 2018 found own-privacy risk non-significant): for embodied AI with continuous sensing, privacy concerns significantly reduce both PU and acceptance, and their absence is a prerequisite in every high-acceptance configuration.
- Managerial: segment users (function-oriented vs style-conscious); prioritize robust encryption, anonymization, local processing, transparent privacy communication; market intelligence/naturalness attributes.

For practitioners building payment/fintech AI systems: the same psychology applies to agentic payment assistants — perceived task intelligence (does it execute payments correctly and autonomously?) and conversational quality build perceived usefulness, while privacy/consent anxiety suppresses adoption even when utility is obvious. Consent UX, transparent data handling, and on-device/local processing are adoption prerequisites, not nice-to-haves.

## Limitations

Acknowledged by authors:
- Single-country sample (US) limits generalizability; culture/demographics may shift adoption drivers.
- Cross-sectional design — snapshot only; longitudinal designs needed to track evolving acceptance.
- Model explains 57.3% of variance; unexplored constructs remain (authors suggest perceived simplicity, perceived innovativeness, perceived intrusiveness).

Inferred by me:
- MTurk purposive self-selection: sample skews male (60.4%) and young; "acceptance" is intention/perception among existing-or-aware users (83.9% already Meta Ray-Ban owners/users), not longitudinal behavior.
- Minor internal inconsistencies (627 vs 629 sample size; CI➔PU β 0.188 vs 0.183; Config-2 consistency 0.940 vs 0.938) suggest a pre-publication manuscript.
- Self-reported perceptions subject to common-method bias despite mitigations; privacy concern measured as attitude, not actual disclosure behavior.
- fsQCA configurations share large raw coverage (0.544) with tiny unique coverage (0.037/0.038), so pathways overlap heavily.

## Relevance to Our Hackathon

Directly informs the consumer-trust side of a Razorpay-track agentic-payments build:

1. **Consent-first UX for delegated payments**: privacy concerns were the ONLY factor negative in every pathway (β = -0.221 on PU, -0.111 on acceptance; absence required in all high-acceptance fsQCA configs). An agent that pays on the user's behalf must surface transparent consent screens, granular spend limits, and plain-language data-use policies before checkout — treat privacy assurance as an adoption prerequisite, mirroring DPDP-style consent capture.
2. **Trust through demonstrated task intelligence**: TI items ("can autonomously complete tasks quickly", "understand and execute user tasks independently") map onto what users need to see from a payment agent — visible verification steps, confirmations, receipts — before delegating money movement.
3. **Voice/conversational interfaces for payments**: PN and CI positively predict acceptance; if our hack adds voice-initiated payments (natural fit for eyewear/wearables), natural-sounding confirmation dialogues measurably help adoption.
4. **Segmented rollout strategy**: function-driven vs style-conscious configurations justify offering both a utilitarian "agent dashboard" mode and a minimal/invisible mode; don't force one UX.
5. **Survey instrument reuse**: the validated item sets (privacy concerns scale from De Cosmo et al./Dhagarra et al.; acceptance from Gursoy et al.) can be lifted into a hackathon user study measuring willingness to delegate payments to an agent.
6. **Explainability angle**: since PC suppresses perceived usefulness most strongly, pairing every automated payment decision with an explanation (what data was used, why this merchant/order) attacks the exact barrier identified.
